﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BasicLib;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for ExampleChooser.xaml
    /// </summary>
    public partial class RotationChooser : Window
    {

        public RotationChooser()
        {
            InitializeComponent();
            AxislistBox.Items.Add(AXIS.X);
            AxislistBox.Items.Add(AXIS.Y);
            AxislistBox.Items.Add(AXIS.Z);
            AxislistBox.SelectedValue = AXIS.Z;
        }

        public AXIS ChosenAxis
        {
            get { 
                return (AXIS)AxislistBox.SelectedValue; 
            }
        }

        public double ChosenAngle
        {
            get {
                try
                {
                    return double.Parse(AngleTextBox.Text);
                }
                catch (Exception)
                {
                    return 0;
                }
            }
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            AngleTextBox.Text = slider1.Value.ToString();
        }
    }
}
