﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for ExampleChooser.xaml
    /// </summary>
    public partial class ExampleChooser : Window
    {
       
        public ExampleChooser()
        {
            InitializeComponent();
            for (int i = 1; i < 3455; i++)
                ExamplesCombo.Items.Add(i);
        }

        public int ChosenIndex
        {
            get { return (int)ExamplesCombo.SelectedItem; }
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
