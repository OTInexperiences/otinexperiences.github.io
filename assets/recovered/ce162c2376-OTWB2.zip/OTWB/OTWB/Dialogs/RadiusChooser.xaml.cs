﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BasicLib;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for ExampleChooser.xaml
    /// </summary>
    public partial class RadiusChooser : Window
    {
       
        public RadiusChooser()
        {
            InitializeComponent();
            
        }

        public Range PathStats
        {
            set
            {
                MinRadius.Text = value.Start.ToString();
                MaxRadius.Text = value.End.ToString();
            }
        }

        public double ChosenRadius
        {
            get {
                try
                {
                    return double.Parse(RadiusEntry.Text);
                }
                catch
                {
                    return 0;
                }
            }
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
