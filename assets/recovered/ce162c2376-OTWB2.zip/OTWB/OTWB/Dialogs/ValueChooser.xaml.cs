﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BasicLib;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for ExampleChooser.xaml
    /// </summary>
    public partial class ValueChooser : Window
    {

        double _default;

        public ValueChooser()
        {
            InitializeComponent();
            
        }

        public string DataLabel
        {
            set { label1.Content = value; }
        }

        public double ChosenValue
        {
            get {
                try
                {
                    return double.Parse(KeyEntry.Text);
                }
                catch
                {
                    return _default;
                }
            }
        }

        public double DefaultValue
        {
            set
            {
                _default = value;
                KeyEntry.Text = value.ToString(); 
            }
            get
            {
                return _default;
            }
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
