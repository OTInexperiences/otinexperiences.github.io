﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for CheckFolderPaths.xaml
    /// </summary>
    public partial class CheckFolderPaths : Window
    {
        public CheckFolderPaths()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            //Check if files exist and if so set up basiclib
            if ((Directory.Exists(ProjectFolderPicker.Directory) &&
                (Directory.Exists(LibraryFolderPicker.Directory))))
            {
                BasicLib.Properties.Settings.Default.ProjectsFolder = ProjectFolderPicker.Directory;
                BasicLib.Properties.Settings.Default.LibraryFolder = LibraryFolderPicker.Directory;
                this.DialogResult = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("One of the paths is not valid");
            }
        }

    }
}
