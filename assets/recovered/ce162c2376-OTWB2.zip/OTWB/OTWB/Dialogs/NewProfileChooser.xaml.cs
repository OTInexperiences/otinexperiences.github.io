﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BasicLib;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for ExampleChooser.xaml
    /// </summary>
    public partial class NewProfileChooser : Window
    {

        double _defaultKey;
        double _defaultRadius;
        double _defaultHeight;
        bool _isneg;
        int _defaultNumPoints;

        public NewProfileChooser()
        {
            InitializeComponent();
            _defaultKey = 0;
            _defaultHeight = 20;
            _defaultRadius = 100;
            _isneg = true;
        }

        public string DataLabel
        {
            set { label1.Content = value; }
        }

        public double Key
        {
            get {
                try
                {
                    return double.Parse(KeyEntry.Text);
                }
                catch
                {
                    return _defaultKey;
                }
            }
        }
        public double DefaultKey
        {
            set
            {
                _defaultKey = value;
                KeyEntry.Text = value.ToString(); 
            }
            get
            {
                return _defaultKey;
            }
        }

        public double MaxRadius
        {
            get
            {
                try
                {
                    return double.Parse(RadiusEntry.Text);
                }
                catch (Exception)
                {
                    return _defaultRadius;
                }
            }
        }
        public double DefaultRadius
        {
            set
            {
                _defaultRadius = value;
                RadiusEntry.Text = _defaultRadius.ToString();
            }
            get
            {
                return _defaultRadius;
            }
        }

        public double ChordHeight
        {
            get
            {
                try
                {
                    return double.Parse(HeightEntry.Text);
                }
                catch (Exception)
                {
                    return _defaultHeight;
                }
            }
        }
        public double DefaultHeight
        {
            set
            {
                _defaultHeight = value;
                RadiusEntry.Text = _defaultHeight.ToString();
            }
            get
            {
                return _defaultHeight;
            }
        }

        public bool IsNegative
        {
            get { return (bool)IsNegCB.IsChecked; }
        }
        public bool DefaultIsNegative
        {
            set
            {
                _isneg = value;
                IsNegCB.IsChecked = _isneg;
            }
            get { return _isneg; }
        }

        public int NumPoints
        {
            get
            {
                if (NumPointsTextBox.Value.HasValue)
                    return (int)NumPointsTextBox.Value;
                else
                    return _defaultNumPoints;
            }
        }
        public int DefaultNumPoints
        {
            get { return _defaultNumPoints; }
            set
            {
                _defaultNumPoints = value;
                NumPointsTextBox.Value = value;
            }
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
