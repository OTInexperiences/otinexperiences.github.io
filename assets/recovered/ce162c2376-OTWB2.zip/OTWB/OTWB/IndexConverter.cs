﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Globalization;
using System.Windows.Media.Media3D;
using System.Collections.ObjectModel;
using BasicLib;

namespace OTWB
{
    public class PathListIndexConverter : IMultiValueConverter
    {
        public object Convert(
                           object[] values, Type targetType,
                           object parameter, CultureInfo culture)
        {
            //System.Diagnostics.Debug.Print("values[0]=" + values[0].ToString());
            //System.Diagnostics.Debug.Print("values[1]=" + values[1].ToString());
            Path item = values[0] as Path;
            ObservableCollection<Path> list = values[1] as ObservableCollection<Path>;
            int i = list.IndexOf(item);
            if (item != null)
                return string.Format("Path_{0} TP={1}", i + 1, item.ToolPosition);
            else
                return string.Empty;
        }

        public object[] ConvertBack(
         object value, Type[] targetTypes,
         object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Cannot convert back");
        }
    }

    /*
    public class GcodeProgramListIndexConverter : IMultiValueConverter
    {
        public object Convert(
                           object[] values, Type targetType,
                           object parameter, CultureInfo culture)
        {
            //System.Diagnostics.Debug.Print("values[0]=" + values[0].ToString());
            //System.Diagnostics.Debug.Print("values[1]=" + values[1].ToString());
            GcodeProgramItem item = values[0] as GcodeProgramItem;
            GcodeManager list = values[1] as GcodeManager;
            int i = list.IndexOf(item);
            return string.Format("Path_{0}", i + 1);
        }

        public object[] ConvertBack(
         object value, Type[] targetTypes,
         object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Cannot convert back");
        }
    }
     * */
    public class ProfileIndexConverter : IMultiValueConverter
    {
        public object Convert(
                           object[] values, Type targetType,
                           object parameter, CultureInfo culture)
        {
            System.Diagnostics.Debug.Print("values[0]=" + values[0].ToString());
            System.Diagnostics.Debug.Print("values[1]=" + values[1].GetType().ToString());
            Profile item = values[0] as Profile;
            ObservableCollection<Profile> list = values[1] as ObservableCollection<Profile>;
            int i = list.IndexOf(item);
            return string.Format("key_{0}", item.Key);
        }

        public object[] ConvertBack(
         object value, Type[] targetTypes,
         object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Cannot convert back");
        }
    }

    public class Point3DToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType,
            object parameter, CultureInfo culture)
        {
            if (value is Point3D)
            {
                Point3D p = (Point3D)value;
                return string.Format("{0},{1},{2}", p.X, p.Y, p.Z);
            }
            return string.Empty;
        }

        public object ConvertBack(object value, Type targetType,
            object parameter, CultureInfo culture)
        {
            if (value is string)
            {
                string[] vs = ((string)value).Split(new char[]{','});
                return new Point3D(double.Parse(vs[0]),
                                   double.Parse(vs[1]),
                                   double.Parse(vs[2]));
            }
            return new Point3D();
        }
    }
}
