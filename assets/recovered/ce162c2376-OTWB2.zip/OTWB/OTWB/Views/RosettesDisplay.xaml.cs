﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BasicLib;
using System.Diagnostics;
using System.Collections.ObjectModel;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for RosettesDisplay.xaml
    /// </summary>
    public partial class RosettesDisplay : UserControl
    {
        public event EventHandler RosetteSelected;

        double _opacity;
        double _sf;
        TransformGroup _tg;
        ScaleTransform _st;
        TranslateTransform _tt;
        RotateTransform _rt;

        Grid _grid;
        Point _start;
        Point _origin;
        List<Rosette> _rosette_names;
        bool _showgrid;

        public Spindle Spindle { get; set; }

        public RosettesDisplay()
        {
            InitializeComponent();
            // set transform dependant on width and height
            _opacity = BasicLib.Properties.Settings.Default.Opacity;
            _tg = new TransformGroup();
         
            _rt = new RotateTransform(0);
            _tg.Children.Add(_rt);

            _st = new ScaleTransform(1, 1, 0.5, 0.5);
            _tg.Children.Add(_st);

            _tt = new TranslateTransform(0, 0);
            _tg.Children.Add(_tt);
            SpindleRosettesCanvas.RenderTransform = _tg;
            SpindleRosettesCanvas.RenderTransformOrigin = new Point(0.5, 0.5);
            _sf = 1;

            _rosette_names = new List<Rosette>();
            _showgrid = GridMenuItem.IsChecked;
            if (_grid == null)
            {
                try
                {
                    _grid = new Grid(Grid.GRIDTYPE.RADIAL);
                    double maxrad = 200;
                    if (Spindle != null)
                        maxrad = Spindle.MaxRosetteRadius + 10;
                    Range r = new Range(0, 10,maxrad);
                    _grid.Dim1Range = r;
                    _grid.Dim2Range = new BasicLib.Range(0, 10, 360);
                    _grid.CreateGrid();
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.InnerException.Message);
                }
            }
        }

     
        public void DrawSpindle(string lastRosette)
        {
            Shape ro;
            
            SpindleRosettesCanvas.Children.Clear();
            _rosette_names.Clear();
            if ( _showgrid && _grid.GridOutline != null)
            {
                double r = (Spindle == null)
                        ? border1.ActualHeight / 2 - 20
                        : Spindle.MaxRosetteRadius;
                if (_grid.Dim1Range.End != r)
                {
                    _grid.Dim1Range.End = r + 20;
                    _grid.CreateGrid();
                }
                _grid.GridOutline.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.GridColor);
                _grid.GridOutline.StrokeThickness = 1 / _sf;
                SpindleRosettesCanvas.Children.Add(_grid.GridOutline);
            }
            if (Spindle != null)
            {
                _opacity = Math.Max(BasicLib.Properties.Settings.Default.Opacity, 1.0 / Spindle.Rosettes.Count);
                _rt.Angle = Spindle.Phase; // rotation to equal phase of spindle


                foreach (Rosette ros in Spindle.Rosettes)
                {
                    if (!ros.Name.Equals(lastRosette))
                    {
                        ro = ros.Outline;
                        ro.StrokeThickness = 1 / _sf;
                        if (ros.Include)
                        {
                            ro.Opacity = _opacity;
                            ro.Fill = new SolidColorBrush(BasicLib.Properties.Settings.Default.FillColor);
                        }
                        else
                        {
                            ro.Opacity = BasicLib.Properties.Settings.Default.Excluded_Opacity;
                            ro.Fill = new SolidColorBrush(BasicLib.Properties.Settings.Default.HiddenColor);
                        }

                        SpindleRosettesCanvas.Children.Add(ro);
                        _rosette_names.Add(ros);
                    }
                }
                // now add outline of last rosette
                if (lastRosette != string.Empty)
                {
                    ro = Spindle.LookupByName(lastRosette).Outline;
                    ro.StrokeThickness = 1 / _sf;
                    ro.Opacity = 1;
                    ro.Fill = new SolidColorBrush(BasicLib.Properties.Settings.Default.FillColor);
                    SpindleRosettesCanvas.Children.Add(ro);
                }
            }
            DrawAxes();
        }

        private void DrawAxes()
        {
            System.Windows.Shapes.Line l = new System.Windows.Shapes.Line();
            l.StrokeThickness = 1 / _sf;
            l.Stroke = System.Windows.Media.Brushes.Red;
            l.X1 = -10;
            l.Y1  = 0;
            l.X2 = 10;
            l.Y2 = 0;
            SpindleRosettesCanvas.Children.Add(l);
            l = new System.Windows.Shapes.Line();
            l.Stroke = System.Windows.Media.Brushes.Red;
            l.StrokeThickness = 1 / _sf;
            l.X1 = 0;
            l.Y1  = -10;
            l.X2 = 0;
            l.Y2 = 10;
            SpindleRosettesCanvas.Children.Add(l);
        }

     
        private void SpindleRosettesCanvas_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0)
                _sf += 0.1;
            else if (e.Delta < 0)
                if (_sf > 0.1)
                    _sf -= 0.1;

            setSF();
            
        }

        private void Home(object sender, RoutedEventArgs e)
        {
            _sf = 1;
            setSF();
            _tt.X = 0;
            _tt.Y = 0;
        }
     
        private void SpindleRosettesCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _start = e.GetPosition(border1);
            _origin = new Point(_tt.X, _tt.Y);
            SpindleRosettesCanvas.CaptureMouse();
        }

        private void SpindleRosettesCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            SpindleRosettesCanvas.ReleaseMouseCapture();
        }

        private void SpindleRosettesCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (SpindleRosettesCanvas.IsMouseCaptured)
            {
                Vector v = _start - e.GetPosition(border1);
               
                _tt.X = _origin.X - v.X;
                _tt.Y = _origin.Y - v.Y;
            }
        }

        public void Clear()
        {
            SpindleRosettesCanvas.Children.Clear();
        }

        private void SpindleRosettesCanvas_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {

            _start = e.GetPosition(border1);
        }

        private void SpindleRosettesCanvas_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
           
        }

        private void Select_Rosette(object sender, RoutedEventArgs e)
        {
            // find Rosette chosen from visual on canvas
            HitTestResult result = VisualTreeHelper.HitTest(this, _start);
            int indx = -1;
            try
            {
                if (result.VisualHit is Shape)
                {
                    Console.WriteLine(result.VisualHit);
                    indx = SpindleRosettesCanvas.Children.IndexOf(result.VisualHit as Shape);
                    Console.WriteLine("rosette index is {0} Name is {1}", indx, Spindle.Rosettes[indx].Name);
                    string rname = Spindle.Rosettes[indx].Name;
                    if (RosetteSelected != null)
                        RosetteSelected(Spindle.Rosettes[indx],new EventArgs());
                    DrawSpindle(rname);

                }
            }
            catch
            {
                Console.WriteLine("Exception null reference indx was {0}",indx);
            }
        }

        private void GridMenuItem_Checked(object sender, RoutedEventArgs e)
        {
            _showgrid = true;
            DrawSpindle(string.Empty);
        }

        private void GridMenuItem_Unchecked(object sender, RoutedEventArgs e)
        {
            _showgrid = false;
            DrawSpindle(string.Empty);
        }

        private void Zoom_In_Click(object sender, RoutedEventArgs e)
        {
            _sf += 0.5;
            setSF();
        }

        private void Zoom_Out_Click(object sender, RoutedEventArgs e)
        {
            _sf -= 0.5;
            setSF();

        }

        private void setSF()
        {
            _st.ScaleX = _st.ScaleY = _sf;
            foreach (Shape s in SpindleRosettesCanvas.Children)
            {
                s.StrokeThickness = 1 / _sf;
            }
        }
    }
}
