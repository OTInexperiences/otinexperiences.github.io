﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Collections.ObjectModel;
using System.Windows.Media.Media3D;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BasicLib.Coordinates;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for OffsetViewer.xaml
    /// </summary>
    public partial class OffsetViewer : UserControl
    {
        ObservableCollection<XYZRAD> _path;

        public OffsetViewer()
        {
            InitializeComponent();
            _path = new ObservableCollection<XYZRAD>();
            PathTab.DataContext = _path;
        }

        public Point3DCollection Path
        {
            set
            {
                _path.Clear();
                foreach (Point3D p in value)
                    _path.Add(new XYZRAD(p));
            }
        }

        internal void ClearPath()
        {
            _path.Clear();
        }
    }
}
