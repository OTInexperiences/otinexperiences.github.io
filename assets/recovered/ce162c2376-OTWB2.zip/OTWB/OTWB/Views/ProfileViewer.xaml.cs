﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BasicLib;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for ProfileViewer.xaml
    /// </summary>
    public partial class ProfileViewer : UserControl
    {
        double _sf;
        TransformGroup _tg;
        ScaleTransform _st;
        TranslateTransform _tt;
        RotateTransform _rt;

        Point _start;
        Point _origin;

        Grid _grid;
        bool _showgrid;
        Range xrange, yrange;

        private Profile _profile;

        public Profile Profile
        {
            get { return _profile; }
            set
            {
                _profile = value;
                Range r1 = _profile.Range1; CalcIncrement(ref r1);
                Range r2 = _profile.Range2; CalcIncrement(ref r2);
                bool recalc = false;
                if (!_grid.Dim1Range.Equals(r1))
                {
                    _grid.Dim1Range = r1;
                    recalc = true;
                }
                if (!_grid.Dim2Range.Equals(r2))
                {
                    _grid.Dim2Range = r2;
                    recalc = true;
                }
                if (recalc)
                {
                    _grid.CreateGrid();
                }
                Console.WriteLine("Grid Profile Range1 {0}", _grid.Dim1Range);
                Console.WriteLine("Grid Profile Range2 {0}", _grid.Dim2Range);
                _showgrid = GridMenuItem.IsChecked;
                DrawProfile();
            }
        }

        void CalcIncrement(ref Range r)
        {
            double l = r.Length;
            if (l <= 1)
                r.Inc = 0.1;
            else if (l <= 10)
                r.Inc = 1;
            else if (l <= 100)
                r.Inc = 10;
            else r.Inc = 20;
        }

        public ProfileViewer()
        {
            InitializeComponent();
            _tg = new TransformGroup();

            _rt = new RotateTransform(0);
            _tg.Children.Add(_rt);

            _st = new ScaleTransform(1, -1, 0.5, 0.5);
            _tg.Children.Add(_st);

            _tt = new TranslateTransform(0, 0);
            _tg.Children.Add(_tt);
            ProfileCanvas.RenderTransform = _tg;
            ProfileCanvas.RenderTransformOrigin = new Point(0.5, 0.5);

            _sf = 1;
            _showgrid = GridMenuItem.IsChecked;
            xrange = new Range(-150, 1, 150);
            yrange = new Range(-20, 1, 20);

            if (_grid == null)
            {
                try
                {
                    _grid = new Grid(Grid.GRIDTYPE.CARTESIAN);
                    _grid.Dim1Range = xrange;
                    _grid.Dim2Range = yrange;
                    _grid.CreateGrid();
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.InnerException.Message);
                }
            }
            DrawProfileAxes(100, 40);
        }

        public void DrawProfile()
        {
            if (_profile != null)
            {
                Shape c = _profile.Outline;
                ProfileCanvas.Children.Clear();
                if (c == null) return;
                ProfileCanvas.Children.Add(c);
            }
            if (_showgrid && _grid.GridOutline != null)
            {
                _grid.GridOutline.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.GridColor);
                _grid.GridOutline.Opacity = BasicLib.Properties.Settings.Default.Grid_Opacity;
                ProfileCanvas.Children.Add(_grid.GridOutline);
            }
           
            DrawProfileAxes(100,40);
        }

        private void Home(object sender, RoutedEventArgs e)
        {
            _sf = 1;
            _st.ScaleY = -_sf;
            _st.ScaleX = _sf;
            _tt.X = _tt.Y = 0;
        }

        private void DrawProfileAxes(double xmax, double ymax)
        {
            System.Windows.Shapes.Line l = new System.Windows.Shapes.Line();
            l.StrokeThickness = 1;
            l.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.AxisColor);
            l.X1 = -xmax;
            l.Y1 = 0;
            l.X2 = xmax;
            l.Y2 = 0;
            ProfileCanvas.Children.Add(l);
            l = new System.Windows.Shapes.Line();
            l.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.AxisColor);
            l.StrokeThickness = 1;
            l.X1 = 0;
            l.Y1 = -ymax;
            l.X2 = 0;
            l.Y2 = ymax;
            ProfileCanvas.Children.Add(l);
        }
        private void ProfileCanvas_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0)
                _sf += 0.1;
            else if (e.Delta < 0)
                if (_sf > 0.1)
                    _sf -= 0.1;

            if (Math.Abs(_sf) > 0.1)
            {
                _st.ScaleX = _sf;
                _st.ScaleY = -_sf;
            }
        }

        private void ProfileCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _start = e.GetPosition(border1);
            _origin = new Point(_tt.X, _tt.Y);
            ProfileCanvas.CaptureMouse();
        }

        private void ProfileCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ProfileCanvas.ReleaseMouseCapture();
        }

        private void ProfileCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (ProfileCanvas.IsMouseCaptured)
            {
                Vector v = _start - e.GetPosition(border1);

                _tt.X = _origin.X - v.X;
                _tt.Y = _origin.Y - v.Y;
              
            }
        }

        private void GridMenuItem_Checked(object sender, RoutedEventArgs e)
        {
            _showgrid = true;
            DrawProfile();
        }

        private void GridMenuItem_Unchecked(object sender, RoutedEventArgs e)
        {
            _showgrid = false;
            DrawProfile();
        }

        private void Zoom_In_Click(object sender, RoutedEventArgs e)
        {
            _st.ScaleX += 0.5;
            _st.ScaleY -= 0.5;
           
           
        }

        private void Zoom_Out_Click(object sender, RoutedEventArgs e)
        {
            if (_st.ScaleX > 0.5)
                _st.ScaleX -= 0.5;
           
            if (_st.ScaleY < -0.5)
                _st.ScaleY += 0.5;
            
        }
    }
}
