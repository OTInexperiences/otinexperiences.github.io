﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Specialized;
using System.Windows.Media.Media3D;


namespace OTWB
{
    /// <summary>
    /// Interaction logic for PathViewer.xaml
    /// </summary>
    public partial class ChuckPathViewer : UserControl
    {
        Chuck _chuck;

        bool _showGrid;
        double _opacity;
        double _sf;

        TransformGroup _tg;
        ScaleTransform _st;
        TranslateTransform _tt;
        RotateTransform _rt;

        Point _start;
        Point _origin;

        public Chuck Chuck
        {
            set
            {
                _chuck = value;
                DrawPath();
                if (_chuck != null)
                  _chuck.PathChanged += new EventHandler(_chuck_PathChanged);
                
            }
        }

        void _chuck_PathChanged(object sender, EventArgs e)
        {
            DrawPath();
        }

        public bool ShowGrid
        {
            get { return _showGrid; }
            set
            {
                _showGrid = value;
                DrawPath();
            }
        }

        public ChuckPathViewer()
        {
            InitializeComponent();
            _opacity = BasicLib.Properties.Settings.Default.Opacity;
            ChuckPathCanvas.RenderTransformOrigin = new Point(0.5, 0.5);
            _tg = new TransformGroup();

            _rt = new RotateTransform(0);
            _tg.Children.Add(_rt);

            _st = new ScaleTransform(1, 1, 0.5, 0.5);
            _tg.Children.Add(_st);

            _tt = new TranslateTransform(0, 0);
            _tg.Children.Add(_tt);
            ChuckPathCanvas.RenderTransform = _tg;
            _sf = 1;
        }

        private void ChuckPathCanvas_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0)
                _sf += 0.1;
            else if (e.Delta < 0)
                if (_sf > 0.1)
                    _sf -= 0.1;

            _st.ScaleX = _sf;
            _st.ScaleY = _sf;
        }

        private void ChuckPathCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _start = e.GetPosition(border1);
            _origin = new Point(_tt.X, _tt.Y);
            ChuckPathCanvas.CaptureMouse();
        }

        private void ChuckPathCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ChuckPathCanvas.ReleaseMouseCapture();
        }

        private void ChuckPathCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (ChuckPathCanvas.IsMouseCaptured)
            {
                Vector v = _start - e.GetPosition(border1);

                _tt.X = _origin.X - v.X;
                _tt.Y = _origin.Y - v.Y;
            }
        }

        private Polyline MakeDrawablePath(Path path)
        {
            Polyline s = new Polyline();
            s.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.ToolPathColor);
            s.Fill = new SolidColorBrush(BasicLib.Properties.Settings.Default.FillColor);
            s.Fill.Opacity = BasicLib.Properties.Settings.Default.Opacity;
            s.StrokeThickness = 1 / _sf;
            foreach (Point3D p3 in path.Points)
            {
                if ( BasicLib.Utilities.isZaxis(_chuck.RotationAxis))
                    s.Points.Add(new Point(p3.X, p3.Y));
                else if (BasicLib.Utilities.isYaxis(_chuck.RotationAxis))
                    s.Points.Add(new Point(p3.X, p3.Z));
                else if (BasicLib.Utilities.isXaxis(_chuck.RotationAxis))
                    s.Points.Add(new Point(p3.Y, p3.Z));
            }
            return s;
        }

        public void DrawPath()
        {
            ChuckPathCanvas.Children.Clear();
            if (_showGrid)
                DrawGrid();
            if (_chuck != null)
            {
                ChuckPathCanvas.Children.Add(MakeDrawablePath(_chuck.Path));                
            }
            DrawAxes();
        }

        private void DrawGrid()
        {
            
        }

        private void DrawAxes()
        {
            System.Windows.Shapes.Line l = new System.Windows.Shapes.Line();
            l.StrokeThickness = 1;
            l.Stroke = System.Windows.Media.Brushes.Red;
            l.X1 = -10;
            l.Y1 = 0;
            l.X2 = 10;
            l.Y2 = 0;
            ChuckPathCanvas.Children.Add(l);
            l = new System.Windows.Shapes.Line();
            l.Stroke = System.Windows.Media.Brushes.Red;
            l.StrokeThickness = 1;
            l.X1 = 0;
            l.Y1 = -10;
            l.X2 = 0;
            l.Y2 = 10;
            ChuckPathCanvas.Children.Add(l);
        }

        private void Home(object sender, RoutedEventArgs e)
        {
            _sf = 1;
            _st.ScaleY = _sf;
            _st.ScaleX = _sf;
            _tt.X = 0;
            _tt.Y = 0;
        }

    }
}
