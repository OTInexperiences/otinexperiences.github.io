﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Media3D;
using System.Collections.Specialized;
using BasicLib;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for Canvas3D.xaml
    /// </summary>
    public partial class Canvas3D : UserControl
    {
        PathList _paths;
        int _hilightID = -1;
        ProjectInfo _pinfo;

        MeshGeometry3D triangleMesh = new MeshGeometry3D();
        private double _sf;
        
        public Canvas3D()
        {
            InitializeComponent();
            GridXYCB.IsChecked = mainViewport.Children.Contains(XYGrid);
            XYGrid.Color = BasicLib.Properties.Settings.Default.GridColor;
            XYGrid.Opacity = (float)BasicLib.Properties.Settings.Default.Grid_Opacity;
        }

        public int HilightPathID
        {
            get { return _hilightID;  }
            set
            {
                try
                {
                    Path3D p3d;
                    if (_hilightID >= 0)
                    {
                        // switch off last hilight
                        p3d = FindPath3D(_hilightID);
                        if (p3d != null)
                            p3d.Color = BasicLib.Properties.Settings.Default.ToolPathColor;
                    }
                   
                    _hilightID = value;
                     if (value >= 0)
                     {
                        // hilight current path
                        p3d = FindPath3D(_hilightID);
                        if (p3d != null)
                            p3d.Color = BasicLib.Properties.Settings.Default.HilightColor;
                      }
                        
                }
                catch { }
            }
        }

        public double MaxWorkPieceRadius { get; set; }

        public ProjectInfo Project
        {
            set
            {
                _pinfo = value;
                if (XYGrid != null)
                    if (XYGrid.Dim1Range != null)
                        XYGrid.Dim1Range.End = _pinfo.MaxWorkPieceRadius;
                    else
                        XYGrid.Dim1Range = new Range(0, 10, _pinfo.MaxWorkPieceRadius);
            }
        }

        public PathList Paths
        {
            set
            {
                _paths = value;
                _paths.CollectionChanged += new NotifyCollectionChangedEventHandler(_paths_CollectionChanged);
                _paths.PathChangedEvent += OnPathChanged;

                CreatePaths();
            }
        }

        private void _paths_CollectionChanged(Object sender, NotifyCollectionChangedEventArgs e)
        {
            // reflect changes in pathlist by removing or adding paths
            // remove non existant paths first
            List<Path3D> nonexistantpathids = new List<Path3D>();
            foreach (Visual3D v in mainViewport.Children)
                if (v is Path3D)
                {
                    if (!PathExists((v as Path3D).Path.ID))
                    {
                        nonexistantpathids.Add(v as Path3D);
                    }
                }
            foreach (Path3D p in nonexistantpathids)
                mainViewport.Children.Remove(p);

            // check to see if we need to add the path
            foreach (Path p in _paths)
            {
                if (!Path3DExists(p.ID))
                {
                    Path3D p3d = new Path3D();
                    p3d.Path = p;
                    mainViewport.Children.Add(p3d);

                    // check if range needs to change
                  
                }
            }
        }

        public static double Distance(Point3D p)
        {
            return Math.Sqrt(p.X * p.X + p.Y * p.Y + p.Z * p.Z);
        }

        void CalcScaleFactor(Path3D p)
        {
            double xRangeLength = p.XRange.Length;
            double yRangeLength = p.YRange.Length;
            double zRangeLength = p.ZRange.Length;

            double rl = Math.Max(xRangeLength, yRangeLength);
            rl = Math.Max(rl, zRangeLength);

            double wl = Math.Max(this.Width, this.Height);
            if (rl > wl)
            {
              
                double newcl = rl / Math.Sin(Utilities.toRadians(this.Camera1.FieldOfView / 2));

                double cl = Distance(this.Camera1.Position);
                double sf = newcl / cl;

                Point3D p3d = this.Camera1.Position;
                p3d.X *= sf;
                p3d.Y *= sf;
                p3d.Z *= sf;
                
            }
            
        }

        private bool PathExists(int id)
        {
            foreach (Path p in _paths)
                if (p.ID == id)
                    return true;
            return false;
        }

        private bool Path3DExists(int id)
        {
            foreach (Visual3D v3d in mainViewport.Children)
                if (v3d is Path3D)
                {
                    if ((v3d as Path3D).Path.ID == id)
                        return true;
                }
            return false;
        }

        private Path3D FindPath3D(int id)
        {
            foreach (Visual3D v3d in mainViewport.Children)
                if (v3d is Path3D)
                {
                    if ((v3d as Path3D).Path.ID == id)
                        return (v3d as Path3D);
                }
            return null;
        }

        private Path FindPath(int id)
        {
            foreach (Path p in _paths)
                if (p.ID == id)
                    return p;
            return null;
        }

        public void OnPathChanged(object sender, PathChangedEventArgs pc)
        {
            // do something to redraw path
        }

        private void Home(object sender, RoutedEventArgs e)
        {
            _sf = 0;
            setSF();
            hscroll.Value = 0;
            vscroll.Value = 0;
           
            XYGrid.Color = BasicLib.Properties.Settings.Default.GridColor;
            XYGrid.Opacity = BasicLib.Properties.Settings.Default.Grid_Opacity;

        }

        void CreatePaths()
        {
            foreach (Path p in _paths)
            {
                Path3D p3d = new Path3D();
                p3d.Path = p;
                mainViewport.Children.Add(p3d);
            }
        }

        private void ClearViewport()
        {
            ModelVisual3D m;
            for (int i = mainViewport.Children.Count - 1; i >= 0; i--)
            {
                m = (ModelVisual3D)mainViewport.Children[i];
                if (m.Content is DirectionalLight == false)
                    mainViewport.Children.Remove(m);
            }
        }

        private void DockPanel_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0)
                _sf += 0.1;
            else if (e.Delta < 0)
                    _sf -= 0.1;
            setSF();
        }

        private void setSF()
        {
            CameraTranslateTransform.OffsetX = _sf * Camera1.LookDirection.X;
            CameraTranslateTransform.OffsetY = _sf * Camera1.LookDirection.Y;
            CameraTranslateTransform.OffsetZ = _sf * Camera1.LookDirection.Z;
        }

        private void Zoom_In_Click(object sender, RoutedEventArgs e)
        {
            _sf += 0.1;
            setSF();
        }

        private void Zoom_Out_Click(object sender, RoutedEventArgs e)
        {
            _sf -= 0.1;
            setSF();

        }

        private void GridMenuItem_Checked(object sender, RoutedEventArgs e)
        {
            if (XYGrid != null) 
                mainViewport.Children.Add(XYGrid);
        }

        private void GridMenuItem_Unchecked(object sender, RoutedEventArgs e)
        {
            mainViewport.Children.Remove(XYGrid);
        }

        private void Home()
        {

        }

        private void ViewXY(object sender, RoutedEventArgs e)
        {
            Camera1.Position = new Point3D(0, 0, BasicLib.Properties.Settings.Default.DefaultCameraDistance);
            Camera1.LookDirection = new Vector3D(0, 0, -BasicLib.Properties.Settings.Default.DefaultCameraDistance);
            hscroll.Value = 0;
            vscroll.Value = 0;
        }

        private void ViewXZ(object sender, RoutedEventArgs e)
        {
            Camera1.Position = new Point3D(0, BasicLib.Properties.Settings.Default.DefaultCameraDistance, 0);
            Camera1.LookDirection = new Vector3D(0, -BasicLib.Properties.Settings.Default.DefaultCameraDistance, 0);
            hscroll.Value = 0;
            vscroll.Value = 0;
        }

        private void ViewYZ(object sender, RoutedEventArgs e)
        {
            Camera1.Position = new Point3D(BasicLib.Properties.Settings.Default.DefaultCameraDistance, 0, 0);
            Camera1.LookDirection = new Vector3D(-BasicLib.Properties.Settings.Default.DefaultCameraDistance, 0, 0);
            hscroll.Value = 0;
            vscroll.Value = 0;
        }

     
        private void GridXYCB_Checked(object sender, RoutedEventArgs e)
        {
            if (!mainViewport.Children.Contains(XYGrid))
                mainViewport.Children.Add(XYGrid); 
        }

        private void GridXYCB_Unchecked(object sender, RoutedEventArgs e)
        {
            if (mainViewport.Children.Contains(XYGrid))
                mainViewport.Children.Remove(XYGrid);
        }

        private void GridYZCB_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void GridXZCB_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void GridXZCB_Unchecked(object sender, RoutedEventArgs e)
        {
            mainViewport.Children.Remove(XYGrid);
        }

    }
}
