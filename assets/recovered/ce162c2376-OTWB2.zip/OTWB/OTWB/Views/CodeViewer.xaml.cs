﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for CodeViewer.xaml
    /// </summary>
    public partial class CodeViewer : UserControl
    {
        GcodeProgramItem _pgm;

        public ProjectInfo Info { get; set; }
        public GcodeProgramItem Gcode 
        {
            get { return _pgm; }
            set{
                _pgm = value;
                if (_pgm != null)
                    DisplayCode();
            }
        }

        private void DisplayCode()
        {
            GcodeText.Text = "";
            if ((_pgm.ProgramType == GcodeProgramType.TEMPLATE) || 
                (_pgm.ProgramType == GcodeProgramType.TEXT))
                GcodeText.Text = _pgm.Text;
            else
            { // it is gcode
                if (_pgm.Program.Count > 0)
                    GcodeText.Text = _pgm.Program.RenderText();
            }
            
        }

        public CodeViewer()
        {
            InitializeComponent();
        }

        private void ClearGCode_Click(object sender, RoutedEventArgs e)
        {
            if (_pgm.ProgramType == GcodeProgramType.TEMPLATE)
                _pgm.Text = string.Empty;
            else
                _pgm.Program.Clear();
            DisplayCode();
        }

        private void WriteText()
        {
            string fn = System.IO.Path.Combine(BasicLib.Properties.Settings.Default.TemplateFolder, _pgm.Name);
            fn = System.IO.Path.ChangeExtension(fn, BasicLib.Properties.Settings.Default.TemplateExt);

            using (StreamWriter sw = new StreamWriter(fn))
            {
                 sw.WriteLine(GcodeText.Text);
            }
            // now update program text
            _pgm.Text = GcodeText.Text;
        }

        private void SaveGCode_Click(object sender, RoutedEventArgs e)
        {
            if (_pgm.ProgramType == GcodeProgramType.TEMPLATE)
            {
                WriteText();
            }
            else
            {
                string fn = BasicLib.Utilities.ExportFilename("Gcode",_pgm.Name,
                                                             BasicLib.Properties.Settings.Default.ProjectsFolder,
                                                             BasicLib.Properties.Settings.Default.ExecutableGcodeFileExtension);
                if (fn.Length > 0)
                {
                    string txt = (_pgm.ProgramType == GcodeProgramType.TEXT)
                                ? _pgm.Text
                                : _pgm.Program.RenderText();
                   
                    using (StreamWriter sw = new StreamWriter(fn))
                    {
                         sw.WriteLine(txt);
                    }
                }
            }
        }

        private void SaveAs_Click(object sender, RoutedEventArgs e)
        {
            string newname = BasicLib.Utilities.ExportFilename("Template",
                                                               "New Name",
                                                               BasicLib.Properties.Settings.Default.TemplateFolder,
                                                               BasicLib.Properties.Settings.Default.TemplateExt);
            if (newname != string.Empty)
            {
                using (StreamWriter sw = new StreamWriter(newname))
                {
                    sw.WriteLine(GcodeText.Text);
                }
                _pgm.Name = System.IO.Path.GetFileNameWithoutExtension(newname);
            }
        }
    }
}
