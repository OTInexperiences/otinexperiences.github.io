﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using BasicLib;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for SurfaceViewer.xaml
    /// </summary>
    public partial class SurfaceViewer : UserControl
    {
        public SurfaceManager Manager { get; set; }

        double _opacity;
        double _sf;
        TransformGroup _tg;
        ScaleTransform _st;
        TranslateTransform _tt;
        RotateTransform _rt;

        Point _start;
        Point _origin;

        ObservableCollection<Polyline> _pathlist;

        public SurfaceViewer()
        {
            InitializeComponent();
            _opacity = BasicLib.Properties.Settings.Default.Opacity;
            _tg = new TransformGroup();

            _rt = new RotateTransform(0);
            _tg.Children.Add(_rt);

            _st = new ScaleTransform(1, 1, 0.5, 0.5);
            _tg.Children.Add(_st);

            _tt = new TranslateTransform(0, 0);
            _tg.Children.Add(_tt);
            SurfaceCanvas.LayoutTransform = _tg;
            _sf = 1;
            _pathlist = new ObservableCollection<Polyline>();
            DrawAxes(100, 100);
        }

       

        private void Home()
        {
            _sf = 1;
            _st.ScaleY = _sf;
            _st.ScaleX = _sf;
        }

        private void DrawAxes(double xmax, double ymax)
        {
            System.Windows.Shapes.Line l = new System.Windows.Shapes.Line();
            l.StrokeThickness = 1;
            l.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.AxisColor);
            l.X1 = -xmax;
            l.Y1 = 0;
            l.X2 = xmax;
            l.Y2 = 0;
            SurfaceCanvas.Children.Add(l);
            l = new System.Windows.Shapes.Line();
            l.Stroke = System.Windows.Media.Brushes.Red;
            l.StrokeThickness = 1;
            l.X1 = 0;
            l.Y1 = -ymax;
            l.X2 = 0;
            l.Y2 = ymax;
            SurfaceCanvas.Children.Add(l);
        }
       

        private void SurfaceCanvas_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0)
                _sf += 0.1;
            else if (e.Delta < 0)
                if (_sf > 0.1)
                    _sf -= 0.1;

            _st.ScaleX = _sf;
            _st.ScaleY = _sf;
        }

        private void SurfaceCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void SurfaceCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void SurfaceCanvas_MouseMove(object sender, MouseEventArgs e)
        {

        }

        
    }
}
