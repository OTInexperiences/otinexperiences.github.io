﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Specialized;
using System.Windows.Media.Media3D;
using BasicLib;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for PathViewer.xaml
    /// </summary>
    public partial class PathViewer : UserControl
    {
        PathList _paths;
        Nullable<int> _hilight = null;

        double _opacity;
        double _sf;

        TransformGroup _tg;
        ScaleTransform _st;
        TranslateTransform _tt;
        RotateTransform _rt;

        Point _start;
        Point _origin;
        Grid _grid;
        Shape _wplimit;
        ProjectInfo _pinfo;
        bool _showGrid;
        bool _showWork;

        public ProjectInfo Project 
        {
            set
            {
                _pinfo = value;
                if (_grid != null)
                    if (_grid.Dim1Range != null)
                        _grid.Dim1Range.End = _pinfo.MaxWorkPieceRadius;
                    else
                        _grid.Dim1Range = new Range(0, 10, _pinfo.MaxWorkPieceRadius);
            }
        }

        public PathList Paths 
        {
            set { 
                _paths = value;
                _paths.CollectionChanged +=new NotifyCollectionChangedEventHandler(_paths_CollectionChanged);
                _paths.PathChangedEvent += OnPathChanged;
               
                DrawPaths();
            } 
        }

        public Nullable<int> HilightPathIndex {
            get { return _hilight.HasValue ? _hilight : null; }
            set
            {
                Polyline pl;
                if (value >= 0 && value < PathCanvas.Children.Count)
                {
                    // first switch off last hilight
                    try
                    {
                        if (_hilight.HasValue && _hilight.Value != value)
                        {
                            pl = (Polyline)PathCanvas.Children[_hilight.Value];
                            pl.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.ToolPathColor);
                        }
                        _hilight = value;
                        pl = (Polyline)PathCanvas.Children[_hilight.Value];
                        pl.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.HilightColor);
                    }
                    catch { }
                }
            }
        }

        public double MaxWorkPieceRadius { get; set; }

        public PathViewer()
        {
            InitializeComponent();
            _opacity = BasicLib.Properties.Settings.Default.Opacity;
            PathCanvas.RenderTransformOrigin = new Point(0.5, 0.5);
            _tg = new TransformGroup();

            _rt = new RotateTransform(0);
            _tg.Children.Add(_rt);

            _st = new ScaleTransform(1, 1, 0.5, 0.5);
            _tg.Children.Add(_st);

            _tt = new TranslateTransform(0, 0);
            _tg.Children.Add(_tt);
            PathCanvas.RenderTransform = _tg;
            _sf = 1;
            _hilight = null;

            if (_grid == null)
            {
                try
                {
                    _grid = new Grid(Grid.GRIDTYPE.RADIAL);
                    Range r = new Range(0, 10, OTWB.Properties.Settings.Default.DefaultMaxWorkpieceRadius);
                    if (_pinfo != null)
                        r.End = _pinfo.MaxWorkPieceRadius;
                    _grid.Dim1Range = r;
                    _grid.Dim2Range = new BasicLib.Range(0, 10, 360);
                    _grid.CreateGrid();
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.InnerException.Message);
                }
            }
            _wplimit = WorkPieceLimit;
            
        }

        private void _paths_CollectionChanged (Object sender, NotifyCollectionChangedEventArgs e)
        {
            Console.WriteLine("Path collection Changed");
            DrawPaths();
        }

        private void PathCanvas_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0)
                _sf += 0.1;
            else if (e.Delta < 0)
                if (_sf > 0.1)
                    _sf -= 0.1;

            _st.ScaleX = _sf;
            _st.ScaleY = _sf;
        }

        private void PathCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _start = e.GetPosition(border1);
            _origin = new Point(_tt.X, _tt.Y);
            PathCanvas.CaptureMouse();
        }

        private void PathCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PathCanvas.ReleaseMouseCapture();
        }

        private void PathCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (PathCanvas.IsMouseCaptured)
            {
                Vector v = _start - e.GetPosition(border1);

                _tt.X = _origin.X - v.X;
                _tt.Y = _origin.Y - v.Y;
            }
        }

        private Polyline MakeDrawablePath(Path p)
        {
            Polyline s = new Polyline();
            s.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.ToolPathColor);
            s.Fill = new SolidColorBrush(BasicLib.Properties.Settings.Default.FillColor);
            s.Fill.Opacity = BasicLib.Properties.Settings.Default.Opacity;
            s.StrokeThickness = 1;
            foreach (Point3D p3 in p.Points)
                
                s.Points.Add(new Point(p3.X, p3.Y));
            return s;
        }

        public void DrawPaths()
        {
            PathCanvas.Children.Clear();
            if (_showWork && _wplimit != null)
                PathCanvas.Children.Add(_wplimit);
            if (_showGrid && _grid.GridOutline != null)
            {
                PathCanvas.Children.Add(_grid.GridOutline);
            }
            // now add max diameter of work
            foreach (Path p in _paths)
            {
                Polyline pl = MakeDrawablePath(p);
                //pl.LayoutTransform = _tg;
                PathCanvas.Children.Add(pl); 
            }
            DrawAxes();
        }

        private System.Windows.Shapes.Path WorkPieceLimit
        {
            get
            {
                System.Windows.Shapes.Path path = new System.Windows.Shapes.Path();
                EllipseGeometry eg = new EllipseGeometry(new Point(0, 0), 150, 150);
                path.Data = eg;
                path.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.WorkpieceColor);
                path.Fill = path.Stroke.CloneCurrentValue();
                path.Fill.Opacity = BasicLib.Properties.Settings.Default.Opacity;
                return path;
            }
        }

        private void DrawAxes()
        {
            System.Windows.Shapes.Line l = new System.Windows.Shapes.Line();
            l.StrokeThickness = 1;
            l.Stroke = System.Windows.Media.Brushes.Red;
            l.X1 = -10;
            l.Y1 = 0;
            l.X2 = 10;
            l.Y2 = 0;
            PathCanvas.Children.Add(l);
            l = new System.Windows.Shapes.Line();
            l.Stroke = System.Windows.Media.Brushes.Red;
            l.StrokeThickness = 1;
            l.X1 = 0;
            l.Y1 = -10;
            l.X2 = 0;
            l.Y2 = 10;
            PathCanvas.Children.Add(l);
        }

        private void Home(object sender, RoutedEventArgs e)
        {
            _sf = 1;
            _st.ScaleY = _sf;
            _st.ScaleX = _sf;
            _tt.X = 0;
            _tt.Y = 0;
        }

        public void OnPathChanged(object sender, PathChangedEventArgs pc)
        {
            DrawPaths();
        }

        private void GridMenuItem_Checked(object sender, RoutedEventArgs e)
        {
            _showGrid = true;
            DrawPaths();
        }

        private void GridMenuItem_Unchecked(object sender, RoutedEventArgs e)
        {
            _showGrid = false;
            DrawPaths();
        }

        private void WPMenuItem_Checked(object sender, RoutedEventArgs e)
        {
            _showWork = true;
            DrawPaths();
        }

        private void WPMenuItem_Unchecked(object sender, RoutedEventArgs e)
        {
            _showWork = false;
            DrawPaths();
        }

        private void Zoom_In_Click(object sender, RoutedEventArgs e)
        {
            _st.ScaleX += 0.5;
            _st.ScaleY += 0.5;
        }

        private void Zoom_Out_Click(object sender, RoutedEventArgs e)
        {
            _st.ScaleX -= 0.5;
            _st.ScaleY -= 0.5;
        }

    }
}
