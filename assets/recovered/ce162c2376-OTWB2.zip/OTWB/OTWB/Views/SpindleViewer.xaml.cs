﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for SpindleViewer.xaml
    /// </summary>
    public partial class SpindleViewer : UserControl
    {
        Spindle _spindle;

        public SpindleViewer()
        {
            InitializeComponent();
        }

        public RosettesDisplay Rosettes_Display
        {
            get { return RosettesDisplay1; }
        }

        public Spindle Spindle
        {
            get { return _spindle; }
            set
            {
                _spindle = value;
                RosettesDisplay1.Spindle = value;
                SpindleOutline1.Spindle = value;
                DrawOutline();
                DrawRosettes(string.Empty);
            }
        }

        public void DrawOutline()
        {
            SpindleOutline1.DrawOutline();
        }

        public void DrawRosettes(string last_rosette)
        {
            RosettesDisplay1.DrawSpindle(last_rosette);
        }
    }
}
