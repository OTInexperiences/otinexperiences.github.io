﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BasicLib;
using System.Diagnostics;
using System.Collections.ObjectModel;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for SpindleEditor.xaml
    /// </summary>
    public partial class SpindleOutline : UserControl
    {
        double _opacity;
        double _sf;
        TransformGroup _tg;
        ScaleTransform _st;
        TranslateTransform _tt;
        RotateTransform _rt;

        Point _start;
        Point _origin;
        Grid _grid;
        bool _showgrid;

       public Spindle Spindle { get; set; }
         

        public SpindleOutline()
        {
            InitializeComponent();
            // set transform dependant on width and height
            _opacity = BasicLib.Properties.Settings.Default.Opacity;
            _tg = new TransformGroup();
         
            _rt = new RotateTransform(0);
            _tg.Children.Add(_rt);

            _st = new ScaleTransform(1, 1, 0.5, 0.5);
            _tg.Children.Add(_st);

            _tt = new TranslateTransform(0, 0);
            _tg.Children.Add(_tt);
            SpindleCanvas.RenderTransform = _tg;
            SpindleCanvas.RenderTransformOrigin = new Point(0.5, 0.5);
            _sf = 1;
           
            slider1.Maximum = OTWB.Properties.Settings.Default.MaxTurns;
            slider1.Minimum = 1;
            slider1.Value  = 1.0;
            _showgrid = GridMenuItem.IsChecked;
            if (_grid == null)
            {
                try
                {
                    _grid = new Grid(Grid.GRIDTYPE.RADIAL);
                    double maxrad = 200;
                    if (Spindle != null)
                        maxrad = Spindle.MaxRadius + 10;
                    Range r = new Range(0, 10, maxrad);
                    _grid.Dim1Range = r;
                    _grid.Dim2Range = new BasicLib.Range(0, 10, 360);
                    _grid.CreateGrid();
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.InnerException.Message);
                }
            }
        }

        public void DrawOutline()
        {
            SpindleCanvas.Children.Clear();
            //_rt.Angle = Spindle.Phase; // rotation to equal phase of spindle
            if (Spindle != null)
            {
                Spindle.CreateOutline();
                if (_showgrid && _grid.GridOutline != null)
                {
                    double r = Spindle.MaxRadius;
                    if (_grid.Dim1Range.End != r)
                    {
                        _grid.Dim1Range.End = r + 20;
                        _grid.CreateGrid();
                    }
                    _grid.GridOutline.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.GridColor);
                    _grid.GridOutline.StrokeThickness = 1 / _sf;
                    SpindleCanvas.Children.Add(_grid.GridOutline);
                }
                Shape so = Spindle.Outline;
                so.Stroke.Opacity = 1;
                so.StrokeThickness = 1 / _sf;
                SpindleCanvas.Children.Add(so);
            }
            DrawAxes();
        }

      

        private void DrawAxes()
        {
            System.Windows.Shapes.Line l = new System.Windows.Shapes.Line();
            l.StrokeThickness = 1 / _sf;
            l.Stroke = System.Windows.Media.Brushes.Red;
            l.X1 = -10;
            l.Y1  = 0;
            l.X2 = 10;
            l.Y2 = 0;
            SpindleCanvas.Children.Add(l);
            l = new System.Windows.Shapes.Line();
            l.Stroke = System.Windows.Media.Brushes.Red;
            l.StrokeThickness = 1 / _sf;
            l.X1 = 0;
            l.Y1  = -10;
            l.X2 = 0;
            l.Y2 = 10;
            SpindleCanvas.Children.Add(l);
        }

     
        private void SpindleCanvas_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0)
                _sf += 0.1;
            else if (e.Delta < 0)
                if (_sf > 0.1)
                    _sf -= 0.1;

            setSF();
            
        }

        private void Home(object sender, RoutedEventArgs e)
        {
            _sf = 1;
            setSF();
            _tt.X = 0;
            _tt.Y = 0;
            slider1.SmallChange = 1;
            slider1.LargeChange = 10;
            slider1.TickFrequency = 1;
            slider1.TickPlacement = System.Windows.Controls.Primitives.TickPlacement.TopLeft;
            slider1.IsSnapToTickEnabled = true;
            slider1.Maximum = OTWB.Properties.Settings.Default.MaxTurns;
            slider1.Value = 1;
        }
     
        private void SpindleCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
           
            _start = e.GetPosition(border1);
            _origin = new Point(_tt.X, _tt.Y);
            SpindleCanvas.CaptureMouse();
        }

        private void SpindleCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            SpindleCanvas.ReleaseMouseCapture();
        }

        private void SpindleCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (SpindleCanvas.IsMouseCaptured)
            {
                Vector v = _start - e.GetPosition(border1);
               
                _tt.X = _origin.X - v.X;
                _tt.Y = _origin.Y - v.Y;
                //System.Diagnostics.Debug.Print("tt x:{0} y:{1}", _tt.X, _tt.Y);
            }
        }

        private void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (Spindle != null)
            {

                Spindle.AngleRange.End = slider1.Value * 360;
                DrawOutline();
            }
        }

        private void GridMenuItem_Checked(object sender, RoutedEventArgs e)
        {
            _showgrid = true;
            DrawOutline();
        }

        private void GridMenuItem_Unchecked(object sender, RoutedEventArgs e)
        {
            _showgrid = false;
            DrawOutline();
        }

        private void Zoom_In_Click(object sender, RoutedEventArgs e)
        {
            _sf += 0.5;
            setSF();
        }

        private void Zoom_Out_Click(object sender, RoutedEventArgs e)
        {
            _sf -= 0.5;
            setSF();
            
        }

        private void setSF()
        {
            _st.ScaleX = _st.ScaleY = _sf;
            foreach (Shape s in SpindleCanvas.Children)
            {
                s.StrokeThickness = 1 / _sf;
            }
        }
    }
}
