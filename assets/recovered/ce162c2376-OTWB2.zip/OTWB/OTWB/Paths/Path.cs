﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Media.Media3D;
using System.Linq;
using System.Text;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows;
using System.ComponentModel;
using BasicLib;

namespace OTWB
{
   

    public class Path
    {
        [Browsable(true)]
        [DisplayName("Path ID")]
        public int ID { get; set; }

        [Browsable(true)]
        [ReadOnly(true)]
        public int Count { get { return Points.Count; } }

        [Browsable(true)]
        [ReadOnly(true)]
        [DisplayName("Tool Position")]
        public double ToolPosition { get; set; }

        [Browsable(true)]
        public Point3DCollection Points { get; set; }

        public Path(int id)
        {
            Points = new Point3DCollection();
            ID = id;
        }

        public Path(int id, Polygon s)
        {
            Points = new Point3DCollection();
            foreach (Point p3 in s.Points)
                Points.Add(new Point3D(p3.X, p3.Y,0));
        }

        public void Add(Point3D pt)
        {
            Points.Add(pt);
        }

        [Browsable(true)]
        [DisplayName("Radial range")]
        public Range RadialRange
        {
            get
            {
                Range range = new Range(0, 0, double.MinValue);
                foreach (Point3D p in Points)
                {
                    double r = Cylindrical.CalcRadius(p);
                    if (range.Start > r)
                        range.Start = r;
                    if (range.End < r)
                        range.End = r;
                }
                return range;
            }
        }

        public Polyline Outline2D
        {
            get
            {
                Polyline s = new Polyline();
                s.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.ToolPathColor);
                s.Fill = new SolidColorBrush(BasicLib.Properties.Settings.Default.FillColor);
                s.StrokeThickness = 1;
                foreach (Point3D p in Points)
                {
                    s.Points.Add(new Point(p.X, p.Y));
                }

                return s;
            }
        }

        public void ScaleRadiusOfPath(double sf)
        {
           Point3DCollection np = new Point3DCollection();
           foreach (Point3D p in Points)
           {
              np.Add(new Point3D(sf * p.X, sf * p.Y, p.Z));
           }
           Points = np;
        }

        public void Rotate(AXIS axis, double angle)
        {
            Vector3D v = Utilities.Unit(axis);
            Point3DCollection np = new Point3DCollection();
            AxisAngleRotation3D tr = new AxisAngleRotation3D(v, angle);
            RotateTransform3D t = new RotateTransform3D(tr);
            foreach (Point3D p in Points)
            {
                Point3D pp = t.Transform(p);
                np.Add(pp);
            }
            Points = np;
        }

        internal void LayOnSurface(SurfaceManager _surfman)
        {
            for (int indx = 0; indx < Points.Count; indx++ )
            {
                Point3D p = Points[indx];
                Console.WriteLine("Old p is {0}", p);
                p.Z += _surfman.Surface.Depth(p);
                Console.WriteLine("New p is {0}", p);
                Points[indx] = p;
            }
        }
    }
}
