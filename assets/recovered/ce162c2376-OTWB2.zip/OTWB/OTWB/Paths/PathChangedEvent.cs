﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OTWB
{
    public class PathChangedEventArgs : EventArgs
    {
        Path ThePath { get; set; }

        public PathChangedEventArgs(Path p)
        {
            ThePath = p;
        }
    }
}
