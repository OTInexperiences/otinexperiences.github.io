﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;
using System.Windows;
using System.ComponentModel;
using System.Windows.Controls.Primitives;
using System.Activities.Presentation.PropertyEditing;
using PropertyTools.Wpf;
using BasicLib;

namespace OTWB
{
  
    public class PathList : ObservableCollection<Path>
    {
        public EventHandler<PathChangedEventArgs> PathChangedEvent;

        public PathList() : base() { }

        [Browsable(true)]
        [Category("Data")]
        [ReadOnly(true)]
        [DisplayName("Number of Paths")]
        public int NumPaths
        {
            get { return base.Count; }
        }

        public Polyline GetShape(int indx)
        {
            //Polyline s = new Polyline();
            //s.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.ToolPathColor);
            //s.Fill = new SolidColorBrush(BasicLib.Properties.Settings.Default.FillColor);
            //s.StrokeThickness = 1;
            //foreach (Point3D p in this[indx].Points)
            //{
            //    s.Points.Add(new Point(p.X,p.Y));
            //}

            return this[indx].Outline2D;
        }

        public void ScaleRadiusOfPath(int indx)
        {
            if (indx > this.Count) return;
            Range range = this[indx].RadialRange;
            RadiusChooser rd = new RadiusChooser();
            rd.PathStats = range;
            Nullable<bool> ok = rd.ShowDialog();
            if (ok.HasValue && ok.Value && rd.ChosenRadius > 0)
            {
                double sf = rd.ChosenRadius / range.End;
                this[indx].ScaleRadiusOfPath(sf);

                if (PathChangedEvent != null)
                    PathChangedEvent(this,new PathChangedEventArgs(this[indx]));
            }            
        }

        public void RotatePath(int indx)
        {
            if (indx > this.Count) return;
            RotationChooser rd = new RotationChooser();
            Nullable<bool> ok = rd.ShowDialog();
            if (ok.HasValue && ok.Value)
            {
                this[indx].Rotate(rd.ChosenAxis, rd.ChosenAngle);
                if (PathChangedEvent != null)
                    PathChangedEvent(this, new PathChangedEventArgs(this[indx]));
            }            
        }

        internal void LayOnSurface(int indx, SurfaceManager _surfman)
        {
            if (indx > this.Count) return;
            this[indx].LayOnSurface(_surfman);
        }
    }
}
