
using System;
using System.ComponentModel;
using System.Xml.Serialization;
using BasicLib;

namespace OTWB
{
	
	/// <summary>
	/// Class holding data about machining values
	/// </summary>
	[Serializable]
	[XmlRoot("MachiningData")]
	public class MachiningData
	{
		public static string TraceToolName = "zero";
		
			
		public MachiningData()
		{
			RoughCut = 1.0;		// assume mm
			FinishCut = 0.5;	// assume equal to maxcut 
			SafeHeight = 10.0;
			FeedRate = 1.0f;
			InverseFeedRate = 1.0;
			Units = UNITS.MM;
		    AssumedSurfaceDepth = 0;
            CutterOverlap = 0;
		}
		
		[XmlElement("Feed_Rate")]
        [DisplayName("Feed Rate")]
        [Browsable(true)]
		public double FeedRate {get; set; }
			

		[XmlElement("Inverse_Feed_Rate")]
        [DisplayName("Inverse Feed Rate")]
        [Browsable(true)]
		public double InverseFeedRate {get; set; }


        [XmlElement("Finish_Cut_Depth")]
        [DisplayName("Finish cut depth")]
        [Browsable(true)]
        public double FinishCut { get; set; }
		

		[XmlElement("Rough_Cut_Depth")]
        [DisplayName("Rough cut depth")]
        [Browsable(true)]
		public double RoughCut { get; set; }
			

		[XmlElement("Safe_Height")]
        [DisplayName("Safe Height")]
        [Browsable(true)]
		public double SafeHeight { get; set; }
		
		[XmlElement("Cutter_Overlap")]
        [DisplayName("Cutter Overlap")]
        [Browsable(true)]
		public double CutterOverlap { get; set; }
					
		[XmlElement("Units")]
        [Browsable(true)]
		public UNITS Units { get; set; }

        [Browsable(true)]
        [DisplayName("Assumed surface depth")]
		public double AssumedSurfaceDepth { get; set; }
			
		
	
	}
}
