using System;
using System.Text;
using System.Collections.ObjectModel;
using BasicLib;

namespace OTWB
{
	
	
	public class CodeList  : ObservableCollection<Code>
	{
		
		public CodeList() : base()
		{
		}
		
		public CodeList(params Code[] clist) : base()
		{
			if (clist.Length > 0 )
				for(int i=0; i < clist.Length; i++)
					this.Add(clist[i]);	
		}
		
		public void AddSeparator()
		{
			this.Add(Code.MkComment("----------------------------------------"));
		}
		
		public void AddComment(string comment)
		{
			this.Add(Code.MkComment(comment));
		}
		
		public void EmptyLine()
		{
			this.Add(new Code());	
		}
		
		public Code Last()
		{
			if (Count == 0)
				return null;
			else
				return this[this.Count - 1];	
		}
		
		public bool Empty
		{
			get { return Count == 0 ; }	
		}

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Code c in this)
            {
                sb.Append(c.ToString()).Append("\n");
            }
            return sb.ToString();
        }
	}
}
