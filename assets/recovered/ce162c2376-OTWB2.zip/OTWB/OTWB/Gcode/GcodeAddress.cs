
using System;
using System.Xml.Serialization;

namespace OTWB
{
	public class GcodeAddress
	{
		string _value;
		bool _isint;
		
		public GcodeAddress()
		{
			_value = String.Empty;
			_isint = false;
		}
		
		public GcodeAddress(int a)
		{
			_value = a.ToString();
			_isint = true;
		}
		
		public GcodeAddress(string a)
		{
			_value = a;
			_isint = false;
		}
		
		public bool Valid
		{
			get { return _value != string.Empty; }	
		}
		
		public bool isInt
		{
			get { return _isint; }	
		}
		
		public object Value
		{
			get {
					return _value;
			}
			
			set {
				_value = value.ToString();
				_isint = value is int;
			}
		}
		
		public int ToInt()
		{
			if (Valid)
				return ((_isint) ? int.Parse(_value) : -1);	
			else
				return -1;
		}
		
		public override string ToString()
		{
			if (isInt)
				return _value;
			else
				return string.Format("<{0}>",_value);
		}
	
	}
	
}
