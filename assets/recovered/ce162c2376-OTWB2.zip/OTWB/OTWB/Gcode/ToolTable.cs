//  
//  Copyright (C) 2009 Alan Battersby
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
// 

using System;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Xml.Serialization;

namespace OTWB
{
	
	[XmlRoot("ToolInformation")]
	[Serializable]
	public class ToolInfo
	{
		double _diameter;
		double _length;
		string _name;
		
		[XmlElement("Diameter")]
        [Browsable(true)]
		public double Diameter {
			get {
					return _diameter;
			}
			set {
					_diameter = value;
			}
		}

		[XmlElement("Length")]
        [Browsable(true)]
		public double Length {
			get {
				return _length;
			}
			set {
				_length = value;
			}
		}	
		
		[XmlElement("Name")]
        [Browsable(true)]
		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}
		
		public ToolInfo()
		{
			_name="zero";
			_diameter = _length = 0;	
		}
		
		public ToolInfo(string name, double dia, double len)
		{
			_name = name;
			_diameter = dia;
			_length = len;
		}
	}
	
	[Serializable]
	public class ToolTable : ObservableCollection<ToolInfo>
	{	
		bool _changed;
		
		public bool Changed
		{
			get { return _changed; }	
			set { _changed = value; }
		}
		
		public ToolTable() : base(){ _changed = false; }
		
	
		public double ToolDiameter(string name)
		{
			foreach (ToolInfo ti in this)
			{
				if (ti.Name == name)
					return ti.Diameter;
			}
			return 0;	    
		}
		
		public double ToolLength(string name)
		{
			foreach (ToolInfo ti in this)
			{
				if (ti.Name == name)
					return ti.Length;
			}
			return 0;	
	
		}
		
		public bool ToolPresent(string name)
		{
			foreach (ToolInfo ti in this)
			{
				if (ti.Name == name)
					return true;
			}
			return false;	
		}
	
		public int IndexOf (string toolname)
		{
			foreach (ToolInfo ti in this)
			{
				if (ti.Name == toolname)
					return this.IndexOf(ti);
			}
			return -1;
		}
		
		public new void Add (ToolInfo item)
		{
            if (IndexOf(item.Name) > 0)
            {
                item.Name = string.Format("{0}_({1})", item.Name, IndexOf(item.Name));
            } 
			base.Add(item);
            _changed = true;
		}

		public  bool Remove (string toolname)
		{
			int indx = IndexOf(toolname);
			if (indx < 0)
				return false;
			else {
				base.RemoveAt(indx);
				_changed = true;
				return true;
			}
		}

		public void changeName(string from, string to)
		{
			int indx = IndexOf(from);
			if (indx < 0)
				return;
			else
				this[indx].Name = to;
		}
		
		public void changeDiameter(string toolname, double dia)
		{
			int indx = IndexOf(toolname);
			if (indx < 0)
				return;
			else
				this[indx].Diameter = dia;
		}
		
		public void changeLength(string toolname, double len)
		{
			int indx = IndexOf(toolname);
			if (indx < 0)
				return;
			else
				this[indx].Length = len;
		}
		
	}
}
