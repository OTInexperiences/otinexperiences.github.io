
using System;
using System.Text;
using System.Collections.ObjectModel;

namespace OTWB
{


	public class GcodeProgram : ObservableCollection<CodeList>
	{

		public GcodeProgram () : base()
		{
		}

        public ObservableCollection<string> RenderTextList()
        {
            ObservableCollection<string> txt = new ObservableCollection<string>();
            foreach (CodeList cl in this)
            {
                txt.Add(cl.ToString());
            }
            return txt;
        }

        public string RenderText()
        {
            StringBuilder sb = new StringBuilder();
            foreach (CodeList cl in this)
            {
                sb.Append(cl.ToString()).Append("\n");
            }
            return sb.ToString();
        }
	}
}
