//  
//  Copyright (C) 2009 Alan Battersby
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
// 
// Words in an G code
//[0]A A-axis of machine
//[1]B B-axis of machine
//[2]C C-axis of machine
//[3]D tool radius compensation number
//[4]F feedrate
//[5]G general function (see Table 5)
//[6]H tool length offset index
//[7]I X-axis offset for arcs /X offset in G87 canned cycle
//[8]J Y-axis offset for arcs / Y offset in G87 canned cycle
//[9]K Z-axis offset for arcs / Z offset in G87 canned cycle
//[10]L number of repetitions in canned cyclkey used with G10
//[11]M miscellaneous function (see Table 7)
//[12]N line number
//[13]P dwell time in canned cycles / dwell time with G4 / key used with G10
//[14]Q feed increment in G83 canned cycle
//[15]R canned cycle plane
//[16]S spindle speed
//[17]T tool selection
//[18]X X-axis of machine
//[19]Y Y-axis of machine
//[20]Z Z-axis of machine

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using BasicLib;


namespace OTWB
{
	public class Parameter
	{
        [XmlAttribute]
        public string Name { get; set; }

        [XmlAttribute]
        public string Value { get; set; }

		public Parameter(string k, string v)
		{
			Name = k;
			Value = v;
		}
        
        public Parameter()
        {
            Name = Value = string.Empty;
        }

		public override string ToString ()
		{
			return string.Format("{0}{1}",Name,Value);
		}

	}
	
    [XmlRoot("GCode")]
	public class Code
	{
		
		const string sp = " "; // single space
		const string tab = "\t"; // tab
		
		string _codeWord;			// G word or Mword or O word
		string _comment;			// comment on line
		
		string _expression;			// the expression
		List<Parameter> _params;  		// any double pvalues
	
		public Code()
		{
			_codeWord = _comment = _expression = string.Empty;
			_params = null;
		}
		
		public Code (string code)
		{
			_codeWord = code;
			_comment = _expression = string.Empty;
			_params = null;
		}

        [XmlArray("Parameters")]
        public List<Parameter> Parameters
        {
            get { return _params; }
            set { _params = value; }
        }

         [XmlIgnore]
		public bool hasExpression
		{
			get { return _expression != string.Empty; }
		}
		
        [XmlIgnore]
		public double A {   // A axis of machine
			get {
				
				return valueOf(GPARAM.A);
			}
			set {
				Add(GPARAM.A,value);
			}
		}

        [XmlIgnore]
		public double B {   // B axis of machine
			get {
				
				return valueOf(GPARAM.B);
			}
			set {
				Add(GPARAM.B,value);
			}
		}

        [XmlIgnore]
		public double C // C axis of machine
		{   
			get {
				
				return valueOf(GPARAM.C);
			}
			set {
				Add(GPARAM.C,value);
			}
		}

        [XmlIgnore]
		public double D // D axis of machine
		{   
			get {
				
				return valueOf(GPARAM.D);
			}
			set {
				Add(GPARAM.D,value);
			}
		}

        [XmlIgnore]
		public double F // F axis of machine
		{   
			get {
				
				return valueOf(GPARAM.F);
			}
			set {
				Add(GPARAM.F,value);
			}
		}

         [XmlIgnore]
		public double G // G axis of machine
		{   
			get {
				
				return valueOf(GPARAM.G);
			}
			set {
				Add(GPARAM.G,value);
			}
		}

         [XmlIgnore]
		public double H // H axis of machine
		{   
			get {
				
				return valueOf(GPARAM.H);
			}
			set {
				Add(GPARAM.H,value);
			}
		}

         [XmlIgnore]
		public double I // I axis of machine
		{   
			get {
				
				return valueOf(GPARAM.I);
			}
			set {
				Add(GPARAM.I,value);
			}
		}

         [XmlIgnore]
		public double J // J axis of machine
		{   
			get {
				
				return valueOf(GPARAM.J);
			}
			set {
				Add(GPARAM.J,value);
			}
		}

         [XmlIgnore]
		public double K // K axis of machine
		{   
			get {
				
				return valueOf(GPARAM.K);
			}
			set {
				Add(GPARAM.K,value);
			}
		}

         [XmlIgnore]
		public double L // L axis of machine
		{   
			get {
				
				return valueOf(GPARAM.L);
			}
			set {
				Add(GPARAM.L,value);
			}
		}

         [XmlIgnore]
		public double M // M axis of machine
		{   
			get {
				
				return valueOf(GPARAM.M);
			}
			set {
				Add(GPARAM.M,value);
			}
		}

         [XmlIgnore]
		public string N 
		{   
			get {

                return ValueOf(GPARAM.N);
			}
			set {
                Add(GPARAM.N, value.ToString());
			}
		}

         [XmlIgnore]
		public double P // P axis of machine
		{   
			get {
				
				return valueOf(GPARAM.P);
			}
			set {
				Add(GPARAM.P,value);
			}
		}

         [XmlIgnore]
		public double Q // Q axis of machine
		{   
			get {
				
				return valueOf(GPARAM.Q);
			}
			set {
				Add(GPARAM.Q,value);
			}
		}

         [XmlIgnore]
		public double R // R axis of machine
		{   
			get {
				
				return valueOf(GPARAM.R);
			}
			set {
				Add(GPARAM.R,value);
			}
		}

         [XmlIgnore]
		public double S // S axis of machine
		{   
			get {
				
				return valueOf(GPARAM.S);
			}
			set {
				Add(GPARAM.S,value);
			}
		}

         [XmlIgnore]
		public double T // T axis of machine
		{   
			get {
				
				return valueOf(GPARAM.T);
			}
			set {
				Add(GPARAM.T,value);
			}
		}

         [XmlIgnore]
		public double X // X axis of machine
		{   
			get {
				
				return valueOf(GPARAM.X);
			}
			set {
				Add(GPARAM.X,value);
			}
		}

         [XmlIgnore]
		public double Y // Y axis of machine
		{   
			get {
				
				return valueOf(GPARAM.Y);
			}
			set {
				Add(GPARAM.Y,value);
			}
		}

         [XmlIgnore]
		public double Z // Z axis of machine
		{   
			get {
				
				return valueOf(GPARAM.Z);
			}
			set {
				Add(GPARAM.Z,value);
			}
		} 
	

		public string Expression
		{
			get { return _expression; }
			set { _expression = value; }
		}
		
		public string CodeWord
		{
			get { return this._codeWord; }
			set { _codeWord = value; }
		}
		
		public override string ToString ()
		{
			StringBuilder sb = new StringBuilder();
			if (isOWord) 
				sb.Append(PCODE.O).Append(N);
			else if (CodeWord != String.Empty)
				sb.Append(CodeWord);
			sb.Append(sp);
			// add in others if appropriate
			if (hasExpression) 
				sb.Append(Expression).Append(sp);
			
			if (_params != null)
			{
				foreach (Parameter p in _params)
				{
                    if (p.Name != GPARAM.N)
                    {
                        if (p.Name == PCODE.CODE || isCodeParam(p.Name))
                            sb.Append(p.Value).Append(sp);
                        else
                            sb.Append(p.ToString()).Append(sp);
                    }
				}
			}
			
			
			// now append final comment 

			if (Comment != string.Empty)
				sb.Append(tab).Append(COMMENT.START).Append(Comment).Append(COMMENT.END);
			
			return sb.ToString();
		}

		public double valueOf(string key)
		{
			if (_params != null)
			{	
				Parameter p = _params.Find( delegate( Parameter pm)
				                       { return (pm.Name == key); });
				if (p == null)
					return double.NaN;
				else
					return double.Parse(p.Value);
			}
			return double.NaN;
		}
		
		public string ValueOf(string key)
		{
			if (_params != null)
			{	
				foreach (Parameter p in _params)
				{
					if (p.Name == key)
						return p.Value;
				}
			}
			return string.Empty;
		}
		
		//// <value>
		/// Properties testing type of word
		/// </value>
         [XmlIgnore]
		public bool isOWord
		{
			get {
				return CodeWord.StartsWith(PCODE.O);
			}
		}

         [XmlIgnore]
		public bool isNamedOWord
		{
			get {
				return CodeWord.StartsWith(PCODE.OPENANGLE);
			}
		}

         [XmlIgnore]
		public bool isVariable
		{
			get { return CodeWord.StartsWith(PCODE.HASH+PCODE.OPENANGLE); }
		}

         [XmlIgnore]
		public bool isGlobalVariable
		{
			get { return CodeWord.StartsWith(PCODE.HASH + PCODE.OPENANGLE + PCODE.UNDERSCORE); }
		}

         [XmlIgnore]
		public bool isMWord
		{
			get {
				return CodeWord.StartsWith(GPARAM.M);
			}
		}

         [XmlIgnore]
		public bool isGWord
		{
			get {
				return CodeWord.StartsWith(GPARAM.G);
			}
		}

         [XmlIgnore]
		public bool isComment
		{
			get {
				return CodeWord.StartsWith(COMMENT.START);
			}
		}
		
		public void Add(string s, double v)
		{
			if (_params == null)
				_params = new List<Parameter>();
			_params.Add(new Parameter(s,string.Format("{0:f3}",v)));
		}
		
		public void Add(string key, string val)
		{
			if (_params == null)
				_params = new List<Parameter>();
			_params.Add(new Parameter(key,val));
		}
		
		public void AddCodeParam(int i, string pv)
		{
			if (_params == null)
				_params = new List<Parameter>();
			_params.Add(new Parameter(i.ToString(),pv));
		}
		
		public bool isCodeParam(string name)
		{
			return System.Char.IsDigit(name[0]);
		}
		
		public string Comment
		{
			get {
				return _comment;
			}
			set {
				_comment = value;
			}
		}
		
		/// <summary>
		/// These are global static functions to create code
		/// </summary>
		public static Code MkComment(string v)
		{
			return new Code(COMMENT.START + v + COMMENT.END);	
		}
			
		public static Code MkOWord(int v)
		{
			return new Code(PCODE.Onum(v));
		}
		
		public static Code MkGWord(string g)
		{
			return new Code(g);	
		}
		
		public static Code MkMWord(string m)
		{
			return new Code(m);	
		}
	}
}
