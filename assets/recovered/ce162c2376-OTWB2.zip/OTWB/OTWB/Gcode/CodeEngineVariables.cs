
using System;
using BasicLib;

namespace OTWB
{


	public class CodeEngineVariables
	{

		protected int _maxDepthLoops;			// number of times to loop	
		protected int _maxWidthLoops;			// number of width passes
		
		protected double _maxDepth;				// maximum depth allowing for surface
		protected double _minDepth;				// minimum depth allowing for surface
		                                        // normally would be zero
		protected double _maxMachiningDepth;	// maximum depth to machine
		
		protected double _roughCutIncrement;	// depth cut in each initial pass
												// before the final finish cut
		protected double _finishCutDepth;		// depth of finishing cut
		protected double _currentDepth;			// depth to cut at;
		protected double _roughCutDepthLimit;	// last depth before finishing cut
		
		protected double _halfwidthDiff;		// this is (W - tool diameter)/2
		protected double _toolOffset;			// amount to move each width pass
		
		protected int _widthpassCount;			// counter for width loop
		protected double _maxWidth;				// maximum width of the path
		protected double _minWidth;				// diameter of the tool
		protected double _overlap;				// path overlap from info
		
		public int WidthpassCount {
			get {
				return _widthpassCount;
			}
			set {
				_widthpassCount = value;
			}
		}
		
		
		public double ToolOffset {
			get {
				return _toolOffset;
			}
			set {
				_toolOffset = value;
			}
		}
		
		
		public double RoughCutIncrement {
			get {
				return _roughCutIncrement;
			}
			set {
				_roughCutIncrement = value;
			}
		}
		
		
		public double RoughCutDepthLimit {
			get {
				return _roughCutDepthLimit;
			}
			set {
				_roughCutDepthLimit = value;
			}
		}
		
		
		public double MinDepth {
			get {
				return _minDepth;
			}
			set {
				_minDepth = value;
			}
		}
		
		
		public int MaxWidthLoops {
			get {
				return _maxWidthLoops;
			}
			set {
				_maxWidthLoops = value;
			}
		}
		
		
		public double MaxMachiningDepth {
			get {
				return _maxMachiningDepth;
			}
			set {
				_maxMachiningDepth = value;
			}
		}
		
		
		public int MaxDepthLoops {
			get {
				return _maxDepthLoops;
			}
			set {
				_maxDepthLoops = value;
			}
		}
		
		
		public double MaxDepth {
			get {
				return _maxDepth;
			}
			set {
				_maxDepth = value;
			}
		}
		
		
		public double HalfwidthDiff {
			get {
				return _halfwidthDiff;
			}
			set {
				_halfwidthDiff = value;
			}
		}
		
		
		public double FinishCutDepth {
			get {
				return _finishCutDepth;
			}
			set {
				_finishCutDepth = value;
			}
		}
		
		public double CurrentDepth {
			get {
				return _currentDepth;
			}
			set {
				_currentDepth = value;
			}
		}
		
		public double MinWidth {
			get {
				return _minWidth;
			}
			set {
				_minWidth = value;
			}
		}
		
		public double MaxWidth {
			get {
				return _maxWidth;
			}
			set {
				_maxWidth = value;
			}
		}
			
		public double Overlap {
			get {
				return _overlap;
			}
			set {
				_overlap = value;
			}
		}
		
		public CodeEngineVariables ()
		{
			_maxDepthLoops = _maxWidthLoops = 1;
			_currentDepth = 0;
			_maxMachiningDepth = 0;
			_roughCutIncrement = 0;
			_roughCutDepthLimit = 0;
			_finishCutDepth = 0;
			_maxDepth = 0;
			_minDepth = 0;
			_halfwidthDiff = 0;
			_toolOffset = 0;
			_maxWidth = _minWidth = 0;
		}
		
		public void CalcDepthLoopVariables(double maxmachiningdepth, MachiningData mdata)
		{
			double fcut = mdata.FinishCut;
			double roughcut = mdata.RoughCut;
			
			// set up globals
			_maxDepthLoops = 0;
			_maxMachiningDepth = maxmachiningdepth;
			
			if (Math.Abs(_maxMachiningDepth) < Utilities.EPS) {
				_maxDepthLoops = 1;
				_roughCutIncrement = 0;
				_finishCutDepth = 0;
			}
			else if (Math.Abs(_maxMachiningDepth) <= Math.Abs(fcut))
			{
				_maxDepthLoops = 1;
				_roughCutIncrement = fcut;
				_finishCutDepth = 0;
			}
			else{
				_roughCutDepthLimit = _maxMachiningDepth - fcut;
				int roughcutloops = (int)Math.Ceiling(Math.Abs(_roughCutDepthLimit) / Math.Abs(roughcut));
				_roughCutIncrement = _roughCutDepthLimit / roughcutloops;
				_finishCutDepth = _maxMachiningDepth - (roughcutloops * _roughCutIncrement);
				_maxDepthLoops = roughcutloops + 1;
			}
		}
		
		public void CalcWidthLoopVariables(double maxwidth, MachiningData mdata)
		{
			
		}
	}
}
