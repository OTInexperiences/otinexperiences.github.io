﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using BasicLib;
using System.Text.RegularExpressions;
using System.Windows;
using PropertyTools.Wpf;

namespace OTWB
{
    public enum GcodeProgramType
    {
        COMPLETE,
        SUBROUTINE,
        MAIN,
        TEMPLATE,
        TEXT
    }

    public class GCodeProgramInformation
    {
        GcodeProgramItem _itm;

        public GCodeProgramInformation(GcodeProgramItem itm)
        {
            _itm = itm;
        }

        [Browsable(true)]
        [ReadOnly(true)]
        [DisplayName("Program Type")]
        public GcodeProgramType Ptype
        {
            get { return _itm.ProgramType; }
        }

        [Browsable(true)]
        [ReadOnly(true)]
        [DisplayName("Program Name")]
        [Description("Then name of the item")]
        [AutoUpdateText] 
        public string Name
        {
            get { return _itm.Name; }
        }

        [Browsable(true)]
        [Description("Description of gcode item")]
        [WideProperty, Height(200)]
        [AutoUpdateText] 
        public string Description
        {
            get { return _itm.Description; }
            set { _itm.Description = value; }
       }
    }

    public class GcodeProgramItem : DependencyObject
    {
        private static readonly DependencyProperty NameProperty =
           DependencyProperty.Register("Name", typeof(string), typeof(GcodeProgramItem),
            new PropertyMetadata(string.Empty, new PropertyChangedCallback(OnNamePropChanged)));

        private static void OnNamePropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            if (obj is GcodeProgramItem)
            {
                (obj as GcodeProgramItem).Name = (string)args.NewValue;
            }
        }
        public string Name
        {
            get { return (string)GetValue(NameProperty); }
            set
            {
                SetValue(NameProperty, value);
            }
        }
  
        public GcodeProgram Program { get; set; }
        public GcodeProgramType ProgramType { get; set; }
        public string Description {get; set; }
        public string Text { get; set; }

        public GcodeProgramItem(string name, 
                                GcodeProgram code, 
                                GcodeProgramType typ,
                                string description )
        {
            Name = name;
            Program = code;
            ProgramType = typ;
            Description = description;
            Text = string.Empty;
        }

        public GcodeProgramItem(string name,
                                 string text,
                                 string description)
        {
            Name = name;
            Program = null;
            ProgramType = GcodeProgramType.TEMPLATE;
            Description = description;
            Text = text;
        }

        public GcodeProgramItem()
        {
            Name = string.Empty;
            Program = null;
            ProgramType = GcodeProgramType.SUBROUTINE;
            Description = string.Empty;
        }
        
    }

    // library of gcode programs
    class GcodeManager 
    {

        ObservableCollection<GcodeProgramItem> _items;
        ObservableCollection<GcodeProgramItem> _templates;

        public ProjectInfo Project { get; set; }

        string folder = BasicLib.Properties.Settings.Default.TemplateFolder;

        public ObservableCollection<GcodeProgramItem> Items
        {
            get { return _items; }
            set { _items = value; }
        }

        public ObservableCollection<GcodeProgramItem> Templates
        {
            get { return _templates; }
            set { _templates = value; }
        }

        internal GcodeProgramItem FindTemplate(string tmplname)
        {
            return _templates.FirstOrDefault((GcodeProgramItem p) => p.Name == tmplname);
        }

        internal bool TemplateExists(string tmplname)
        {
            foreach (GcodeProgramItem itm in _templates)
                if (itm.Name == tmplname)
                    return true;
            return false;
        }

        public GcodeManager()
        {
            _items = new ObservableCollection<GcodeProgramItem>();
            _templates = new ObservableCollection<GcodeProgramItem>(FindTemplates());
        }

        public GcodeProgramItem Template(string name)
        {
            return new GcodeProgramItem(name, LoadTemplateUsingName(name), "Template");
        }

        // these are standard gcode subs that may be used
        public string LoadTemplateUsingName(string name)
        {
            string tmpl = string.Empty;
            string tmpname = System.IO.Path.Combine(folder, name);
            tmpname = System.IO.Path.ChangeExtension(tmpname,
                        BasicLib.Properties.Settings.Default.TemplateExt);
            try
            {
                tmpl = System.IO.File.ReadAllText(tmpname);
            }
            catch
            {
                tmpl = name;
            }
            return tmpl;
        }

        public GcodeProgramItem LoadTemplate(string name)
        {
            return new GcodeProgramItem(name,
                                        LoadTemplateUsingName(name),
                                        "Template");
        }

        IList<GcodeProgramItem> FindTemplates()
        {
            
            // now look for all template files in folder and add their 
            // name to templates list
            List<GcodeProgramItem> names = new List<GcodeProgramItem>();
           try
            {
                foreach (string s in Directory.GetFiles(folder))
                {
                    string fext = System.IO.Path.GetExtension(s);
                    if ( fext.EndsWith( BasicLib.Properties.Settings.Default.TemplateExt))
                    {
                        GcodeProgramItem itm = Template(System.IO.Path.GetFileNameWithoutExtension(s));
                        names.Add(itm);
                    }
                }
     
            }
            catch (Exception e){}
            return names;
        }

        internal string Instantiate(string tmpl)
        {
            string res = tmpl;
            MatchCollection matches = Regex.Matches(tmpl, "_PROJ");
            if (matches.Count > 0)
            {
                res = tmpl.Replace("_PROJ", Project.ProjectName);
            }
            Console.WriteLine("Replaced _PROJ\n {0}", res);
            matches = Regex.Matches(res, "{(USING|using)\\s*(\\w*\\.)?(\\w*)\\s*}");
            if (matches.Count > 0)
            {
                foreach (Match m in matches)
                {
                    string tn = m.Groups[3].Value;
                    //Console.WriteLine("value is {0} viz {1}", m.Value, tn);
                    string txt = FindTemplate(tn).Text;
                    //Console.WriteLine("value {0} is {1}", tn, txt);
                    string tmpl1 = Instantiate(txt);
                    //Console.WriteLine("replacing {0} with {1}", tn, tmpl1);
                    res = res.Replace(m.Value, tmpl1);
                }
            }
            AXIS ax;

            Match match = Regex.Match(res, "{\\s*AXIS0\\s*}");
            if (match.Success )
            { 
                ax = (Project != null) ? Project.AXIS0
                                           : OTWB.Properties.Settings.Default.AXIS0_Default;
                res = res.Replace(match.Value,ax.ToString());
            }

            match = Regex.Match(res, "{\\s*RAXIS0\\s*}");
            if (match.Success)
            {
                ax = (Project != null) ? Project.AXIS0
                                           : OTWB.Properties.Settings.Default.AXIS0_Default;
                ax = Utilities.RotationAxis(ax);
                res = res.Replace(match.Value, ax.ToString());
            }

            match = Regex.Match(res, "{\\s*AXIS1\\s*}");
            if (match.Success)
            {
                ax = (Project != null) ? Project.AXIS1
                                           : OTWB.Properties.Settings.Default.AXIS1_Default;
                res = res.Replace(match.Value, ax.ToString());
            }

            match = Regex.Match(res, "{\\s*RAXIS1\\s*}");
            if (match.Success)
            {
                ax = (Project != null) ? Project.AXIS1
                                           : OTWB.Properties.Settings.Default.AXIS1_Default;
                ax = Utilities.RotationAxis(ax);
                res = res.Replace(match.Value, ax.ToString());
            }

            match = Regex.Match(res, "{\\s*AXIS2\\s*}");
            if (match.Success)
            {
                ax = (Project != null) ? Project.AXIS2
                                           : OTWB.Properties.Settings.Default.AXIS2_Default;
                res = res.Replace(match.Value, ax.ToString());
            }

            match = Regex.Match(res, "{\\s*RAXIS2\\s*}");
            if (match.Success)
            {
                ax = (Project != null) ? Project.AXIS2
                                           : OTWB.Properties.Settings.Default.AXIS2_Default;
                ax = Utilities.RotationAxis(ax);
                res = res.Replace(match.Value, ax.ToString());
            }

            match = Regex.Match(res, "{\\s*AXIS3\\s*}");
            if (match.Success)
            {
                ax = (Project != null) ? Project.AXIS3
                                           : OTWB.Properties.Settings.Default.AXIS3_Default;
                res = res.Replace(match.Value, ax.ToString());
            }

            match = Regex.Match(res, "{\\s*AXIS3\\s*}");
            if (match.Success)
            {
                ax = (Project != null) ? Project.AXIS3
                                           : OTWB.Properties.Settings.Default.AXIS3_Default;
                ax = Utilities.RotationAxis(ax);
                res = res.Replace(match.Value, ax.ToString());
            }
          
            return res;
        }

        public GcodeProgramItem Instantiate(GcodeProgramItem tmpl)
        {
            string name = string.Format("{0}_{1}",Project.ProjectName,tmpl.Name);
            GcodeProgramItem prog = new GcodeProgramItem(name,"","Program");
            prog.ProgramType = GcodeProgramType.TEXT;
            if (tmpl.ProgramType == GcodeProgramType.TEMPLATE)
            {
                prog.Text = Instantiate(tmpl.Text);
            }
            return prog;

        }

        internal void AddProgram(GcodeProgramItem itm)
        {
            _items.Add(itm);
        }

        internal void AddTemplate(string p)
        {
            _templates.Add(LoadTemplate(p));
        }

        internal void Remove(GcodeProgramItem itm)
        {
            if (itm.ProgramType == GcodeProgramType.TEMPLATE)
            {
                _templates.Remove(itm);
                // now remove from area
                string fn = System.IO.Path.Combine(BasicLib.Properties.Settings.Default.TemplateFolder, itm.Name);
                fn = System.IO.Path.ChangeExtension(fn, BasicLib.Properties.Settings.Default.TemplateExt);
                if (MessageBox.Show("Delete Template from Library?","Remove Template Permenantly",MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    System.IO.File.Delete(fn);
            }
            else
                _items.Remove(itm);
        }
    }
}
