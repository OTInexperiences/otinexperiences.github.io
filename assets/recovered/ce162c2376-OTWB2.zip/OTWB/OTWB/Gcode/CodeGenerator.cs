
using System;
using System.Windows;
using System.Collections;
using System.Collections.ObjectModel;
using System.Windows.Media.Media3D;
using BasicLib;
using System.Windows.Media;

namespace OTWB
{

	/// </summary>
	public class CodeGenerator
	{

        protected const string DEPTH = "depth";
        protected const string UNITSPERMINUTE = "units_per_minute";
        protected const string FEEDRATE = "feedrate";
        protected const string SAFEHEIGHT = "safeheight";

		protected string depthloopComment = "Rough cut pass {0} Current depth {1}";
		protected string finishcutComment = "Finish cut pass {0} depth {1}";
		protected string pathloopComment  = "Path {0}  Width pass {1}";
		protected string pathstartComment = "Path:{0} MaxDepth:{1} Width:{2} needs {3} width pass[es]";
		
        protected string RoseSpindleAxis;       // used for spindle rotation
		protected string RoseOffsetAxis;        // used for offset
        protected string PumpAxis;              // used for pumping
        protected string Yaxis;                 // not used
		protected string CutterDepthAxis;      // used for depth
     
		// The required variables 
		protected CodeEngineVariables _vars;				// variables needed by code engine
        protected GcodeAddress _mainsubaddr;                // address of main sub
        protected Queue _subaddresses;

		protected GCODE _modalCode;			// current modal gcode
			
		protected bool _GCodeRequired; 
		protected bool _FeedrateRequired;
		
	    protected int _windingNumber;       // number of full turns around spindle axis

        protected double _lastAngle;        // angle of last point
        protected Cylindrical _lastPosition;  // last point when rotary move
        protected Cylindrical _currentPosition;

        protected Point3D _lastPoint;             // last point when linear move
		
        protected bool _patternLiesOutsideSpindleCentre; 
		protected bool _pathCompletion;
			
		public ProjectInfo Project {get; set; }
       
		public CodeGenerator()
		{
			_vars = new CodeEngineVariables();
            _subaddresses = new Queue();
            _lastPosition = new Cylindrical(0,0,0);
            _currentPosition = new Cylindrical(0,0,0);
            _lastPoint = new Point3D(0,0,0);
		}

        public GcodeProgram RenderGCodeSub(string name,Path p)
        {
            RoseSpindleAxis = Project.AXIS0.ToString();
            PumpAxis = Project.AXIS1.ToString();
            RoseOffsetAxis = Project.AXIS2.ToString();
            CutterDepthAxis = Project.AXIS3.ToString();
            GcodeProgram gcode = new GcodeProgram();
            gcode.Add(RenderPathAsSub(name, p.Points));

            return gcode;
        }

        

        public GcodeProgram RenderGCodeFromPathList(PathList paths)
        {
            // set up axes
            RoseSpindleAxis = Project.AXIS0.ToString();
            PumpAxis = Project.AXIS1.ToString();
            RoseOffsetAxis = Project.AXIS2.ToString();
            CutterDepthAxis = Project.AXIS3.ToString();

            GcodeProgram gcode = new GcodeProgram();
             gcode.Add(RenderHeader("Paths"));
             gcode.Add(RenderVariables());
            for (int indx=0; indx < paths.Count; indx++)
            {
                 gcode.Add(RenderPath(indx, paths[indx].Points));
            }
             gcode.Add(RenderMainLoop(paths));
             gcode.Add(RenderFooter());
            return gcode;
        }
        public GcodeProgram RenderGCodeProgram(Offsets offsets, GCodeSource src, Surface surf)
        {
            // set up axes
            RoseSpindleAxis = Project.AXIS0.ToString();
            PumpAxis = Project.AXIS1.ToString();
            RoseOffsetAxis = Project.AXIS2.ToString();
            CutterDepthAxis = Project.AXIS3.ToString();
          
            GcodeProgram gcode = new GcodeProgram();
             gcode.Add(RenderHeader(src.ToString()));
             gcode.Add(RenderVariables());
			 gcode.Add(RenderPath(offsets, src, surf));
             gcode.Add(RenderMainLoop(offsets,src));
             gcode.Add(RenderFooter());
            return gcode;
        }

        GcodeAddress mkSubAddress(int indx)
        {
            string s= string.Format("{0}_path_{1}", Project.ProjectName, indx + 1);
            return new GcodeAddress(s);
        }

        void CheckWinding()
        {
            double lp = Utilities.fixAngleDegrees(_lastPosition.Angle);
            double cp = Utilities.fixAngleDegrees(_currentPosition.Angle);
            int lpq = Utilities.Quadrant(lp);
            int cpq = Utilities.Quadrant(cp);

            System.Diagnostics.Debug.Print("Check Winding lp={0},lpQ={1},cp={2},cpQ={3}",
                              lp, lpq, cp, cpq);
            if (lpq == cpq)
                return;  // no change
            else if ((lpq == 0) && (cpq == 3))
                _windingNumber -= 1;
            else if ((lpq == 3) && (cpq == 0))
                _windingNumber += 1;
        }

        private CodeList RenderPathAsSub(string name, Point3DCollection point3DCollection)
        {    
            CodeList codelist = new CodeList();
            GcodeAddress subaddr = new GcodeAddress(name);
            Code substart = mkSubStart(subaddr);
            codelist.Add(substart);
            RenderPoints(ref codelist, point3DCollection);
            codelist.Add(mkSubEnd(subaddr));
            codelist.EmptyLine();
            return codelist;
        }

        public void RenderGlobals(ref CodeList lines, Headstock hs)
        {
            lines.AddComment("Main Memory Area");
            lines.Add(mkEMCVariableAssign(EMC.EmcMemoryMap.UseMainSpindle,
                                (hs.IncludeMainSpindle ? 1 : 0),
                                "Include main spindle"));
            lines.Add(mkEMCVariableAssign(EMC.EmcMemoryMap.UsePumpSpindle,
                                (hs.IncludePumpSpindle ? 1 : 0),
                                "Include pump spindle"));
            lines.AddComment("Machining Data");
            lines.Add(mkEMCVariableAssign(EMC.EmcMemoryMap.RoughCutIncrement,
                                Project.MachiningData.RoughCut,
                                "Rough Cut Increment"));
            lines.Add(mkEMCVariableAssign(EMC.EmcMemoryMap.FinishCutIncrement,
                                Project.MachiningData.FinishCut,
                                "Finish Cut Increment"));
            lines.Add(mkEMCVariableAssign(EMC.EmcMemoryMap.FeedRate,
                                Project.MachiningData.FeedRate,
                                "Linear Feed Rate"));
            lines.Add(mkEMCVariableAssign(EMC.EmcMemoryMap.InverseTimeFeedRate,
                                Project.MachiningData.InverseFeedRate,
                                "Inverse Time Feed Rate"));
            lines.Add(mkEMCVariableAssign(EMC.EmcMemoryMap.MMUnitsFlag,
                                (Project.MachiningData.Units == UNITS.MM) ? 1 : 0,
                                "Use MM units flag"));
            lines.Add(mkEMCVariableAssign(EMC.EmcMemoryMap.SafeHeight,
                                Project.MachiningData.SafeHeight,
                                "Safe Height"));
        }

        internal void RenderSpindleOffsets(ref CodeList lines, 
                                           int baseaddr,
                                           ObservableCollection<FullOffsetInfo> offs,
                                           Range anglerange)
        {
            int startindx = 0;
            int endindx = offs.Count;
            int count = offs.Count;
            if (Project.CodeType == GCodeType.RELATIVE)
            {
                startindx += 1;
                endindx -= 1;
                count -= 1;
            }

            lines.Add(mkEMCVariableAssign(baseaddr + EMC.EmcMemoryMap.TableLengthOffset, count, "Table length"));
            lines.Add(mkEMCVariableAssign(baseaddr + EMC.EmcMemoryMap.AngleIncOffset, anglerange.Inc, "Angle Increment"));
            
            int tabindx = baseaddr + EMC.EmcMemoryMap.TableStartOffset;
           
            
            for (int indx = startindx; indx < endindx; indx++)
            {
                string comment = string.Format("[{0}]", offs[indx].Angle);
                if (Project.CodeType == GCodeType.RELATIVE)
                    lines.Add(mkEMCVariableAssign(tabindx++, offs[indx].ROffset, comment));
                else
                    lines.Add(mkEMCVariableAssign(tabindx++, offs[indx].Radius, comment));
            }
        }

        public CodeList RenderEMCMemoryMap(Headstock hs, Offsets offsets, Range anglerange)
        {
            CodeList lines = new CodeList();
            GcodeAddress subaddr = new GcodeAddress(Project.MemoryMapName);
            Code substart = mkSubStart(subaddr);
            lines.Add(substart);
            if (hs.IncludeMainSpindle)
            {
                // need to save increment values not absolute values
                // assume increment 0 at start
                ObservableCollection<FullOffsetInfo> offs = offsets.MainSpindle_Offsets;
                string hdr = (Project.CodeType == GCodeType.ABSOLUTE)
                           ? "Start of Main Spindle Radii Data for Absolute distance mode"
                           : "Start of Main Spindle Offset Data for Relative distance mode";

                lines.AddComment( hdr);
                RenderSpindleOffsets(ref lines,EMC.EmcMemoryMap.MainSpindleStartAddr ,offs, anglerange);
                lines.AddComment("End of Main table");
            }
            if (hs.IncludePumpSpindle)
            {
                ObservableCollection<FullOffsetInfo> offs = offsets.Pump_Offsets;
                string hdr = (Project.CodeType == GCodeType.ABSOLUTE)
                           ? "Start of Pump Spindle Radii Data for Absolute distance mode"
                           : "Start of Pump Spindle Offset Data for Relative distance mode";
                lines.AddComment(hdr);
                RenderSpindleOffsets(ref lines, EMC.EmcMemoryMap.PumpSpindleStartAddr, offs, anglerange);
                lines.AddComment("End of Pumping Table");
            }
            lines.Add(mkSubEnd(subaddr));
            lines.EmptyLine();
            return lines;
        }

        private void RenderPoints(ref CodeList codelist, Point3DCollection path)
        {
            Code code;

            _lastAngle = 0;
            _lastPosition.Radius = _lastPosition.Angle = _lastPosition.Depth = 0;
            _currentPosition.Radius = _currentPosition.Angle = _currentPosition.Depth = 0;
            _lastPoint.X = _lastPoint.Y = _lastPoint.Z = 0;
            _windingNumber = 0;
            if (Project.CodeType == GCodeType.RELATIVE)
                RenderIncrementalMode(ref codelist);
            else
                RenderAbsoluteMode(ref codelist);

            if (Project.UseRotaryTable)
            {
                RenderUnitsperMinuteMode(ref codelist);
                _currentPosition.asPoint = path[0];
                code = mkRotaryMoveToPoint(_currentPosition);
                code.CodeWord = GCODE.Linear_interpolation;
                code.Add(GPARAM.F, PCODE.Bracket(PCODE.GlobalVariable(UNITSPERMINUTE)));
                CheckWinding();
                _lastPosition.Radius = _currentPosition.Radius;
                _lastPosition.Angle = _currentPosition.Angle;
                _lastPosition.Depth = _currentPosition.Depth;
            }
            else
            {
                code = mkLinearMoveToPoint(path[0]);
                code.Add(GPARAM.F, PCODE.Bracket(PCODE.GlobalVariable(FEEDRATE)));
            }
            codelist.Add(code);
            for (int pindx = 1; pindx < path.Count; pindx++)
            {
                if (Project.UseRotaryTable)
                {
                    _currentPosition.asPoint = path[pindx];

                    CheckWinding();
                    //System.Diagnostics.Debug.Print("lp {0}, cp {1}, winding {2}", 
                    //    _lastPosition, _currentPosition, _windingNumber);
                    if (_currentPosition.Angle % 360 == 0)
                        _currentPosition.Angle = _windingNumber * 360;
                    else
                        _currentPosition.Angle += _windingNumber * 360;

                    //System.Diagnostics.Debug.Print("new cp {0}", _currentPosition);

                    code = mkRotaryMoveToPoint(_currentPosition);

                }
                else
                    code = mkLinearMoveToPoint(path[pindx]);
                codelist.Add(code);
                _lastPosition.Radius = _currentPosition.Radius;
                _lastPosition.Angle = _currentPosition.Angle;
            }
        }

        CodeList RenderPath(int indx, Point3DCollection path)
		{
            _lastAngle = 0;
            _lastPosition.Radius = _lastPosition.Angle = _lastPosition.Depth = 0;
            _currentPosition.Radius = _currentPosition.Angle = _currentPosition.Depth = 0;
            _lastPoint.X = _lastPoint.Y = _lastPoint.Z = 0;
            _windingNumber = 0;
            CodeList codelist = new  CodeList();
           
            _mainsubaddr = mkSubAddress(indx);
            Code substart = mkSubStart(_mainsubaddr);
            codelist.Add(substart);
            //now start with G01
           
            if (Project.CodeType == GCodeType.RELATIVE)
                RenderIncrementalMode(ref codelist);
            else
                RenderAbsoluteMode(ref codelist);
            // set up movement code
            Code code;
                
                new Code( GCODE.Linear_interpolation);
            if (Project.UseRotaryTable)
            {
                RenderUnitsperMinuteMode(ref codelist);
                _currentPosition.asPoint = path[0];
                code = mkRotaryMoveToPoint(_currentPosition);
                code.CodeWord =  GCODE.Linear_interpolation;
                code.Add(GPARAM.F, PCODE.Bracket(PCODE.GlobalVariable(UNITSPERMINUTE)));
                CheckWinding();
                _lastPosition.Radius = _currentPosition.Radius;
                _lastPosition.Angle = _currentPosition.Angle;
                _lastPosition.Depth = _currentPosition.Depth;
            }
            else
            {
                code = mkLinearMoveToPoint(path[0]);
                code.Add(GPARAM.F, PCODE.Bracket(PCODE.GlobalVariable(FEEDRATE)));
            }
            codelist.Add(code);
           

            for (int pindx=1; pindx < path.Count; pindx++)
            {
                if (Project.UseRotaryTable)
                {
                    _currentPosition.asPoint = path[pindx];
                    
                    CheckWinding();
                    //System.Diagnostics.Debug.Print("lp {0}, cp {1}, winding {2}", 
                    //    _lastPosition, _currentPosition, _windingNumber);
                    if (_currentPosition.Angle % 360 == 0)
                        _currentPosition.Angle = _windingNumber * 360;
                    else
                        _currentPosition.Angle += _windingNumber * 360;
                   
                    //System.Diagnostics.Debug.Print("new cp {0}", _currentPosition);
                   
                    code = mkRotaryMoveToPoint(_currentPosition);
                    
                }
                else
                    code = mkLinearMoveToPoint(path[pindx]);
                codelist.Add(code);
                _lastPosition.Radius = _currentPosition.Radius;
                _lastPosition.Angle = _currentPosition.Angle;
            }
            codelist.Add(mkSubEnd(_mainsubaddr));
            codelist.EmptyLine();
            return codelist;
		}
        CodeList RenderPath(Offsets alloffsets, GCodeSource src, Surface surf)
		{
            ObservableCollection<FullOffsetInfo> offsets = alloffsets.OffsetsFor(src);
            _windingNumber = 0;
            _lastAngle = 0;

            CodeList codelist = new  CodeList();
            _mainsubaddr = mkSubAddress(1);
            Code substart = mkSubStart(_mainsubaddr);
            substart.Comment = "Generate gcode for offsets for " + src.ToString();
            codelist.Add(substart);
            //now start with G01
           
            if (Project.CodeType == GCodeType.RELATIVE)
                RenderIncrementalMode(ref codelist);
            else
                RenderAbsoluteMode(ref codelist);
            // set up movement code
            Code code = new Code( GCODE.Linear_interpolation);
            if (Project.UseRotaryTable)
            {
                RenderUnitsperMinuteMode(ref codelist);
                code.Add(GPARAM.F, PCODE.Bracket(PCODE.GlobalVariable(UNITSPERMINUTE)));
            }
            else
            {
                code.Add(GPARAM.F, PCODE.Bracket(PCODE.GlobalVariable(FEEDRATE)));
            }
            codelist.Add(code);

            foreach (FullOffsetInfo foi in offsets)
            {
                code = new Code();
                if (Project.CodeType == GCodeType.RELATIVE)
                    RenderOffset(ref code, foi, src);
                else
                    RenderAbsolute(ref code, foi, src);
                codelist.Add(code);
            }
            codelist.Add(mkSubEnd(_mainsubaddr));
            codelist.EmptyLine();
            return codelist;
		}

        CodeList RenderMainLoop(PathList paths)
		{
            CodeList codelist = new  CodeList();
            codelist.AddComment("Main Program");
            codelist.EmptyLine();
            // now definne depth variable
            Code code;  
            _windingNumber = 0;
            // move to first position
            RenderMoveToSafeHeight(ref codelist);
            for (int indx = 0; indx < paths.Count; indx++)
            {
                Point3DCollection path = paths[indx].Points;
                Cylindrical p = new Cylindrical(path[0]);
                code = mkRotaryMoveToPoint(p);
                code.CodeWord=  GCODE.Rapid_Positioning;
                code.Comment = string.Format("This should be first position on path {0}",indx+1);
                codelist.Add(code);
                RenderMoveToCuttingDepth(ref codelist);
                codelist.Add(mkCall(mkSubAddress(indx)));
                RenderMoveToSafeHeight(ref codelist);
            }
            return codelist;
		}
        CodeList RenderMainLoop(Offsets alloffsets, GCodeSource src)
        {
            ObservableCollection<FullOffsetInfo> offsets = alloffsets.OffsetsFor(src);
            CodeList codelist = new  CodeList();
            codelist.AddComment("Main Program");
            codelist.EmptyLine();
            // now definne depth variable
            Code code;
            _windingNumber = 0;
            // move to first position
            RenderMoveToSafeHeight(ref codelist);
            code = new Code( GCODE.Rapid_Positioning);
            code.Comment = "This should be radius of first position on path";
            if (Project.CodeType == GCodeType.RELATIVE)
                RenderOffset(ref code, offsets[0], src);
            else
                RenderAbsolute(ref code, offsets[0], src);

            codelist.Add(code);
            RenderMoveToCuttingDepth(ref codelist);
            codelist.Add(mkCall(_mainsubaddr));
            RenderMoveToSafeHeight(ref codelist);
            return codelist;
        }

		CodeList RenderHeader(string src)
		{
			CodeList hdr = new CodeList();
			string units = Project.MachiningData.Units.ToString();
			hdr.AddSeparator();
		
			hdr.AddComment(string.Format("Date: {0}",DateTime.Today.Date));
		
            //hdr.AddComment(string.Format("Using tool: {0} Diameter {1}",
            //                             Project.Tool, Project.Tooltable.ToolDiameter(Project.Tool)));
			hdr.AddComment(string.Format("Units used are {0}",units));
			hdr.AddComment(string.Format("Source is {0}",src));
			hdr.AddComment(string.Format("Coordinates are {0}",Project.CodeType.ToString()));             
			if (Project.UseRotaryTable)
				hdr.AddComment(string.Format("Using Rotary Table around {0} axis",RoseSpindleAxis));
			else
				hdr.AddComment("Not using Rotary table");

            return hdr;		
		}		
		CodeList RenderFooter()
		{
            CodeList ftr = new CodeList();
			ftr.Add(Code.MkMWord(MCODE.End_of_Program));
			ftr.AddComment("-----End of Program-----");
            return ftr;
		}

        CodeList RenderVariables()
        {
            CodeList codelist = new CodeList();
            Code code = mkGlobalAssign(SAFEHEIGHT, Project.MachiningData.SafeHeight.ToString());
            code.Comment = "Safe height for cutter above work change his manually";
            codelist.Add(code);  

            codelist.AddComment("Global values used in the program");
            code = mkGlobalAssign(DEPTH, Project.MachiningData.AssumedSurfaceDepth.ToString());
            code.Comment = "Depth to cut change this manually";
            codelist.Add(code);
           
            code = mkGlobalAssign(FEEDRATE, Project.MachiningData.FeedRate.ToString());
            code.Comment = "Linear feed rate change this manually";
            codelist.Add(code);

            code = mkGlobalAssign(UNITSPERMINUTE, Project.MachiningData.InverseFeedRate.ToString());
            code.Comment = "Angular feed rate tchange his manually";
            codelist.Add(code);  
            return codelist;
        }

        //double CheckAngle(double angle)
        //{
        //    if (_lastPosition.Angle == angle)
        //        return angle;
        //    else if (Utilities.Quadrant3To0(_lastPosition.Angle, angle))
        //       _windingNumber += 1;
        //    else if (Utilities.Quadrant0To3(_lastPosition.Angle, angle))
        //        _windingNumber -= 1;
        //    double nxtangle = angle + _windingNumber * 360.0;
        //    _lastPosition.Angle = nxtangle;
        //    return nxtangle;
        //}
     
    

        void RenderAbsolute(ref Code code, FullOffsetInfo offset, GCodeSource src)
        {
           
            code.Add(RoseSpindleAxis, offset.Angle);
            switch (src)
            {
                case GCodeSource.ROSE:
                    code.Add(RoseOffsetAxis, offset.Radius);
                    break;
                case GCodeSource.PUMP:
                    code.Add(PumpAxis, offset.Radius);
                    break;
                case GCodeSource.ROSE_WITH_PUMP:
                    code.Add(RoseOffsetAxis, offset.Radius);
                    code.Add(PumpAxis, offset.Radius);
                    break;
                case GCodeSource.CHUCK:
                    code.Add(RoseOffsetAxis, offset.Radius);
                    break;
                case GCodeSource.CHUCK_AND_ROSE:
                    break;
                case GCodeSource.CHUCK_AND_ROSE_WITH_PUMP:
                    code.Add(RoseOffsetAxis, offset.Radius);
                    code.Add(PumpAxis, offset.Radius);
                    break;
            }
            code.Comment = string.Format("[ {0} ]", offset.Angle);
        }
        void RenderOffset(ref Code code, FullOffsetInfo offset, GCodeSource src)
        {
            if (Math.Abs(offset.AOffset) > 0) 
                code.Add(RoseSpindleAxis, offset.AOffset);
            switch (src)
            {
                case GCodeSource.ROSE:
                    if (Math.Abs(offset.ROffset) > 0) 
                        code.Add(RoseOffsetAxis, offset.ROffset);
                    break;
                case GCodeSource.PUMP:
                        if (Math.Abs(offset.ROffset) > 0) 
                    code.Add(PumpAxis, offset.ROffset);
                    break;
                case GCodeSource.ROSE_WITH_PUMP:
                    if (Math.Abs(offset.ROffset) > 0)
                    {
                        code.Add(RoseOffsetAxis, offset.ROffset);
                        code.Add(PumpAxis, offset.ROffset);
                    }
                    break;
                case GCodeSource.CHUCK:
                    if (Math.Abs(offset.ROffset) > 0) 
                        code.Add(RoseOffsetAxis, offset.ROffset);
                    break;
                case GCodeSource.CHUCK_AND_ROSE:
                    break;
                case GCodeSource.CHUCK_AND_ROSE_WITH_PUMP:
                    if (Math.Abs(offset.ROffset) > 0)
                    {
                        code.Add(RoseOffsetAxis, offset.ROffset);
                        code.Add(PumpAxis, offset.ROffset);
                    }
                   
                    break;
            }
            code.Comment = string.Format("[ {0} ]", offset.Angle);
        }

		protected bool differentParamFromLast(ref CodeList codelist, string param, double v)
		{
			if (codelist.Empty) return true;
			double pv = codelist.Last().valueOf(param);
			if (double.IsNaN(pv)) return true;
			else return (Math.Abs(pv-v) > Utilities.EPS);
		}		
		protected string ValueOfLastParam(ref CodeList codelist, string param)
		{
			if (codelist.Empty) return string.Empty;
			return codelist.Last().ValueOf(param);
		}	
		protected bool differentCodeWordFromLast(ref CodeList codelist, string code)
		{
			if (codelist.Empty) return true;
			return (codelist.Last().CodeWord != code);
		}

		protected void RenderAbsoluteMode(ref CodeList codelist)
		{
			Code code = Code.MkGWord( GCODE.Absolute_programming);
            code.Comment = "Absolute positioning mode";
			codelist.Add(code);
		}
		protected void RenderIncrementalMode(ref CodeList codelist)
		{
			Code code = Code.MkGWord( GCODE.Incremental_programming);
            code.Comment = "Incremental positioning Mode";
			codelist.Add(code);
		}	
		protected void RenderInverseTimeMode(ref CodeList codelist)
		{
			Code code = Code.MkGWord( GCODE.Inverse_time_mode);
            code.Comment = "Inverse Time Mode";
			codelist.Add(code);	
		}
		protected void RenderUnitsperMinuteMode(ref CodeList codelist)
		{
			Code code = Code.MkGWord( GCODE.Units_per_minute_feed);
            code.Comment = "Units per minute mode";
			codelist.Add(code);	
		}
        protected void RenderMoveToSafeHeight(ref CodeList codelist)
        {
            if (Project.CodeType == GCodeType.RELATIVE)
            {
                // issue temp absolute move
                RenderAbsoluteMode(ref codelist);
            }
            codelist.Add(mkMoveToSafeHeight());
            if (Project.CodeType == GCodeType.RELATIVE)
            {
                // re issue temp incremental move code
                RenderIncrementalMode(ref codelist);
            }

        }
        protected void RenderMoveToCuttingDepth(ref CodeList codelist)
        {
            if (Project.CodeType == GCodeType.RELATIVE)
            {
                // issue temp absolute move
                RenderAbsoluteMode(ref codelist);
            }

            codelist.Add(mkRapidMoveToDepth(Project.MachiningData.AssumedSurfaceDepth));
            codelist.Add(mkLinearMoveToDepth());

            if (Project.CodeType == GCodeType.RELATIVE)
            {
                // re issue temp incremental move code
                RenderIncrementalMode(ref codelist);
            }
        }

        protected Code mkOWord(GcodeAddress addr)
        {
            Code code = new Code(PCODE.O);
            code.N = addr.ToString();
            return code;
        }
        protected Code mkSubStart(GcodeAddress addr)
        {
            return mkOWord(addr, PCODE.Sub);
        }
        protected Code mkOWord(GcodeAddress addr, string line)
        {
            Code code = new Code(PCODE.O);
            code.N = addr.ToString();
            code.Expression = line;
            return code;
        }
        protected Code mkNamedOwordLine(string name, string line)
        {
            Code code = new Code(PCODE.OwordName(name));
            code.Expression = line;
            return code;
        }
        protected Code mkSubEnd(GcodeAddress addr)
        {
            return mkOWord(addr, PCODE.Endsub);
        }
        protected Code mkCall(GcodeAddress addr, params string[] parameters)
        {
            Code code = mkOWord(addr);
            code.Expression = PCODE.Callsub;
            if (parameters.Length > 0)
            {
                string p;
                for (int i = 0; i < parameters.Length; i++)
                {
                    p = parameters[i];
                    if (!p.StartsWith(PCODE.OPENBRACKET))
                        p = PCODE.Bracket(p);

                    code.AddCodeParam(i, p);
                }
            }
            return code;
        }
        protected Code mkAssign(string variable, string val)
        {
            Code code = new Code();
            code.Expression = PCODE.Assign(variable, val);
            return code;
        }
        protected Code mkGlobalAssign(string variable, string val)
        {
            Code code = new Code();
            code.Expression = PCODE.Assign(PCODE.GlobalVariable(variable), val);
            return code;
        }

        protected Code mkEMCVariableAssign(int varid, double val, string comment)
        {
            Code code = new Code();
            code.Expression = PCODE.Assign(PCODE.NumericVariable(varid), val.ToString());
            code.Comment = comment;
            return code;
        }

        protected Code mkLocalAssign(string variable, string val)
        {
            Code code = new Code();
            code.Expression = PCODE.Assign(PCODE.LocalVariable(variable), val);
            return code;
        }
        protected Code mkMoveToSafeHeight()
        {
            Code code = new Code( GCODE.Rapid_Positioning);
            code.Add(CutterDepthAxis, PCODE.Bracket(PCODE.GlobalVariable(SAFEHEIGHT)));
            return code;
        }
        protected Code mkRapidMoveToDepth(double depth)
        {
            Code code = new Code( GCODE.Rapid_Positioning);
            code.Add(CutterDepthAxis,depth);
            return code;
        }
        protected Code mkLinearMoveToDepth()
        {
            Code code = new Code( GCODE.Linear_interpolation);
            code.Add(CutterDepthAxis, PCODE.Bracket(PCODE.GlobalVariable(DEPTH)));
            code.Add(GPARAM.F, PCODE.Bracket(PCODE.GlobalVariable(FEEDRATE)));
            return code;
        }

        protected Code mkRotaryMoveToPoint(Cylindrical2D pc)
        {
            Code code = new Code();
            if (Project.CodeType == GCodeType.ABSOLUTE)
            {
                code.Add(RoseOffsetAxis, Math.Round(pc.Radius,Project.Accuracy));
                code.Add(RoseSpindleAxis, Math.Round(pc.Angle, Project.Accuracy));
            }
            else
            {
                code.Add(RoseOffsetAxis, Math.Round(pc.Radius - _lastPosition.Radius,Project.Accuracy));
                code.Add(RoseSpindleAxis, Math.Round(pc.Angle - _lastPosition.Angle,Project.Accuracy));
            }
            return code;
        }

        protected Code mkRotaryMoveToPoint(Cylindrical pc)
        {
            Code code = new Code();
            if (Project.CodeType == GCodeType.ABSOLUTE)
            {
                code.Add(RoseOffsetAxis, Math.Round(pc.Radius, Project.Accuracy));
                code.Add(RoseSpindleAxis, Math.Round(pc.Angle, Project.Accuracy));
            }
            else
            {
                code.Add(RoseOffsetAxis, Math.Round(pc.Radius - _lastPosition.Radius, Project.Accuracy));
                code.Add(RoseSpindleAxis, Math.Round(pc.Angle - _lastPosition.Angle, Project.Accuracy));
            }
            return code;
        }

        protected Code mkLinearMoveToPoint(Point3D p)
        {
            Code code = new Code();
            if (Project.CodeType == GCodeType.ABSOLUTE)
            {
                code.Add(RoseOffsetAxis, Math.Round(p.X, Project.Accuracy));
                code.Add(Yaxis, Math.Round(p.Y, Project.Accuracy));
            }
            else
            {
                code.Add(RoseOffsetAxis, Math.Round(p.X - _lastPoint.X, Project.Accuracy));
                code.Add(RoseSpindleAxis, Math.Round(p.Y - _lastPoint.Y, Project.Accuracy));
            }
            _lastPoint = p;
            return code;
        }

      
    }
}
