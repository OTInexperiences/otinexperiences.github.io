﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OTWB
{
    public enum GCodeSource
    {
        ROSE,
        PUMP,
        ROSE_WITH_PUMP,
        CHUCK,
        CHUCK_AND_ROSE,
        CHUCK_AND_ROSE_WITH_PUMP
    }

    public enum GCodeType
    {
        ABSOLUTE,
        RELATIVE
    }
}
