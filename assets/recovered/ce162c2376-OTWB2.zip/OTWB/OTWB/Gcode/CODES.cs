//  
//  Copyright (C) 2009 Alan Battersby
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
// 

using System;
using System.Text;

namespace OTWB
{
	
	/// <summary>
	/// This ennumeration gives values to all gcodes
	/// </summary>
	/// 
	public class GCODE
	{
		public static string Rapid_Positioning 					= "G00";
		public static   string Linear_interpolation  				= "G01";
		public static   string CW_circular_interpolation 			= "G02";
		public static   string CCW_circular_interpolation			= "G03";
		public static   string Dwell								= "G04";
		public static   string Coordinate_system_origin_setting	= "G10";

		// G05.1 Q1. 	Ai Nano contour control
		// G05 P10000 	HPCC
		// G10/G11 	Programmable Data input/Data write cancel
		public static   string X_Y_plane_selection 				= "G17";
		public static   string X_Z_plane_selection					= "G18";
		public static   string Y_Z_plane_selection					= "G19";
		
		public static   string Programming_in_inches				= "G20";
		public static   string	Programming_in_mm					= "G21"; 
		public static   string	Return_to_home_position 			= "G28";
		
		public static   string	Second_reference_point_return 		= "G30";
		public static   string	Skip_function						= "G31";
		public static   string	Constant_pitch_threading			= "G33";
		public static   string	Variable_pitch_threading			= "G34";
		public static   string Straight_probe						= "G38.2";

		public static   string	ToolRadius_compensation_off		= "G40";
		public static   string	Tool_radius_compensation_left		= "G41";
		public static   string Tool_radius_compensation_right		= "G42";
		public static   string Tool_offset_compensation_negative 	= "G43";
		public static   string Tool_offset_compensation_positive	= "G44";
		public static   string Axis_offset_single_increase			= "G45";
		public static   string Axis_offset_single_decrease			= "G46";
		public static   string Axis_offset_double_increase			= "G47";
		public static   string Axis_offset_double_decrease			= "G48"; 
		public static   string Tool_offset_compensation_cancel		= "G49";
		
		public static   string Motion_in_machine_v2inate_system	= "G53";
		public static   string Work_coordinate_systems_1			= "G54";
		public static   string Work_coordinate_systems_2			= "G55";
		public static   string Work_coordinate_systems_3			= "G56";
		public static   string Work_coordinate_systems_4			= "G57";
		public static   string Work_coordinate_systems_5			= "G58";
		public static   string Work_coordinate_systems_6			= "G59";
		public static   string Work_coordinate_systems_7			= "G59.1";
		public static   string Work_coordinate_systems_8			= "G59.2";
		public static   string Work_coordinate_systems_9			= "G59.3";
		
		public static   string set_path_control_mode_exact_path	= "G61";
		public static   string set_path_control_mode_exact_stop	= "G61.1";
		public static   string set_path_control_mode_continuous	= "G64";


		// now missing the following codes 
		// G54.1 P1 - P48		Extended work coordinate systems
		// G73 	High speed drilling canned cycle
		// G74 	Left hand tapping canned cycle
		// G76 	Fine boring canned cycle
		// G80 	Cancel canned cycle
		// G81 	Simple drilling cycle
		// G82 	Drilling cycle with dwell
		// G83 	Peck drilling cycle
		// G84 	Tapping cycle
		// G84.2 	Direct right hand tapping canned cycle
		// G85 canned cycle: boring, no dwell, feed out
		// G86 canned cycle: boring, spindle stop, rapid out
		// G87 canned cycle: back boring
		// G88 canned cycle: boring, spindle stop, manual out
		// G89 canned cycle: boring, dwell, feed out
		
		public static   string Absolute_programming				= "G90";
		public static   string Incremental_programming				= "G91";
		public static   string offset_coordinate_systems_set_parameters 			= "G92";
		public static   string cancel_offset_coordinate_systems_set_params_to_zero	= "G92.1";
		public static   string cancel_offset_coordinate_systems					= "G92.2";
		public static   string apply_params_to_offset_coordinate_systems 			= "G92.3";
		public static 	string Inverse_time_mode					= "G93";
		public static   string Units_per_minute_feed				= "G94";
		public static   string Units_per_revolution_feed			= "G95";
		public static   string Constant_cutting_speed				= "G96"; 
		public static   string Constant_rotation_speed 			= "G97";
		public static   string Return_to_Initial_Z_plane			= "G98";
		public static   string Return_to_Initial_R_plane			= "G99";
	}
	
	public class MCODE
	{
		public static   string Program_Stop 					= "M0";
		public static   string Optional_Stop					= "M1";
		public static   string End_of_Program					= "M2";
		public static   string Spindle_on_CW_rotation			= "M3";
		public static   string Spindle_on_CCW_rotation 		= "M4";
		public static   string Spindle_off						= "M5";
		public static   string Tool_Change						= "M6";
		public static   string Coolant_on_flood				= "M7";
		public static   string Coolant_on_mist					= "M8";
		public static   string Coolant_off						= "M9";
		public static   string Pallet_clamp					= "M10";
		public static   string Pallet_un_clamp					= "M11";
		public static   string End_of_program					= "M30";
		public static   string Enable_speed_and_feed_overrides	= "M48";
		public static   string Disable_speed_and_feed_overrides= "M49";
		public static   string Pallet_shuttle_and_program_stop	= "M60";
		public static	string Call_Subroutine					= "M98";
		public static 	string End_Subroutine					= "M99";
	}
	
	public class GPARAM
	{
		public static string A 	= "A";
		public static string B 	= "B";
		public static string C 	= "C";
		public static string D 	= "D";
		public static string F 	= "F";
		public static string G 	= "G";
		public static string H 	= "H";
		public static string I 	= "I";
		public static string J 	= "J";
		public static string K 	= "K";
		public static string L 	= "L";
		public static string M 	= "M";
        public static string N = "N";
		public static string P 	= "P";
		public static string Q 	= "Q";
		public static string R 	= "R";
		public static string S 	= "S";
		public static string T 	= "T";
		public static string X 	= "X";
		public static string Y 	= "Y";
		public static string Z 	= "Z";
		
	}
	
	public class PCODE
	{
		public static string Sub			= "sub";
		public static string Endsub		= "endsub";
		public static string O			= "O";
		public static string CODE			= "code";
		public static string HASH			= "#";
		public static string OPENBRACKET	= "[";
		public static string CLOSEBRACKET	= "]";
		public static string Callsub		= "call";
		public static string EndIf 		= "endif";
		public static string Else  		= "else";
		public static string EndWhile		= "endwhile";
		public static string Do 			= "do";
		public static string Addition		= "+";
		public static string Subtraction	= "-";
		public static string Times		= "*";
		public static string Division		= "-";
		public static string OPENANGLE	= "<";
		public static string CLOSEANGLE	= ">";
		public static string UNDERSCORE	= "_";
	
		
		public static string Less_than_or_equal 	= "LE";	
		public static string Equal 					= "EQ";
		public static string Not_equal 				= "NE";
		public static string Greater_than 			= "GT";
		public static string Greater_than_or_equal 	= "GE";
		public static string Less_than 				= "LT";
		
		// pcode functions
		public static string ABS			="abs";
		
		public static string Onum(int n)
		{
			return string.Format("{0}{1}",PCODE.O,n);	
		}
		
		public static string OwordName(string n)
		{
			return string.Format("{0}{1}{2}",PCODE.OPENANGLE,n,PCODE.CLOSEANGLE);
		}
		
		public static string NamedOWord(string name)
		{
			return string.Format("{0}{1}{2}{3}", PCODE.O,PCODE.OPENANGLE,name,PCODE.CLOSEANGLE);
		}
		
		public static string Param(int n)
		{
			return string.Format("{0}{1}",PCODE.HASH,n);	
		}
		
		public static string CallParam(int n)
		{
			return Bracket(Param(n));	
		}

        public static string NumericVariable(int i)
        {
            return string.Format("#{0}", i);
        }

		public static string LocalVariable(string v)
		{
			return string.Format("{0}{1}{2}{3}",
			            PCODE.HASH,PCODE.OPENANGLE,v,PCODE.CLOSEANGLE);
		}
		
		public static string GlobalVariable(string v)
		{
			return string.Format("{0}{1}{2}{3}{4}",
			            PCODE.HASH,PCODE.OPENANGLE,PCODE.UNDERSCORE,v,PCODE.CLOSEANGLE);
		}
		
		public static string ValofGlobal(string v)
		{
			return Bracket(GlobalVariable(v));
		}
		
		public static string ValofLocal(string v)
		{
			return Bracket(LocalVariable(v));
		}
		
		public static string Valof(string v)
		{
			return Bracket(v);	
		}
		
		public static string Bracket(string expr)
		{
			return PCODE.OPENBRACKET + expr + PCODE.CLOSEBRACKET;	
		}
		
		public static string While(string test)
		{
			return string.Format("while [{0}]",test);		                     
		}
		
		public static string IncVariable(string v, string exp)
		{
			return string.Format("{0}= [{0}+{1}]",v,exp);
		}
		
		public static string Assign(string v, string expr)
		{
			return string.Format("{0} = {1}",v,expr);
		}
		
		public static string If(string cond)
		{	
			return string.Format("if [{0}]",cond);
		}
		
		public static string Test(string v1, string cond, string expr)
		{
			return string.Format("{0} {1} {2}",v1,cond,expr);
		}
		
		public static string Binary(string e1, string op, string e2)
		{
			return PCODE.Bracket(string.Format("{0} {1} {2}",e1,op,e2));	
		}
		
		public static string Mult(string e1, string e2)
		{
			return PCODE.Binary(e1,PCODE.Times,e2);	
		}
		
		public static string Add(string e1, string e2)
		{
			return PCODE.Binary(e1,PCODE.Addition,e2);	
		}
		
		public static string Subtract(string e1, string e2)
		{
			return PCODE.Binary(e1,PCODE.Subtraction,e2);	
		}
		
		public static string Divide(string e1, string e2)
		{
			return PCODE.Binary(e1,PCODE.Division,e2);	
		}
		
		public static string Literal(double n)
		{
			return n.ToString();	
		}
		
		public static string gfuncall (string fun, params string[] values)
		{
			StringBuilder sb = new StringBuilder(fun);
			for (int i=0; i < values.Length; i++)
			{
				sb.Append(' ').Append(PCODE.Bracket(values[i]));
			}
			return sb.ToString();
		}
	}
	
	public class COMMENT
	{
		public static string START		= "(";
		public static string END		= ")";
	}
}
