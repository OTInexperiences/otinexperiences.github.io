﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using BasicLib;
using System.Collections.ObjectModel;

namespace OTWB
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region My Commands
        public static RoutedCommand ShowAboutCommand = new RoutedCommand();
        public static RoutedCommand ShowEditHeadstockCommand = new RoutedCommand();

        public static RoutedCommand GenerateGcodeCommand = new RoutedCommand();
        public static RoutedCommand GeneratePathsGcodeCommand = new RoutedCommand();
        public static RoutedCommand GenerateMainSpindleOffsetsCommand = new RoutedCommand();
        public static RoutedCommand GeneratePumpSpindleOffsetsCommand = new RoutedCommand();
        public static RoutedCommand GenerateChuckOffsetsCommand = new RoutedCommand();
        public static RoutedCommand RunCommand = new RoutedCommand();
        public static RoutedCommand ImportCommand = new RoutedCommand();
        public static RoutedCommand ImportSurfaceCommand = new RoutedCommand();

        public static RoutedCommand NewProjectCommand = new RoutedCommand();
        public static RoutedCommand OpenProjectCommand = new RoutedCommand();
        public static RoutedCommand SaveProjectCommand = new RoutedCommand();
        public static RoutedCommand SaveAsProjectCommand = new RoutedCommand();
        public static RoutedCommand GenEMCMemoryMapCommand = new RoutedCommand();
        #endregion

        ProjectInfo _pinfo;
        OffsetGenerator _ofgen;
        Offsets _offsets;
        SurfaceManager _surfman;

        MachiningData _mdata;
        CodeGenerator _codegen;
        GcodeManager _codeman;
        GcodeProgram _gcode;
        PathList _pathlist;

        Random PathIDGenerator = new Random(DateTime.Now.Millisecond);

        // properties

        public static readonly DependencyProperty HeadstockProp;

        public Headstock HeadStock
        {
            get { return (Headstock)GetValue(HeadstockProp); }
            set { SetValue(HeadstockProp, value); }
        }

        public ProjectInfo Project
        {
            get { return _pinfo; }
            set { _pinfo = value; }
        }

        public string ProjectFolder
        {
            get
            {
                if (_pinfo.ProjectPath != string.Empty)
                    return _pinfo.ProjectPath;
                else
                {
                    string path = BasicLib.Properties.Settings.Default.ProjectsFolder;
                    path = System.IO.Path.Combine(path, _pinfo.ProjectName);
                    _pinfo.ProjectPath = path;
                    return path;
                }
            }
        }

        static MainWindow()
        {
            MainWindow.HeadstockProp = DependencyProperty.Register("HeadStock", typeof(Headstock), typeof(MainWindow));
        }

        public void CheckFoldersExist()
        {
            if (!Directory.Exists(BasicLib.Properties.Settings.Default.ProjectsFolder) ||
                !Directory.Exists(BasicLib.Properties.Settings.Default.LibraryFolder))
            {
                CheckFolderPaths fp = new CheckFolderPaths();
                while (!(bool)fp.ShowDialog())
                {
                    MessageBox.Show("OTWB needs a valid Project and Library path");
                }
            }
        }

        public MainWindow()
        {
            InitializeComponent();
           
            #region Command Bindings
            CommandBinding cb = new CommandBinding(ShowAboutCommand,
                   ShowAboutWindowExecute, ShowAboutWindowCanExecute);
            this.CommandBindings.Add(cb);
            this.AboutItem.Command = ShowAboutCommand;

            cb = new CommandBinding(NewProjectCommand,
                    NewCmdExecuted, NewCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.NewProjectItem.Command = NewProjectCommand;

            cb = new CommandBinding(OpenProjectCommand,
                   OpenCmdExecuted, OpenCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.OpenProjectItem.Command = OpenProjectCommand;

            cb = new CommandBinding(SaveProjectCommand,
                  SaveCmdExecuted, SaveCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.SaveProjectItem.Command = SaveProjectCommand;

            cb = new CommandBinding(SaveAsProjectCommand,
                  SaveAsCmdExecuted, SaveAsCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.SaveAsProjectItem.Command = SaveAsProjectCommand;

            cb = new CommandBinding(GeneratePathsGcodeCommand,
            this.GeneratePathsGcodeCmdExecuted, this.GenerateGcodeCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.GenPathsGcodeItem.Command = GeneratePathsGcodeCommand;

            cb = new CommandBinding(GenerateGcodeCommand,
             this.GenerateGcodeCmdExecuted, this.GenerateGcodeCmdCanExecute);
            this.CommandBindings.Add(cb);

            this.GenRoseGcodeItem.Command = GenerateGcodeCommand;
            this.GenPumpGcodeItem.Command = GenerateGcodeCommand;
            this.GenRosePumpGcodeItem.Command = GenerateGcodeCommand;
            this.GenChuckGcodeItem.Command = GenerateGcodeCommand;
            this.GenRoseChuckGcodeItem.Command = GenerateGcodeCommand;
            this.GenAllGcodeItem.Command = GenerateGcodeCommand;

            cb = new CommandBinding(GenerateMainSpindleOffsetsCommand,
           this.GenerateMainSpindleOffsetsCmdExecuted, this.GenerateMainSpindleOffsetsCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.GenMainSpindleOffsetsItem.Command = GenerateMainSpindleOffsetsCommand;

            cb = new CommandBinding(GeneratePumpSpindleOffsetsCommand,
            this.GeneratePumpSpindleOffsetsCmdExecuted, this.GeneratePumpSpindleOffsetsCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.GenPumpSpindleOffsetsItem.Command = GeneratePumpSpindleOffsetsCommand;

            cb = new CommandBinding(GenerateChuckOffsetsCommand,
           this.GenerateChuckOffsetsCmdExecuted, this.GenerateChuckOffsetsCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.GenChuckOffsetsItem.Command = GenerateChuckOffsetsCommand;

            cb = new CommandBinding(RunCommand,
            this.RunCmdExecuted, this.RunCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.RunHSItem.Command = RunCommand;

            cb = new CommandBinding(ImportCommand, this.ImportCmdExecuted, this.ImportCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.ImportMainItem.Command = ImportCommand;
            this.ImportPumpItem.Command = ImportCommand;
            this.ImportChuckItem.Command = ImportCommand;

            cb = new CommandBinding(ImportSurfaceCommand,
                               this.ImportSurfaceCmdExecuted,
                               this.ImportSurfaceCmdCanExecute);

            this.CommandBindings.Add(cb);
            this.ImportSurfaceItem.Command = ImportSurfaceCommand;

            cb = new CommandBinding(GenEMCMemoryMapCommand,
                                    this.GenEMCMemoryMapCmdExecuted,
                                    this.GenEMCMemoryMapCmdCanExecute);
            this.CommandBindings.Add(cb);
            this.GenEMCMemoryMap.Command = GenEMCMemoryMapCommand;
            #endregion
            CheckFoldersExist();
            setWindowTitle();
            _pinfo = new ProjectInfo();
            _pinfo.ProjectPath = BasicLib.Properties.Settings.Default.ProjectsFolder;
            SetValue(HeadstockProp, new Headstock());
            HeadStock.Name = _pinfo.ProjectName;

            _ofgen = new OffsetGenerator();
            _surfman = new SurfaceManager();
            SurfaceItem.DataContext = _surfman.Surface;
            wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
            wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
            _offsets = new Offsets();
            OffsetViewer1.DataContext = _offsets;
            OffsetViewer1.tabControl1.SelectionChanged += new SelectionChangedEventHandler(tabControl1_SelectionChanged);
            _mdata = new  MachiningData();
            _codegen = new  CodeGenerator();
            _codeman = new GcodeManager();
            _codeman.Project = _pinfo;
            CodeManagerItem.DataContext = _codeman;
            _pathlist = new PathList();
            PathViewer1.Paths = _pathlist;
            PathItemList.DataContext = _pathlist;

            PathViewer1.MaxWorkPieceRadius = OTWB.Properties.Settings.Default.DefaultMaxWorkpieceRadius;
            PathsCanvas3D.Paths = _pathlist;
            PathsCanvas3D.MaxWorkPieceRadius = OTWB.Properties.Settings.Default.DefaultMaxWorkpieceRadius;
            // fix up viewers etc
            SurfaceViewer1.Manager = _surfman;
            CodeViewer1.Info = _pinfo;
            ChuckPathViewer1.Chuck = HeadStock.Chuck;
            populateSolutionExplorer();
            //MessageBox.Show(System.Reflection.Assembly.GetExecutingAssembly().Location);
            SpindleViewer1.Rosettes_Display.RosetteSelected +=Rosettes_Display_RosetteSelected;
        }

        public void Rosettes_Display_RosetteSelected(object sender, EventArgs e)
        {
            wpfPropertyGrid1.SelectedObject = sender as Rosette;
        }

        public void tabControl1_SelectionChanged(Object sender, SelectionChangedEventArgs e)
        {
            if (OffsetViewer1.RoseTab.IsSelected)
            {
                if ((_pinfo != null) && (HeadStock.MainSpindle != null) && (HeadStock.MainSpindle.Rosettes.Count > 0))
                    GenerateMainSpindleOffsets();
            }
            else if (OffsetViewer1.PumpTab.IsSelected)
            {
                if ((_pinfo != null) && (HeadStock.PumpSpindle != null) && (HeadStock.PumpSpindle.Rosettes.Count > 0))
                    GeneratePumpSpindleOffsets();
            }
            else if (OffsetViewer1.ChuckTab.IsSelected)
            {
                if ((_pinfo != null) && (HeadStock.Chuck != null) && (HeadStock.Chuck.Stages.Count > 0))
                    GenerateChuckOffsets();
            }
            else if (OffsetViewer1.PathTab.IsSelected)
            {
                if (_pathlist.Count > 0)
                    OffsetViewer1.Path = _pathlist[0].Points;
            }
        }

        #region Command Code

        void OpenCmdExecuted(object target, ExecutedRoutedEventArgs e)
        {
            String command, targetobj;
            command = ((RoutedCommand)e.Command).Name;
            targetobj = ((FrameworkElement)target).Name;
            string path = ImportFilename("project",
                                        BasicLib.Properties.Settings.Default.ProjectsFolder,
                                        BasicLib.Properties.Settings.Default.ProjectInfoExtension);
         
            if (path != string.Empty)
            {
                // Open document
               
                _pinfo = Serializer<ProjectInfo>.ReadFile(path);
                _pinfo.ProjectPath = System.IO.Path.GetDirectoryName(path);
                _pinfo.ProjectName = System.IO.Path.GetFileNameWithoutExtension(path);
                setWindowTitle();
                OpenHeadstock();
                HeadStock.AngleRange = _pinfo.Chuck_Angle_Range;
                
                ToolTableItem.DataContext = _pinfo.ToolTable;
                OpenSurface();
                CodeViewer1.Info = _pinfo;
                _codeman.Project = _pinfo;
                populateSolutionExplorer();
                ExpandProjectExplorer();
            }

        }

        private void ExpandProjectExplorer()
        {
            // manually expand all nodes 
            MyProjectItem.IsExpanded = true;
            HeadstockItem.IsExpanded = true;
            if (HeadStock.MainSpindle.Count > 0)
            {
                MainSpindleItem.IsExpanded = true;
                RosettesItem.IsExpanded = true;
            }
            if (HeadStock.PumpSpindle.Count > 0)
            {
                PumpSpindleItem.IsExpanded = true;
                PumpRosettes.IsExpanded = true;
            }
            if (_pinfo.UsesSurface)
            {
                SurfaceItem.IsExpanded = true;
                ProfilesItem.IsExpanded = true;
            }
            if (HeadStock.Chuck != null && HeadStock.Chuck.Stages.Count > 0)
            {
                ChuckItem.IsExpanded = true;
                ChuckStages.IsExpanded = true;
            }
        }

        void SaveAsCmdExecuted(object target, ExecutedRoutedEventArgs e)
        {
            string fn = ExportFilename("Project info",
                                            _pinfo.ProjectName,
                                            BasicLib.Properties.Settings.Default.ProjectsFolder,
                                            BasicLib.Properties.Settings.Default.ProjectInfoExtension);
            /*
            String command, targetobj;
            command = ((RoutedCommand)e.Command).Name;
            targetobj = ((FrameworkElement)target).Name;
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.InitialDirectory = BasicLib.Properties.Settings.Default.ProjectsFolder;
            dlg.FileName = _pinfo.ProjectName; // Default file name
            dlg.DefaultExt = BasicLib.Properties.Settings.Default.ProjectInfoExtension;
            dlg.Filter = string.Format("Project info (.{0})|*.{0} | All Files (*.*)|*.*",
                        BasicLib.Properties.Settings.Default.ProjectInfoExtension);
            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();
            */
            // Process open file dialog box results
            if (fn != string.Empty)
            {
                // Open document
                Serializer<ProjectInfo>.WriteFile(fn, _pinfo);
                saveHeadstock();
            }

        }

        private void saveHeadstock()
        {
            try
            {
                string headstockfile = string.Empty;

                if (_pinfo.HeadStockName == string.Empty || _pinfo.ProjectPath == string.Empty)
                {
                    string fn = ExportFilename("Headstock", 
                                               _pinfo.ProjectName,
                                                BasicLib.Properties.Settings.Default.ProjectsFolder,
                                                BasicLib.Properties.Settings.Default.HeadstockFileExtension);
                    
                    if (fn != string.Empty)
                    {
                        headstockfile = fn;
                        _pinfo.HeadStockName = System.IO.Path.GetFileNameWithoutExtension(fn);
                    }
                }
                else
                {
                    headstockfile = System.IO.Path.Combine(_pinfo.ProjectPath, _pinfo.HeadStockName);
                    headstockfile = System.IO.Path.ChangeExtension(headstockfile, BasicLib.Properties.Settings.Default.HeadstockFileExtension);
                }
                Serializer<Headstock>.WriteFile(headstockfile, (Headstock)GetValue(HeadstockProp));
            }
            catch (Exception)
            {

            }

        }
        void saveProjectInfo()
        {
            if ((_pinfo != null) && (_pinfo.ProjectPath != null))
            {
               
                string path = System.IO.Path.Combine(_pinfo.ProjectPath, _pinfo.ProjectName);
                path = System.IO.Path.ChangeExtension(path, BasicLib.Properties.Settings.Default.ProjectInfoExtension);
                Console.WriteLine("Saving project name {0} project path {1}   info file {2}", _pinfo.ProjectName, _pinfo.ProjectPath,path);
                Serializer<ProjectInfo>.WriteFile(path, _pinfo);
            }
        }
        void SaveCmdExecuted(object target, ExecutedRoutedEventArgs e)
        {
            String command, targetobj;
            command = ((RoutedCommand)e.Command).Name;
            targetobj = ((FrameworkElement)target).Name;
            saveProjectInfo();
            saveHeadstock();
        }
        void SaveCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = (_pinfo != null) && (_pinfo.ProjectPath != null); ;
        }
        void SaveAsCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = _pinfo != null; ;
        }
        void OpenCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        void NewCmdExecuted(object target, ExecutedRoutedEventArgs e)
        {
            String command, targetobj;
            command = ((RoutedCommand)e.Command).Name;
            targetobj = ((FrameworkElement)target).Name;
            _pinfo = new ProjectInfo();
          

            string fn = ExportFilename("Project",
                                        string.Empty,
                                        BasicLib.Properties.Settings.Default.ProjectsFolder,
                                        BasicLib.Properties.Settings.Default.ProjectInfoExtension);
            /*
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.InitialDirectory = BasicLib.Properties.Settings.Default.ProjectsFolder;
            dlg.FileName = string.Format("project.{0}", BasicLib.Properties.Settings.Default.ProjectInfoExtension);// Default file name
            dlg.DefaultExt = BasicLib.Properties.Settings.Default.ProjectInfoExtension;
            dlg.Filter = string.Format("Project info(*.{0})|*.{0}|All Files(*.*)|*.*",
                        BasicLib.Properties.Settings.Default.ProjectInfoExtension);
            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();
             * */
            // Process open file dialog box results
            if (fn != string.Empty)
            {
                // Open document
                HeadStock = new Headstock();
                string pname = System.IO.Path.GetFileNameWithoutExtension(fn);
                Console.WriteLine("New Project is {0}", pname);
                _pinfo.ProjectName = pname; // System.IO.Path.GetDirectoryName(fn);
                HeadStock.Name = _pinfo.ProjectName;
                _pinfo.HeadStockName = _pinfo.ProjectName;
                _pinfo.ProjectPath = System.IO.Path.GetDirectoryName(fn);
                saveHeadstock();
                saveProjectInfo();
                //Serializer<ProjectInfo>.WriteFile(fn, _pinfo);
                setWindowTitle();
                CodeViewer1.Info = _pinfo;
                _codeman.Project = _pinfo;
                populateSolutionExplorer();
                ExpandProjectExplorer();
            }

        }
        void NewCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        //void HelpCmdExecuted(object target, ExecutedRoutedEventArgs e)
        //{
        //    String command, targetobj;
        //    command = ((RoutedCommand)e.Command).Name;
        //    targetobj = ((FrameworkElement)target).Name;

        //    MessageBox.Show("showing helpfile {0}",HelpProvider.Help.FilenameProperty.ToString());
        //}
        //void HelpCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        //{
        //    e.CanExecute = true;
        //}
        private void ShowAboutWindowCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void ShowAboutWindowExecute(object sender, ExecutedRoutedEventArgs e)
        {
            WPFAboutBox1 about = new WPFAboutBox1(this);
            about.ShowDialog();
        }
        private void ShowEditHeadstockWindowCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void ShowEditHeadstockWindowExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                //wpfPropertyGrid1.SelectedObject = GetValue(HeadstockProp);
            }
            catch (InvalidOperationException) { }
        }

        void GeneratePathsGcodeCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            //first check that paths are there
            if (_pathlist.Count == 0)
                return;

            _codegen.Project = _pinfo;
            _gcode = _codegen.RenderGCodeFromPathList(_pathlist);
        }

        void GenerateGcodeCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            //first check that offsets are there
             GCodeSource src = ( GCodeSource)e.Parameter;
            CheckOffsetsExist(src);
            _codegen.Project = _pinfo;
            _gcode = _codegen.RenderGCodeProgram(_offsets, src, _surfman.Surface);
            GcodeProgramItem itm = new GcodeProgramItem(_pinfo.ProjectName,
                                                        _gcode,
                                                        GcodeProgramType.MAIN,
                                                        "Main program for project");
            _codeman.Items.Add(itm);
            CodeViewer1.Gcode = itm;
        }
        void RunCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            if (HeadStock.AngleRange == null)
                HeadStock.AngleRange = _pinfo.Chuck_Angle_Range;
            Path path = new Path(PathIDGenerator.Next());
            HeadStock.GeneratePath(ref path);
            _pathlist.Add(path);
        }

        void RunCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = _pinfo != null;
        }

        void GenerateGcodeCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = _pinfo != null;
        }

        void GenerateMainSpindleOffsetsCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = (_pinfo != null) &&
                            (HeadStock != null) &&
                            (HeadStock.MainSpindle != null) &&
                            (HeadStock.MainSpindle.Rosettes.Count > 0);
        }
        void GenerateMainSpindleOffsetsCmdExecuted(object target, ExecutedRoutedEventArgs e)
        {
            if (_pinfo == null) return;
            GenerateMainSpindleOffsets();
        }

        public void GenerateMainSpindleOffsets()
        {
            AXIS rx = _pinfo.AXIS2;
            AXIS ax = _pinfo.AXIS0;

            SetupOffsetGeneratorData();

            _offsets.MainSpindle_Offsets = _ofgen.GenerateOffsets(HeadStock.MainSpindle, ax, rx);
            
            OffsetViewer1.RoseSpindleOffsetDataGrid.ItemsSource = _offsets.MainSpindle_Offsets;

            OffsetViewer1.RoseAngleUnitsPerStepLabel.DataContext
                = Utilities.Round(_ofgen.StepData.UnitsPerStep(ax));
            OffsetViewer1.RoseAngleStepsPerUnitLabel.DataContext
                = Utilities.Round(_ofgen.StepData.StepsPerUnit(ax));

            OffsetViewer1.RoseOffsetUnitsPerStepLabel.DataContext
               = Utilities.Round(_ofgen.StepData.UnitsPerStep(rx));
            OffsetViewer1.RoseOffsetStepsPerUnitLabel.DataContext
                = Utilities.Round(_ofgen.StepData.StepsPerUnit(rx));
             
        }
        public void GeneratePumpSpindleOffsets()
        {
            AXIS rx = _pinfo.AXIS1;  // Pumping axis 
            AXIS ax = _pinfo.AXIS0;  // Spindle Rotation axis

            SetupOffsetGeneratorData();
            _offsets.Pump_Offsets = _ofgen.GenerateOffsets(HeadStock.PumpSpindle, ax, rx);
            
            OffsetViewer1.PumpSpindleOffsetDataGrid.ItemsSource = _offsets.Pump_Offsets;
            OffsetViewer1.PumpAngleUnitsPerStepLabel.DataContext
                = Utilities.Round(_ofgen.StepData.UnitsPerStep(ax));
            OffsetViewer1.PumpAngleStepsPerUnitLabel.DataContext
                = Utilities.Round(_ofgen.StepData.StepsPerUnit(ax));

            OffsetViewer1.PumpOffsetUnitsPerStepLabel.DataContext
               = Utilities.Round(_ofgen.StepData.UnitsPerStep(rx));
            OffsetViewer1.PumpOffsetStepsPerUnitLabel.DataContext
                = Utilities.Round(_ofgen.StepData.StepsPerUnit(rx));
             
        }
        public void GenerateChuckOffsets()
        {
            SetupOffsetGeneratorData();
            AXIS ax = _pinfo.AXIS0;
            AXIS rx = _pinfo.AXIS2;

            if (HeadStock.Chuck.AngleRange == null)
                HeadStock.AngleRange = _pinfo.Chuck_Angle_Range;

            HeadStock.Chuck.CreatePath();
            _offsets.Chuck_Offsets = _ofgen.GenerateChuckOffsets(HeadStock.Chuck, ax, rx);

            
            OffsetViewer1.ChuckPathDataGrid.ItemsSource = _offsets.Chuck_Offsets;
            OffsetViewer1.ChuckAngleUnitsPerStepLabel.DataContext
                 = Utilities.Round(_ofgen.StepData.UnitsPerStep(ax));
            OffsetViewer1.ChuckAngleStepsPerUnitLabel.DataContext
                = Utilities.Round(_ofgen.StepData.StepsPerUnit(ax));

            OffsetViewer1.ChuckOffsetUnitsPerStepLabel.DataContext
                = Utilities.Round(_ofgen.StepData.UnitsPerStep(rx));
            OffsetViewer1.ChuckOffsetStepsPerUnitLabel.DataContext
                = Utilities.Round(_ofgen.StepData.StepsPerUnit(rx));
             
        }

        void GeneratePumpSpindleOffsetsCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = (HeadStock != null) &&
                            (HeadStock.PumpSpindle != null) &&
                            ((HeadStock.PumpSpindle.Rosettes.Count > 0) ||
                             (_pinfo.UsesSurface && (_pinfo.SurfaceNormal == _pinfo.AXIS1)));
        }
        void GeneratePumpSpindleOffsetsCmdExecuted(object target, ExecutedRoutedEventArgs e)
        {
            GeneratePumpSpindleOffsets();
        }

        void GenerateChuckOffsetsCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = (HeadStock != null) &&
                           (HeadStock.Chuck != null) &&
                           (HeadStock.Chuck.Stages.Count > 0);

        }
        void GenerateChuckOffsetsCmdExecuted(object target, ExecutedRoutedEventArgs e)
        {
            GenerateChuckOffsets();
        }

        void GenEMCMemoryMapCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = (_pinfo != null);
        }

       

        #region Import - Export Code
        void ImportCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            ImportItem(( GCodeSource)e.Parameter);
        }

        private void ImportItem( GCodeSource src)
        {
            MessageBox.Show("Importing" + src.ToString());
        }

        private void Import_Rosette_to_Main_Click(object sender, RoutedEventArgs e)
        {
            string fn = ImportFilename("Rosette",
                                       BasicLib.Properties.Settings.Default.RosetteFolder,
                                       BasicLib.Properties.Settings.Default.RosetteFileExtension);
            if (fn == string.Empty)
                return;
            Rosette r = Serializer<Rosette>.ReadFile(fn);
            if (r != null)
                HeadStock.MainSpindle.add(r);
        }
        private void Import_Rosette_to_Pump_Click(object sender, RoutedEventArgs e)
        {
            string fn = ImportFilename("Rosette",
                                       BasicLib.Properties.Settings.Default.RosetteFolder,
                                       BasicLib.Properties.Settings.Default.RosetteFileExtension); 
            if (fn == string.Empty)
                return;
            Rosette r = Serializer<Rosette>.ReadFile(fn);
            if (r != null)
                HeadStock.PumpSpindle.add(r);
        }

        private string ImportFilename(string name,string folder, string ext)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.InitialDirectory = folder;
            //dlg.FileName = string.Format("project.{0}",Properties.Settings.Default.ProjectInfoExtension);// Default file name
            dlg.DefaultExt = ext;
            dlg.Filter = string.Format("{0}(*.{1})|*.{1}|All Files(*.*)|*.*",name,ext);
            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process open file dialog box results
            if (result == true)
            {
                return dlg.FileName;
            }
            else
                return string.Empty;
        }
        private string ExportFilename(string filtername, string suggestedname,string folder, string ext)
        {
           Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
           dlg.InitialDirectory = folder;
           dlg.FileName = suggestedname; // Default file name
           dlg.AddExtension = true;
           dlg.DefaultExt = ext;
           dlg.Filter = string.Format("{0}(*.{1})|*.{1}|All Files(*.*)|*.*", filtername,ext );

                // Show open file dialog box
           Nullable<bool> result = dlg.ShowDialog();

           // Process open file dialog box results
           if (result == true)
               return dlg.FileName;
           else
               return string.Empty;
        }

        /*
        private string ImportRosetteFilename()
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.InitialDirectory = BasicLib.Properties.Settings.Default.RosetteFolder;
            //dlg.FileName = string.Format("project.{0}",Properties.Settings.Default.ProjectInfoExtension);// Default file name
            dlg.DefaultExt = BasicLib.Properties.Settings.Default.RosetteFileExtension;
            dlg.Filter = string.Format("Rosette(*.{0})|*.{0}|All Files(*.*)|*.*",
                        BasicLib.Properties.Settings.Default.RosetteFileExtension);
            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process open file dialog box results
            if (result == true)
            {
                return dlg.FileName;
            }
            else
                return string.Empty;
        }
        */
        private void Export_Rosette_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is Rosette)
            {
                Rosette r = (ProjectExplorer.Tag as Rosette);
                string fn = ExportFilename("Rosette",
                                           r.StandardName,
                                           BasicLib.Properties.Settings.Default.RosetteFolder,
                                           BasicLib.Properties.Settings.Default.RosetteFileExtension);
              
                // Process open file dialog box results
                if (fn != string.Empty)
                    Serializer<Rosette>.WriteFile(fn, r);
            }
        }

        void ImportSurfaceCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            Import_Surface();
        }
        void ImportSurfaceCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true; ;
        }

        #endregion

        void CheckOffsetsExist( GCodeSource src)
        {
            switch (src)
            {
                case  GCodeSource.CHUCK:
                    if (_offsets.Chuck_Offsets.Count == 0)
                        GenerateChuckOffsets();
                    break;
                case  GCodeSource.ROSE:
                    if (_offsets.MainSpindle_Offsets.Count == 0)
                        GenerateMainSpindleOffsets();
                    break;
                case  GCodeSource.PUMP:
                    if (_offsets.Pump_Offsets.Count == 0)
                        GeneratePumpSpindleOffsets();
                    break;
                case  GCodeSource.CHUCK_AND_ROSE:
                    if (_offsets.Chuck_Offsets.Count == 0)
                        GenerateChuckOffsets();
                    if (_offsets.MainSpindle_Offsets.Count == 0)
                        GenerateMainSpindleOffsets();
                    break;
                case  GCodeSource.ROSE_WITH_PUMP:
                    if (_offsets.MainSpindle_Offsets.Count == 0)
                        GenerateMainSpindleOffsets();
                    if (_offsets.Pump_Offsets.Count == 0)
                        GeneratePumpSpindleOffsets();
                    break;
                case  GCodeSource.CHUCK_AND_ROSE_WITH_PUMP:
                    if (_offsets.MainSpindle_Offsets.Count == 0)
                        GenerateMainSpindleOffsets();
                    if (_offsets.Pump_Offsets.Count == 0)
                        GeneratePumpSpindleOffsets();
                    if (_offsets.Chuck_Offsets.Count == 0)
                        GenerateChuckOffsets();
                    break;
            }
        }

        private void SetupOffsetGeneratorData()
        {
            if (HeadStock.AngleRange == null)
                _ofgen.Range = new Range(Properties.Settings.Default.Generator_Range_Start,
                                     Properties.Settings.Default.Generator_Range_Increment,
                                     Properties.Settings.Default.Generator_Range_End);
            else
            {
                _ofgen.Range = HeadStock.AngleRange;

            }
            _ofgen.StepData = CalcStepperData();
            _ofgen.UsingSurface = _pinfo.UsesSurface;
            if (_pinfo.UsesSurface)
            {
                _ofgen.Surface = _surfman.Surface;
                _ofgen.SurfaceNormal = _pinfo.SurfaceNormal;
            }
        }

        private void OpenHeadstock()
        {
            if (_pinfo.HeadStockName.Length > 0)
            {
                string path = System.IO.Path.Combine(_pinfo.ProjectPath, _pinfo.HeadStockName);
                path = System.IO.Path.ChangeExtension(path, BasicLib.Properties.Settings.Default.HeadstockFileExtension);
                if (System.IO.File.Exists(path))
                {
                    HeadStock = Serializer<Headstock>.ReadFile(path);
                    HeadStock.FixUpSpindles();
                    // if chuck has stages then connect up event handler
                    if (HeadStock.Chuck.NumStages > 0)
                    {
                        foreach (Stage s in HeadStock.Chuck.Stages)
                            s.StageDataChanged += new EventHandler(HeadStock.Chuck.StageDataChanged);
                    }
                }
                else
                {
                    MessageBox.Show(string.Format("Headstock file {0} does not exist. Creating new Headstock", path));
                    HeadStock = new Headstock();
                    _pinfo.HeadStockName = HeadStock.Name;
                }
            }
            else
            {
                HeadStock = new Headstock();
                _pinfo.HeadStockName = HeadStock.Name;
            }
            HeadStock.Project = _pinfo;
            /*
            HeadStock.MainSpindle.OutlineChanged += new EventHandler(
                                                         delegate(object sender, EventArgs args)
                                                         {
                                                             this.RedrawSpindleOutline(HeadStock.MainSpindle);
                                                         });
            HeadStock.PumpSpindle.OutlineChanged += new EventHandler(
                                                         delegate(object sender, EventArgs args)
                                                         {
                                                             this.RedrawSpindleOutline(HeadStock.PumpSpindle);
                                                         });
             * */
            populateSolutionExplorer();

        }

        private void populateSolutionExplorer()
        {
            if (HeadstockProp != null)
            {
                MainSpindleItem.DataContext = HeadStock.MainSpindle;
                PumpSpindleItem.DataContext = HeadStock.PumpSpindle;
                ChuckItem.DataContext = HeadStock.Chuck;
                ToolTableItem.DataContext = _pinfo.ToolTable;
            }
        }

        void setWindowTitle()
        {
            string projname = (_pinfo == null)
                ? string.Empty
                : _pinfo.ProjectName;
            this.Title = string.Format("{0} : {1}",
                BasicLib.Properties.Settings.Default.ProgramName, projname);
        }

        private void OpenSurface()
        {
            if (_pinfo.UsesSurface)
            {
                string path = ProjectFolder;
                path = System.IO.Path.Combine(path, _pinfo.ProjectName);
                path = System.IO.Path.ChangeExtension(path, BasicLib.Properties.Settings.Default.SurfaceFileExt);
                if (_surfman.Open(path))
                {
                    // hitch up to display
                    SurfaceItem.DataContext = _surfman.Surface;
                }

            }
        }

        void ImportCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = _pinfo != null;
        }
        #endregion

        #region Project Explorer Selections
        private void PumpRosettes_Selected(object sender, RoutedEventArgs e)
        {
            if (e.OriginalSource is TreeViewItem)
            {
                TreeViewItem lb = (TreeViewItem)e.OriginalSource;
                if (lb.DataContext is Rosette)
                {
                    ProjectExplorer.Tag = lb.DataContext;
                    try
                    {
                        wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                        wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                        wpfPropertyGrid1.SelectedObject = (lb.DataContext as Rosette);
                    }
                    catch (InvalidOperationException) { }
                    Headstock h = (Headstock)GetValue(HeadstockProp);
                    SpindleViewer1.Spindle = h.PumpSpindle;
                    SpindleViewer1.DrawRosettes((lb.DataContext as Rosette).Name);
                }
                e.Handled = true;
            }
        }
        private void HeadstockItem_Selected(object sender, RoutedEventArgs e)
        {
            if (e.OriginalSource is TreeViewItem)
            {
                try
                {
                    wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                    wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                    wpfPropertyGrid1.SelectedObject = HeadStock;
                }
                catch (InvalidOperationException) { }
            }
        }
        private void Rosettes_Selected(object sender, RoutedEventArgs e)
        {
            //Debug.Print(e.OriginalSource.ToString());
            if (e.OriginalSource is TreeViewItem)
            {
                TreeViewItem lb = (TreeViewItem)e.OriginalSource;
                if (lb.DataContext is Rosette)
                {
                    ProjectExplorer.Tag = lb.DataContext;
                    try
                    {
                        wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                        wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                        wpfPropertyGrid1.ShowTabs = false;
                        wpfPropertyGrid1.SelectedObject = lb.DataContext;
                    }
                    catch (InvalidOperationException) { }
                    Headstock h = (Headstock)GetValue(HeadstockProp);
                    SpindleViewer1.Spindle = h.MainSpindle;
                    SpindleViewer1.DrawRosettes((lb.DataContext as Rosette).Name);
                }
                e.Handled = true;
            }
        }
        private void Chuck_Selected(object sender, RoutedEventArgs e)
        {
            //Debug.Print(e.OriginalSource.ToString());
            if (e.OriginalSource is TreeViewItem)
            {
                TreeViewItem lb = (TreeViewItem)e.OriginalSource;

                if (lb.DataContext is Chuck)
                {
                    try
                    {
                        wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                        wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                        wpfPropertyGrid1.SelectedObject = (lb.DataContext as Chuck);
                    }
                    catch (InvalidOperationException) { }
                }
                Headstock h = (Headstock)GetValue(HeadstockProp);
                if (h.Chuck != null)
                {
                    h.Chuck.CreatePath();
                    ChuckPathViewer1.Chuck = h.Chuck;
                }
                e.Handled = true;
            }
        }
        private void ChuckStages_Selected(object sender, RoutedEventArgs e)
        {
            //Debug.Print(e.OriginalSource.ToString());
            if (e.OriginalSource is TreeViewItem)
            {
                TreeViewItem lb = (TreeViewItem)e.OriginalSource;
                if (lb.DataContext is Stage)
                {
                    ProjectExplorer.Tag = lb.DataContext;
                    try
                    {
                        wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                        wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                        wpfPropertyGrid1.SelectedObject = (lb.DataContext as Stage);
                    }
                    catch (InvalidOperationException) { }
                    e.Handled = true;
                }
            }
        }
        private void RoseSpindle_Selected(object sender, RoutedEventArgs e)
        {
            try
            {
                wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                wpfPropertyGrid1.SelectedObject = HeadStock.MainSpindle;
            }
            catch (InvalidOperationException) { }
            SpindleViewer1.Spindle = HeadStock.MainSpindle;           
            e.Handled = true;
        }
       
        private void PumpSpindle_Selected(object sender, RoutedEventArgs e)
        {
            try
            {
                wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                wpfPropertyGrid1.SelectedObject = HeadStock.PumpSpindle;
            }
            catch (InvalidOperationException) { }
            SpindleViewer1.Spindle = HeadStock.PumpSpindle;
            e.Handled = true;
        }
        private void General_Selected(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Debug.Print("general Selected");
            try
            {
                wpfPropertyGrid1.RequiredAttribute = null;
                wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                wpfPropertyGrid1.SelectedObject = new General_Data();
            }
            catch (InvalidOperationException) { }
        }
        private void Main_Settings_Selected(object sender, RoutedEventArgs e)
        {
            try
            {
                wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.Expander;
                wpfPropertyGrid1.SelectedObject = _pinfo;
            }
            catch (InvalidOperationException) { }
        }

        private void ToolTableItem_Selected(object sender, RoutedEventArgs e)
        {
            if (e.OriginalSource is TreeViewItem)
            {
                TreeViewItem lb = (TreeViewItem)e.OriginalSource;
                if (lb.DataContext is  ToolInfo)
                {
                    ProjectExplorer.Tag = lb.DataContext;
                    try
                    {
                        wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                        wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                        wpfPropertyGrid1.SelectedObject = (lb.DataContext as  ToolInfo);
                    }
                    catch (InvalidOperationException) { }
                }
                e.Handled = true;
            }
        }
        private void MachiningDataItem_Selected(object sender, RoutedEventArgs e)
        {
            if (_pinfo == null)
                return;
            try
            {
                wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                wpfPropertyGrid1.SelectedObject = _pinfo.MachiningData;
            }
            catch (InvalidOperationException) { }
            e.Handled = true;
        }
        private void Folders_Selected(object sender, RoutedEventArgs e)
        {
            try
            {
                wpfPropertyGrid1.RequiredAttribute = null;
                wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                wpfPropertyGrid1.SelectedObject = new File_Properties();
            }
            catch (InvalidOperationException) { }
            e.Handled = true;
        }
        private void DisplayData_Selected(object sender, RoutedEventArgs e)
        {
            try
            {
                wpfPropertyGrid1.RequiredAttribute = null;
                wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                wpfPropertyGrid1.SelectedObject = new Display_Property_Values();
            }
            catch (InvalidOperationException) { }
            e.Handled = true;
        }
        private void StepperData_Selected(object sender, RoutedEventArgs e)
        {
            try
            {
                wpfPropertyGrid1.RequiredAttribute = null;
                wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.Expander;
                wpfPropertyGrid1.SelectedObject = new StepperDisplayData();
            }
            catch (InvalidOperationException) { }
            e.Handled = true;
        }
        private void SurfaceItem_Selected(object sender, RoutedEventArgs e)
        {
            try
            {
                wpfPropertyGrid1.RequiredAttribute = null;
                wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                wpfPropertyGrid1.SelectedObject = (e.OriginalSource as TreeViewItem).DataContext;
            }
            catch (InvalidOperationException) { }
            e.Handled = true;
        }
        private void ProfilesItem_Selected(object sender, RoutedEventArgs e)
        {
            if (e.OriginalSource is TreeViewItem)
            {
                TreeViewItem lb = (TreeViewItem)e.OriginalSource;
                if (lb.DataContext is Profile)
                {
                    ProjectExplorer.Tag = lb.DataContext;
                }
                try
                {
                    Profile p = lb.DataContext as Profile;
                    wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                    wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                    wpfPropertyGrid1.SelectedObject = p;
                    ProfileViewer1.Profile = p;
                }
                catch (InvalidOperationException) { }
                catch (NullReferenceException) { }
                e.Handled = true;
            }
        }
        private void PathItemList_Selected(object sender, RoutedEventArgs e)
        {
            //SpindleViewer1.DrawToolPaths(_pathlist);
            try
            {
                wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                wpfPropertyGrid1.SelectedObject = _pathlist;
            }
            catch (InvalidOperationException) { }
        }
        private void PathItem_Selected(object sender, RoutedEventArgs e)
        {
            // hilight this path 
            if (e.OriginalSource is TreeViewItem)
            {
                TreeViewItem lb = (TreeViewItem)e.OriginalSource;
                if (lb.DataContext is Path)
                {
                    ProjectExplorer.Tag = lb.DataContext;
                    Path pc = (lb.DataContext as Path);
                    PathViewer1.HilightPathIndex = _pathlist.IndexOf(pc);
                    PathsCanvas3D.HilightPathID = pc.ID;
                }
            }
            e.Handled = true;
        }
        private void CodeManagerProgramItem_Selected(object sender, RoutedEventArgs e)
        {
            if (e.OriginalSource is TreeViewItem)
            {
                TreeViewItem lb = (TreeViewItem)e.OriginalSource;
                if (lb.DataContext is GcodeProgramItem)
                {
                    ProjectExplorer.Tag = lb.DataContext;
                    GcodeProgramItem gp = (lb.DataContext as GcodeProgramItem);
                    CodeViewer1.Gcode = gp;
                    wpfPropertyGrid1.SelectedObject = new GCodeProgramInformation(gp);
                }
            }
            e.Handled = true;
        }
        #endregion

        #region Click Event Handlers
        private void Show_Points_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is Path)
            {
                Path pc = (ProjectExplorer.Tag as Path);
                wpfPropertyGrid1.RequiredAttribute = null;
                wpfPropertyGrid1.SelectedObject = new PathDataWrapper(pc, _pathlist.IndexOf(pc)+1);
            }
        }
        private void Show_Chuck_Points_RAD_Click(object sender, RoutedEventArgs e)
        {
            wpfPropertyGrid1.RequiredAttribute = null;
            wpfPropertyGrid1.SelectedObject = HeadStock.Chuck.PathC;
        }
        private void Show_Chuck_Points_Click(object sender, RoutedEventArgs e)
        {
            wpfPropertyGrid1.RequiredAttribute = null;
            wpfPropertyGrid1.SelectedObject = HeadStock.Chuck.Path;
        }
        private void Create_Path_From_Rosette_Click(object sender, RoutedEventArgs e)
        {
            if ((ProjectExplorer.Tag != null) && (ProjectExplorer.Tag is Rosette))
            {
                Rosette r = ProjectExplorer.Tag as Rosette;
                _pathlist.Add(new Path(PathIDGenerator.Next(), r.Outline as Polygon));
            }    
        }

        private void Add_Rosette_to_main_Click(object sender, RoutedEventArgs e)
        {

             Headstock hs = ( Headstock)GetValue(HeadstockProp);
            //Debug.Print("Adding a Rosette count is {0}",hs.MainSpindle.Count);
            if (sender is MenuItem)
            {
                MenuItem m = sender as MenuItem;
                hs.MainSpindle.add(CreateRosette((ROSETTETYPE)m.CommandParameter));
            }
        }
        private void Add_Rosette_to_chuck_Click(object sender, RoutedEventArgs e)
        {

             Headstock hs = ( Headstock)GetValue(HeadstockProp);
            //Debug.Print("Adding a Rosette count is {0}",hs.MainSpindle.Count);
            if (sender is MenuItem)
            {
                MenuItem m = sender as MenuItem;
                Rosette r = CreateRosette((ROSETTETYPE)m.CommandParameter);
                r.Name = string.Format("stage{0}", hs.Chuck.NumStages);
                hs.Chuck.AddStage(true, 1, 1, r);
            }
        }
        private void Add_Rosette_to_pump_Click(object sender, RoutedEventArgs e)
        {
             Headstock hs = ( Headstock)GetValue(HeadstockProp);
            if (sender is MenuItem)
            {
                MenuItem m = sender as MenuItem;
                hs.PumpSpindle.add(CreateRosette((ROSETTETYPE)m.CommandParameter));
            }
        }
        private void EditChuckRosette_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Debug.Print((ProjectExplorer.Tag as Stage).ToString());
             Headstock h = ( Headstock)GetValue(HeadstockProp);
            if ((ProjectExplorer.Tag != null) && (ProjectExplorer.Tag is Stage))
            {
                try
                {
                    wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                    wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                    wpfPropertyGrid1.SelectedObject = (ProjectExplorer.Tag as Stage).Rosette;
                }
                catch (InvalidOperationException) { }
                //SpindleViewer1.DrawToolPath((ProjectExplorer.Tag as Stage).Rosette.Outline);
            }
        }
        private void DeleteChuckStage_Click(object sender, RoutedEventArgs e)
        {
             Headstock h = ( Headstock)GetValue(HeadstockProp);
            if (h == null || h.MainSpindle == null || h.MainSpindle.Count == 0)
                return;
            if (sender is MenuItem)
            {
                if (ProjectExplorer.Tag != null)
                {
                    h.Chuck.Stages.Remove((ProjectExplorer.Tag as Stage));
                    ProjectExplorer.Tag = null;
                }
            }
        }

        private void Remove_Chuck_Click(object sender, RoutedEventArgs e)
        {
            HeadStock.Chuck = null;
            ChuckItem.DataContext = null;
            ChuckPathViewer1.Chuck = null;
        }

        private void Import_Chuck_Click(object sender, RoutedEventArgs e)
        {
            string fn = ImportFilename("Chuck",
                                       BasicLib.Properties.Settings.Default.ChuckFolder,
                                       BasicLib.Properties.Settings.Default.ChuckExtension);
            if (fn == string.Empty)
                return;
            Chuck c = Serializer<Chuck>.ReadFile(fn);
            if (c != null)
            {
                HeadStock.Chuck = c;
                ChuckItem.DataContext = HeadStock.Chuck;
                ChuckPathViewer1.Chuck = c;
            }
          
        }
        private void Export_Chuck_Click(object sender, RoutedEventArgs e)
        {
            string fn = ExportFilename("Chuck",
                                        _pinfo.ProjectName,
                                        BasicLib.Properties.Settings.Default.ChuckFolder,
                                        BasicLib.Properties.Settings.Default.ChuckExtension);
            if (fn != string.Empty)
                Serializer<Chuck>.WriteFile(fn, HeadStock.Chuck);

        }

        private void Lay_On_Surface_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is Path)
            {
                Path pc = (ProjectExplorer.Tag as Path);
                int indx = _pathlist.IndexOf(pc);

                _pathlist.LayOnSurface(indx, _surfman);
                OffsetViewer1.Path = _pathlist[indx].Points;
            }
        }
        private void Rotate_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is Path)
            {
                Path pc = (ProjectExplorer.Tag as Path);
                int indx = _pathlist.IndexOf(pc);

                _pathlist.RotatePath(indx);
                OffsetViewer1.Path = _pathlist[indx].Points;
            }
        }
        private void Scale_to_Radius_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is Path)
            {
                Path pc = (ProjectExplorer.Tag as Path);
                int indx = _pathlist.IndexOf(pc);

                _pathlist.ScaleRadiusOfPath(indx);
                OffsetViewer1.Path = _pathlist[indx].Points;
            }
        }
        private void Clear_Paths_Click(object sender, RoutedEventArgs e)
        {
            _pathlist.Clear();
        }
        private void DeletePath_Click(object sender, RoutedEventArgs e)
        {
            // hilight this path 
            if (ProjectExplorer.Tag is Path)
            {
                Path pc = (ProjectExplorer.Tag as Path);
                int indx = _pathlist.IndexOf(pc);
                PathViewer1.HilightPathIndex = null;
                _pathlist.RemoveAt(indx);
                OffsetViewer1.ClearPath();
            }
        }

        private void Generate_Code_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is Path)
            {
                Path pc = (ProjectExplorer.Tag as Path);
                int indx = _pathlist.IndexOf(pc);
                string name = string.Format("{0}_path_{1}",_pinfo.ProjectName, indx + 1);
                _codegen.Project = _pinfo;
                GcodeProgram gcodesub = _codegen.RenderGCodeSub(name, pc);
                _codeman.Items.Add(new GcodeProgramItem(name, 
                                                  gcodesub, 
                                                  GcodeProgramType.SUBROUTINE,
                                                  "Subroutine describing path"));
            }
        }
        
        private void Import_Surface_Click(object sender, RoutedEventArgs e)
        {
            Import_Surface();
        }
        private void Export_Surface_Click(object sender, RoutedEventArgs e)
        {
            Export_Surface();
        }

        private void DeleteCode_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is GcodeProgramItem)
            {
                GcodeProgramItem itm = ProjectExplorer.Tag as GcodeProgramItem;
                _codeman.Remove(itm);
                CodeViewer1.Gcode = null;
            }
        }

        private void Save_Code_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is GcodeProgramItem)
            {
                GcodeProgramItem itm = ProjectExplorer.Tag as GcodeProgramItem;
                SaveGcodeText(itm.Name, itm.Program);
            }
        }

        private void Export_Code_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is GcodeProgramItem)
            {
                GcodeProgramItem itm = ProjectExplorer.Tag as GcodeProgramItem;
                ExportGcode(itm);
            }
        }

        private void Import_Code_Click(object sender, RoutedEventArgs e)
        {
            string fn = ImportFilename("Gcode",
                                       BasicLib.Properties.Settings.Default.GcodeFolder,
                                       BasicLib.Properties.Settings.Default.RawGcodeFileExtension);
            if (fn == string.Empty)
                return;
            GcodeProgramItem itm = Serializer<GcodeProgramItem>.ReadFile(fn);
            if (itm != null)
                _codeman.Items.Add(itm);
        }

       

        private void ExportGcode(GcodeProgramItem itm)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.InitialDirectory = BasicLib.Properties.Settings.Default.GcodeFolder;
            dlg.FileName = itm.Name; // Default file name
            dlg.AddExtension = true;
            dlg.DefaultExt = BasicLib.Properties.Settings.Default.RawGcodeFileExtension;
            dlg.Filter = string.Format("Gcode (.{0})|*.{0} | All Files (*.*)|*.*",
                        BasicLib.Properties.Settings.Default.RawGcodeFileExtension);
            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process open file dialog box results
            if (result == true)
            {
                // Open document
                string filename = dlg.FileName;
                Serializer<GcodeProgramItem>.WriteFile(filename, itm);
            }
        }

        private void SaveGcodeText(string name,GcodeProgram gcode)
        {
             Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.InitialDirectory = BasicLib.Properties.Settings.Default.ProjectsFolder;
            dlg.FileName = string.Format("{0}.{1}",
                name, BasicLib.Properties.Settings.Default.ExecutableGcodeFileExtension);// Default file name
            dlg.DefaultExt = BasicLib.Properties.Settings.Default.ExecutableGcodeFileExtension;
            dlg.Filter = string.Format("Gcode(*.{0})|*.{0}|All Files(*.*)|*.*",
                    BasicLib.Properties.Settings.Default.ExecutableGcodeFileExtension);
            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();
            // Process open file dialog box results
            if (result == true)
            {
                using (StreamWriter sw = new StreamWriter(dlg.FileName))
                {
                    sw.WriteLine(gcode.RenderText());
                }
            }
        }
        #endregion

        private Rosette CreateRosette(ROSETTETYPE rtpe)
        {
            Rosette r = new Rosette();
            switch (rtpe)
            {
                case ROSETTETYPE.ELLIPTICAL:
                    // already created
                    break;
                case ROSETTETYPE.POLYGON:
                    r = new PolygonalRosette();
                    break;
                case ROSETTETYPE.WAVE:
                    r = new WaveRosette();
                    break;
                case ROSETTETYPE.EPICYCLOID:
                    r = new EpicycloidRosette();
                    break;
                case ROSETTETYPE.HYPOCYCLOID:
                    r = new HypocycloidRosette();
                    break;
                case ROSETTETYPE.SPIRAL:
                    r = new SpiralRosette();
                    break;
                case ROSETTETYPE.GEAR:
                    r = new GearRosette();
                    break;
                case ROSETTETYPE.PROFILE:
                    r = new ProfileRosette();
                    break;
            }
            return r;
        }
        private void delete_last_Rosette(object sender, RoutedEventArgs e)
        {

            Headstock hs = (Headstock)GetValue(HeadstockProp);
            if (sender is MenuItem)
            {
                MenuItem m = sender as MenuItem;
                switch ((SPINDLETYPE)m.CommandParameter)
                {
                    case SPINDLETYPE.ROSE:
                        if (hs.MainSpindle.Rosettes.Count > 0)
                        {
                            if ((ProjectExplorer.Tag != null) && (ProjectExplorer.Tag is Rosette))
                                hs.MainSpindle.Rosettes.Remove((ProjectExplorer.Tag as Rosette));
                            else
                                hs.MainSpindle.Rosettes.RemoveAt(hs.MainSpindle.Rosettes.Count - 1);

                        }
                        // must do something about display
                        //SpindleViewer1.DrawSpindle(hs.MainSpindle);
                        break;
                    case SPINDLETYPE.PUMP:
                        if (hs.PumpSpindle.Rosettes.Count > 0)
                        {
                            if ((ProjectExplorer.Tag != null) && (ProjectExplorer.Tag is Rosette))
                                hs.PumpSpindle.Rosettes.Remove((ProjectExplorer.Tag as Rosette));
                            else
                                hs.PumpSpindle.Rosettes.RemoveAt(hs.PumpSpindle.Rosettes.Count - 1);

                        }
                        //SpindleViewer1.DrawSpindle(hs.PumpSpindle);
                        break;
                }
            }
        }
        private StepperData CalcStepperData()
        {
            StepperData sdata = new StepperData();
            sdata.CalcLinearStepsPerUnit(_pinfo.AXIS1,
                Properties.Settings.Default.Pump_Spindle_Stepper_Steps,
                Properties.Settings.Default.Pump_Spindle_Stepper_Multiplier,
                Properties.Settings.Default.Pump_Spindle_Gear_Ratio_Numerator,
                Properties.Settings.Default.Pump_Spindle_Gear_Ratio_Denominator,
                Properties.Settings.Default.Pump_Spindle_Pitch);
            sdata.CalcLinearStepsPerUnit(_pinfo.AXIS2,
                Properties.Settings.Default.Offset_Spindle_Stepper_Steps,
                Properties.Settings.Default.Offset_Spindle_Stepper_Multiplier,
                Properties.Settings.Default.Offset_Spindle_Gear_Ratio_Numerator,
                Properties.Settings.Default.Offset_Spindle_Gear_Ratio_Denominator,
                Properties.Settings.Default.Offset_Spindle_Pitch);
            sdata.CalcLinearStepsPerUnit(_pinfo.AXIS3,
                Properties.Settings.Default.Cutter_Depth_Spindle_Stepper_Steps,
                Properties.Settings.Default.Cutter_Depth_Spindle_Stepper_Multiplier,
                Properties.Settings.Default.Cutter_Depth_Spindle_Gear_Ratio_Numerator,
                Properties.Settings.Default.Cutter_Depth_Spindle_Gear_Ratio_Denominator,
                Properties.Settings.Default.Cutter_Depth_Spindle_Pitch);

            sdata.CalcAngularStepsPerUnit(_pinfo.AXIS0,
                Properties.Settings.Default.Main_Spindle_Stepper_Steps,
                Properties.Settings.Default.Main_Spindle_Stepper_Multiplier,
                Properties.Settings.Default.Main_Spindle_Gear_Ratio_Numerator,
                Properties.Settings.Default.Main_Spindle_Gear_Ratio_Denominator,
                Properties.Settings.Default.Main_Spindle_Angle_Per_Turn);

            return sdata;
        }
        private void PointDataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            DataGrid grid = sender as DataGrid;
            TextBox tb = e.EditingElement as TextBox;
            double newval = double.Parse(tb.Text);
            int row = e.Row.GetIndex();
            int col = grid.Columns.IndexOf(e.Column);
            double key = (ProjectExplorer.Tag as Profile).Key;
            //System.Diagnostics.Debug.Print("sender " + sender.ToString());
            //System.Diagnostics.Debug.Print("Action " + e.EditAction.ToString());
            //System.Diagnostics.Debug.Print("New Value {0} ",newval);
            //System.Diagnostics.Debug.Print("Row {0}", row);
            //System.Diagnostics.Debug.Print("Column index is {0}",col);
            //System.Diagnostics.Debug.Print("Key is {0} ", key);
            _surfman.Update(key, row, col, newval);
        }

        private void PathDataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {

        }

        private void CylindricalDataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {

        }
      
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // save project info here

            if (_pinfo != null)
            {
                Console.WriteLine("Saving project {0} path {1}", _pinfo.ProjectName,_pinfo.ProjectPath);
                string path = ProjectFolder;
                path = System.IO.Path.Combine(path, _pinfo.ProjectName);
                path = System.IO.Path.ChangeExtension(path, BasicLib.Properties.Settings.Default.SurfaceFileExt);
                if (_pinfo.UsesSurface)
                    _surfman.Save(path);
                saveProjectInfo();
                saveHeadstock();
            }

            BasicLib.Properties.Settings.Default.Save();
            Properties.Settings.Default.Save();
            SaveLayout();
        }

        #region Tool Table Code
        private void Tools_Selected(object sender, RoutedEventArgs e)
        {
            if (e.OriginalSource is TreeViewItem)
            {
                TreeViewItem lb = (TreeViewItem)e.OriginalSource;
                if (lb.DataContext is  ToolInfo)
                {
                    ProjectExplorer.Tag = lb.DataContext;
                    try
                    {
                        wpfPropertyGrid1.RequiredAttribute = typeof(System.ComponentModel.BrowsableAttribute);
                        wpfPropertyGrid1.ShowCategoriesAs = PropertyTools.Wpf.ShowCategoriesAs.GroupBox;
                        wpfPropertyGrid1.SelectedObject = (lb.DataContext as  ToolInfo);
                    }
                    catch (InvalidOperationException) { }
                }
                e.Handled = true;
            }
        }

        private void Add_Tool_Click(object sender, RoutedEventArgs e)
        {
            _pinfo.ToolTable.Add(new  ToolInfo("new_tool", 0, 0));
        }

        private void Delete_tool_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag != null)
            {
                _pinfo.ToolTable.Remove((ProjectExplorer.Tag as  ToolInfo).Name);
                ProjectExplorer.Tag = null;
            }
        }

        private void ClearToolTable_Click(object sender, RoutedEventArgs e)
        {
            _pinfo.ToolTable.Clear();
        }
        #endregion

        #region Surface and Profile code

        private void Import_Surface()
        {
            string fn = ImportFilename("Surface",
                                       BasicLib.Properties.Settings.Default.SurfaceFolder,
                                       BasicLib.Properties.Settings.Default.SurfaceFileExt);
            if (fn != string.Empty)
            {
                Surface surf = Serializer<Surface>.ReadFile(fn);
                _surfman.Surface = surf;
                _pinfo.UsesSurface = true;
                // now must populate Project Explorer
                SurfaceItem.DataContext = _surfman.Surface;
            }

        }

        private void Export_Surface()
        {
            string fn = ExportFilename("Surface",
                                        _pinfo.ProjectName,
                                       BasicLib.Properties.Settings.Default.SurfaceFolder,
                                       BasicLib.Properties.Settings.Default.SurfaceFileExt);
            if (fn != string.Empty)
                _surfman.Save(fn);
        }

        private void Add_Profile_Click(object sender, RoutedEventArgs e)
        {
            _surfman.AddNewProfile(this);
        }

        private void Edit_Profile_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is Profile)
            {
                Profile p = ProjectExplorer.Tag as Profile;
                _surfman.EditProfile(p.Key);
            }
        }

        private void Delete_Profile_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is Profile)
            {
                Profile p = ProjectExplorer.Tag as Profile;
                _surfman.DeleteProfile(p.Key);
            }
        }

        private void Clear_Profiles_Click(object sender, RoutedEventArgs e)
        {
            _surfman.Clear();
            //SpindleViewer1.Clear();
        }

        private void Add_Concave_Click(object sender, RoutedEventArgs e)
        {
            NewProfileChooser cp = new NewProfileChooser();
            cp.DefaultKey = 0;
            cp.DefaultHeight = 25;
            cp.DefaultRadius = 100;
            cp.DefaultIsNegative = true;
            cp.DefaultNumPoints = 10;
            bool? result = cp.ShowDialog();
            if (result.HasValue && result.Value)
            {
                Profile p = Profile.CreateConcave(cp.NumPoints, cp.MaxRadius, cp.ChordHeight, cp.IsNegative);
                p.Key = cp.Key;
                _surfman.AddProfile(p);
            }
        }

        private void Add_Convex_Click(object sender, RoutedEventArgs e)
        {
            NewProfileChooser cp = new NewProfileChooser();
            cp.DefaultKey = 0;
            cp.DefaultHeight = 25;
            cp.DefaultRadius = 100;
            cp.DefaultIsNegative = true;
            cp.DefaultNumPoints = 10;
            bool? result = cp.ShowDialog();
            if (result.HasValue && result.Value)
            {
                Profile p = Profile.CreateConvex(cp.NumPoints, cp.MaxRadius, cp.ChordHeight, cp.IsNegative);
                p.Key = cp.Key;
                _surfman.AddProfile(p);
            }
        }

        private void Add_Point_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectExplorer.Tag is Profile)
            {
                Profile p = ProjectExplorer.Tag as Profile;
                _surfman.AddPoint(p.Key);
            }
        }
        #endregion
       
        #region Layout Manager Code
        // **************** Layout manager code *******************
        const string LayoutFileName = "OTWBLayout.xml";

        private void SaveLayout()
        {
            // save default layout in OTWB folder on users disk
            string path = System.IO.Path.Combine(BasicLib.Properties.Settings.Default.RootFolder, LayoutFileName);
            dockManager.SaveLayout(path);
        }

        private void RestoreLayout()
        {
            string path = System.IO.Path.Combine(BasicLib.Properties.Settings.Default.RootFolder, LayoutFileName);
            if (File.Exists(path))
                dockManager.RestoreLayout(path);
            else
                Restore_Default_Layout();
            Set_View_Status();
        }

        private void Restore_Default_Layout()
        {
            if (File.Exists(LayoutFileName))
                dockManager.RestoreLayout(LayoutFileName);
            else
            {
                if ( MessageBox.Show("Saving current Layout as default") == MessageBoxResult.OK)
                    dockManager.SaveLayout(LayoutFileName);
            }
        }

        private void dockManager_Loaded(object sender, RoutedEventArgs e)
        {
            RestoreLayout();
            
        }

        private void Restore_Default_Layout_Click(object sender, RoutedEventArgs e)
        {

            dockManager.RestoreLayout(LayoutFileName);
            Set_View_Status();
        }

        private void Save_as_Default_Layout_Click(object sender, RoutedEventArgs e)
        {
            dockManager.SaveLayout(LayoutFileName);
        }

        #endregion

        #region View Windows Code
                
        private void Set_View_Status()
        {
            try
            {
                ProjectExplorerMenuItem.IsChecked = !IsHidden(ProjectContent);
                SpindleOutlineMenuItem.IsChecked = !IsHidden(SpindleOutline);
                OffsetsMenuItem.IsChecked = !IsHidden(Offsets);
                PropertyExplorerMenuItem.IsChecked = !IsHidden(PropertyExplorer);
                SurfaceMenuItem.IsChecked = !IsHidden(Surface);
                GcodeMenuItem.IsChecked = !IsHidden(Gcode);
                PathsMenuItem.IsChecked = !IsHidden(Paths);
                ChuckPathMenuItem.IsChecked = !IsHidden(ChuckPath);
                Paths3DMenuItem.IsChecked = !IsHidden(Paths3D);
            }
            catch
            {

            }
        }
       
      

        private void PaneMenuItem_Unchecked(object sender, RoutedEventArgs e)
        {
            try
            {
                MenuItem itm = sender as MenuItem;
                if (itm == OffsetsMenuItem)
                    Hide(Offsets);
                else if (itm == SpindleOutlineMenuItem)
                    Hide(SpindleOutline);
                else if (itm == ProjectExplorerMenuItem)
                    Hide(ProjectContent);
                else if (itm == PropertyExplorerMenuItem)
                    Hide(PropertyExplorer);
                else if (itm == SurfaceMenuItem)
                    Hide(Surface);
                else if (itm == GcodeMenuItem)
                    Hide(Gcode);
                else if (itm == PathsMenuItem)
                    Hide(Paths);
                else if (itm == ChuckPathMenuItem)
                    Hide(ChuckPath);
                else if (itm == Paths3DMenuItem)
                    Hide(Paths3D);
            }
            catch { }
        }

        private void PaneMenuItem_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                MenuItem itm = sender as MenuItem;
                if (itm == OffsetsMenuItem)
                    Show(Offsets);
                else if (itm == SpindleOutlineMenuItem)
                    Show(SpindleOutline);
                else if (itm == ProjectExplorerMenuItem)
                    Show(ProjectContent);
                else if (itm == PropertyExplorerMenuItem)
                    Show(PropertyExplorer);
                else if (itm == SurfaceMenuItem)
                    Show(Surface);
                else if (itm == GcodeMenuItem)
                    Show(Gcode);
                else if (itm == PathsMenuItem)
                    Show(Paths);
                else if (itm == ChuckPathMenuItem)
                    Show(ChuckPath);
                else if (itm == Paths3DMenuItem)
                    Show(Paths3D);
            }
            catch
            { }
        }

        private void Pane_StateChanged(object sender, RoutedEventArgs e)
        {
            try
            {
                AvalonDock.DockableContent pane = sender as AvalonDock.DockableContent;
                bool hidden = !IsHidden(pane);
                if (pane == Offsets)
                    OffsetsMenuItem.IsChecked = hidden;
                else if (pane == SpindleOutline)
                    SpindleOutlineMenuItem.IsChecked = hidden;
                else if (pane == ProjectContent)
                    ProjectExplorerMenuItem.IsChecked = hidden;
                else if (pane == PropertyExplorer)
                    PropertyExplorerMenuItem.IsChecked = hidden;
                else if (pane == Surface)
                    SurfaceMenuItem.IsChecked = hidden;
                else if (pane == Gcode)
                    GcodeMenuItem.IsChecked = hidden;
                else if (pane == Paths)
                    PathsMenuItem.IsChecked = hidden;
                else if (pane == ChuckPath)
                    ChuckPathMenuItem.IsChecked = hidden;
                else if (pane == Paths3D)
                    Paths3DMenuItem.IsChecked = hidden;
            }
            catch
            {

            }
        }

        private bool IsHidden(AvalonDock.DockableContent pane)
        {
            try
            {
                return pane.State == AvalonDock.DockableContentState.Hidden;
            }
            catch { return false; }
        }

        private void Hide(AvalonDock.DockableContent pane)
        {
            try
            {
                pane.Hide();
            }
            catch { }
        }

        private void Show(AvalonDock.DockableContent pane)
        {
            try
            {
                pane.Show();
            }
            catch { }
        }
        #endregion

        void GenEMCMemoryMapCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            
            string fn = string.Format(_pinfo.MemoryMapName);
            fn = System.IO.Path.Combine(_pinfo.ProjectPath, fn);
            fn = System.IO.Path.ChangeExtension(fn, BasicLib.Properties.Settings.Default.RawGcodeFileExtension);
            GcodeProgramItem gcode = EMCMemoryMap;
            _codeman.Items.Add(gcode);
        }

        
         public GcodeProgramItem EMCMemoryMap
        {
            get
            {
                GcodeProgramItem code = new GcodeProgramItem();
                code.ProgramType = GcodeProgramType.SUBROUTINE;
                code.Name = _pinfo.MemoryMapName; 
                GcodeProgram program = new GcodeProgram();
                _codegen.Project = _pinfo;
                program.Add(EMC_Memory_Map);
                code.Program = program;
                return code;
            }
        }

        public CodeList EMC_Memory_Map
        {
            get
            {
                if (HeadStock.IncludeMainSpindle)
                    GenerateMainSpindleOffsets();
                if (HeadStock.IncludePumpSpindle)
                    GeneratePumpSpindleOffsets();
                return _codegen.RenderEMCMemoryMap(HeadStock, _offsets,_ofgen.Range);
            }
        }

        private void TemplatesItem_Selected(object sender, RoutedEventArgs e)
        {
            if (e.OriginalSource is TreeViewItem)
            {
                TreeViewItem lb = (TreeViewItem)e.OriginalSource;
                if (lb.DataContext is GcodeProgramItem)
                {
                    ProjectExplorer.Tag = (GcodeProgramItem)lb.DataContext;
                    CodeViewer1.Gcode = (GcodeProgramItem)lb.DataContext;
                    wpfPropertyGrid1.SelectedObject = new GCodeProgramInformation((GcodeProgramItem)lb.DataContext);
                }
            }
        }

        private void Instantiate_Template_Click(object sender, RoutedEventArgs e)
        {
            if (e.OriginalSource is MenuItem)
            {
               
                if ((e.OriginalSource as MenuItem).DataContext == _codeman)
                {
                    if (ProjectExplorer.Tag is GcodeProgramItem)
                    {
                        _codeman.AddProgram(_codeman.Instantiate(ProjectExplorer.Tag as GcodeProgramItem));
                    }
                }
            }
        }

        private void New_Template_Click(object sender, RoutedEventArgs e)
        {
            string name = ExportFilename("template",
                            "new_template",
                            BasicLib.Properties.Settings.Default.TemplateFolder,
                            BasicLib.Properties.Settings.Default.TemplateExt);

            string contents = string.Format("( Template File )\n( Created {0})",
                                                System.DateTime.Now.ToShortDateString());
            
            using (StreamWriter sw = new StreamWriter(name))
            {
                sw.WriteLine(contents);
            }
            _codeman.AddTemplate(System.IO.Path.GetFileNameWithoutExtension(name));

        }

        private void Edit_Template_Click(object sender, RoutedEventArgs e)
        {

        }

        private void New_Chuck_Click(object sender, RoutedEventArgs e)
        {
            int ns = int.Parse((sender as MenuItem).CommandParameter.ToString());
            Chuck c = new Chuck(ns);
            HeadStock.Chuck = c;
            ChuckItem.DataContext = c;
            ChuckPathViewer1.Chuck = c;
        }
    }
}
