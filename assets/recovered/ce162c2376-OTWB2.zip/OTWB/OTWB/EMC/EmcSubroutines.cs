﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OTWB.EMC
{
    // returns important subroutines 
    class Subroutines
    {
        /// <summary>
        /// Generate an ellipse from memory block
        /// </summary>
        public static List<string> EllipticalRosette
        {
            get
            {
                List<string> sub = new List<string>();
                string line = string.Empty;
                sub.Add("o<Elliptical_Rosette> sub");
                sub.Add("\t (#1 param is addr of start of block with rosette data)");
                sub.Add("\t (#2 param is angle)");
                sub.Add("o<Elliptical_Rosette> endsub");
                return sub;
            }
        }
    }
}
