﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OTWB.EMC
{
    /// <summary>
    /// This class encapsulates the map of EMC variable memory
    /// used by OTWorkbench
    /// </summary>
    class Variables
    {
        
        public static int Return       = 31;   // location used for sub returns
        // now global variables start at 40
        public static int AngleStart   = 100; // start of generation angle range
        public static int AngleInc     = 101;
        public static int AngleEnd     = 102;

        public static int UseMainSpindle = 103;  // flag set true to use main spindle
        public static int UsePumpSpindle = 104;  // flag set true to use pump spindle
        public static int UseChuck       = 105;  // flag set true to use chuck
        public static int UseSurface     = 106;  // flag set true if using surface 
        public static int ToolOffset    = 107;  // tool offset position
        public static int MainCount     = 108;  // number of rosettes on main spindle
        public static int PumpCount     = 109;  // number of rosettes on pump spindle
        public static int ChuckCount    = 110;  // number of stages on Chuck

        // now Mainspindle rosettes start at 100
        public static int MainSpindle   = 200; // location of first rosette on main spindle
        public static int PumpSpindle   = 400; // location of first rosette on pump spindle
        public static int Chuck         = 600; // location of first rosette on chuck
        public static int Surface       = 1000;// location of start of surface data

        // Rosette object Map
        public static int R_Offset      = 10;   // data in rosette is offset into tables
        
        public static int R_Type        = 0;    // type of rosette
        public static int R_Include     = 1;    // flag to include rosette
        public static int R_R           = 2;    // Major radius of rosette
        public static int R_r           = 3;    // Minor radius of rosette
        public static int R_Phase       = 4;    // phase of rosette
        public static int R_Blend       = 5;    // blend coefficient
        
        // next values are for differing subclasses
        // Polygon Rosette
        public static int R_Numsides    = 6;    // number of sides in polygon
        public static int R_IsStar      = 7;    // flag true if star shape

        // Wave Rosette
        public static int R_Frequency   = 6;    // frequency of wave
        public static int R_Amplitude   = 7;    // Amplitude of wave
        public static int R_Absolute    = 8;    // flag set true if absolute values used

        // Spiral Rosette
        public static int R_Pitch       = 6;    // pitch of spiral
        public static int R_Gradient    = 7;    // gradient of spiral
        public static int R_Exponent    = 8;    // Exponent of spiral
        public static int R_Logrithmic  = 9;    // flag set true if spiral is loagrithmic

        // now for chuck stage data
        public static int C_Offset      = 15;   // offset for chuck data
                                                // only 12 used at present 
        public static int C_Vin         = 0;    // speed of input shaft
        public static int C_VOut        = 1;    // speed of this stage
        public static int C_SameDirn    = 2;    // flag set true if in same direction
        public static int C_Rosette     = 3;    // Rosette forming stage

        // code to add  Rosette data to tables
        // pre - List string cannot be null
        public static void AddRosetteData(ref List<string> code,
                                        int table,
                                        int indx,
                                        Rosette r)
        {
            int addr = table + indx * R_Offset;
            r.EmcData(ref code, addr);
           
        }

        public static void AddRosetteToMainSpindle(ref List<string> code,
                                                    int indx,
                                                    Rosette r)
        {
            int baseaddr = MainSpindle + indx * R_Offset;
            r.EmcData(ref code, baseaddr);
        }

        public static void AddRosetteToPumpSpindle(ref List<string> code,
                                                   int indx,
                                                   Rosette r)
        {
            int baseaddr = PumpSpindle + indx * R_Offset;
            r.EmcData(ref code, baseaddr);
        }

        public static void AddChuckStage(ref List<string> code,
                                         int indx,
                                         Stage stage)
        {
            int baseaddr = Chuck + indx * C_Offset;
            stage.EmcData(ref code, baseaddr);
        }

        public static string Variable(int id)
        {
            return string.Format("#<{0}>", id);
        }

        public static string Assign(int variable, double value)
        {
            return string.Format("#<{0}> = {1}", variable, value);
        }



    }
}
