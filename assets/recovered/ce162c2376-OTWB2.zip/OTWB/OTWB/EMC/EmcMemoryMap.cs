﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OTWB.EMC
{
    /// <summary>
    /// This class holds address for emc variables when implementing
    /// offset tables for main spindle and pump spindle.
    /// 
    /// The main machine data is
    /// #31     -   subroutine return address
    /// #32     -   flag set to 1 if using main spindle
    /// #33     -   flag set to 1 if using pump spindle
    /// 
    /// Machining Section
    /// #40     -   rough cut depth increment
    /// #41     -   finish cut depth increment
    /// #42     -   feed rate
    /// #43     -   inverse time feed rate
    /// #44     -   units flag set 1 if in mm
    /// #45     -   safe height
    /// 
    /// Main spindle range is #1000 - #2999
    /// #1000   -   length of table
    /// #1001   -   angle increment
    /// #1002   -
    /// #1003   -
    /// #1004   -
    /// #1005   -   Table start
    /// 
    /// Pump spindle range is #3000 - #4999
    /// #3000   -   length of table
    /// #3001   -   angle increment
    /// #3002   -
    /// #3003   -
    /// #3004   -
    /// #3005   -   Table start
    /// </summary>
    public class EmcMemoryMap
    {
        public static string MemName = "MemInit";

        // first the standard machine variables
        public static int Return = 31;   // location used for sub returns
        public static int UseMainSpindle = 50;  // flag set true to use main spindle
        public static int UsePumpSpindle = 51;  // flag set true to use pump spindle

        // now area for machining data
        public static int RoughCutIncrement = 40;
        public static int FinishCutIncrement = 41;
        public static int FeedRate = 43;
        public static int InverseTimeFeedRate = 44;
        public static int MMUnitsFlag = 45;
        public static int SafeHeight = 46;

        // Now offset tables themselves
        public static int TableStartOffset = 5;
        public static int TableLengthOffset = 0;
        public static int AngleIncOffset = 1;

        public static int MainSpindleStartAddr = 1000;
        public static int PumpSpindleStartAddr = 3000;
       
        public static string Variable(int id)
        {
            return string.Format("#<{0}>", id);
        }

        public static string Assign(int variable, double value)
        {
            return Assign(variable, value, string.Empty);
        }

        public static string Assign(int variable, double value, string comment)
        {
            if (comment == null || comment == string.Empty)
                return string.Format("#<{0}> = {1}", variable, value);
            else
                return string.Format("#<{0}> = {1}  ({2})", variable, value, comment);
        }

        public static string MapStart
        {
            get
            {
                return string.Format("o<{0}> sub",MemName);
            }
        }

        public static string MapEnd
        {
            get
            {
                return string.Format("o<{0}> endsub",MemName);
            }
        }

        public static string Comment(string c)
        {
            return string.Format("( {0} )", c);
        }
    }
}
