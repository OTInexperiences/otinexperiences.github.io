
using System;
using System.Windows;
using System.Windows.Media.Media3D;
using System.Collections.Generic;
using System.Xml.Serialization;
using BasicLib;

namespace OTWB
{
	
	/// <summary>
	/// A Profile is an association between 
	/// </summary>
	public class Profile3D : Dictionary<double,Profile>
	{
		
		public Profile3D() : base()
		{
		}
		
		
		public double Depth(Point3D p)
		{
            Cylindrical c = new Cylindrical(p);
			
			if (this.ContainsKey(c.Angle))
			{
				return this[c.Angle].ValueAt(c);
			}
			return float.NegativeInfinity;
		}

        public double Depth(Cylindrical p)
        {
            if (this.ContainsKey(p.Angle))
            {
                return this[p.Angle].Value(p.Radius);
            }
            return float.NegativeInfinity;
        }
	}
}
