
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Utils
{
	
	/// <summary>
	/// Gives a value in terms of the linear distance from some
	/// origin
	/// </summary>
	[XmlInclude(typeof(Profile))]
	public class RadialFunction
	{
		protected Vector3 _origin;
		protected List<Vector2> _profile;   // radius , height
		protected Vector3 _normal;
		
		[XmlElement("Origin")]
		public Vector3 Origin
		{
			get { return _origin; }
			set { _origin = value; }
		}
		
		[XmlElement("Normal")]
		public Vector3 Normal
		{
			get { return _normal; }
			set { _normal = value; }
		}
		
		public RadialFunction()
		{
			_origin = new Vector3(0,0,0);
			_normal = new Vector3(0,0,1); // along z
		}
		
		public virtual float ValueAt(ICoordinate p)
		{
			return 0;
		}
		
		[XmlArray("Profile")]
		public List<Vector2> Profile
		{
			get { return _profile; }
			set { _profile = value; }
		}
	}
}
