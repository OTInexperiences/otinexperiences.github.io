﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BasicLib;
//using System.Windows.Forms;
using System.IO;
using System.Collections.ObjectModel;

namespace OTWB
{
    /// <summary>
    /// Public Structure recordtype2
    /// Public V1num As Single   [0]
    /// Public V1den As Single   [1]
    /// Public InOut1 As Single  [2]
    /// Public Ex1 As Single     [3]
    /// Public PHI1 As Single    [4]
    /// Public SR As Single      [5]
    /// 
    /// Public V2num As Single   [6]
    /// Public V2den As Single   [7]
    /// Public InOut2 As Single  [8]
    /// Public Ex2 As Single     [9]
    /// Public PHI2 As Single    [10]
    /// </summary>
    class ChuckExampleImporter
    {
        public Chuck Import(int num)
        {
            String path = System.Reflection.Assembly.GetExecutingAssembly().Location;
            path = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(path), "GEODATA");
            path = System.IO.Path.ChangeExtension(path, "txt");
            if (System.IO.File.Exists(path))
                return BuildChuck(readChuckInfo(path, num));
            else
                return new Chuck();
        }

        private string readChuckInfo(string path, int num)
        {
            string[] parts = null;
            try
            {
                bool found = false;
                using (StreamReader sr = new StreamReader(path))
                {
                    String line;
                    while (((line = sr.ReadLine()) != null) && (!found))
                    {
                        parts = line.Split(new char[] { ':' });
                        found = (NumberOf(parts[0]) == num);
                    }
                }
                
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);

            }
            return parts[1];
        }

        private Chuck BuildChuck(string parts)
        {
            ObservableCollection<Stage> _stages = new ObservableCollection<Stage>();
            System.Diagnostics.Debug.Print("Data is {0}", parts);
            string[] data = parts.Split(new char[]{','});
            // now build chuck from parts first stage 1
            // must have at least 1 stage
            System.Diagnostics.Debug.Print("Data size is {0}", data.GetLength(0));
            double V_IN = double.Parse(data[0]);
            System.Diagnostics.Debug.Print("Stage1 num {0}", V_IN);
            double V_OUT = double.Parse(data[1]);
            System.Diagnostics.Debug.Print("Stage1 den {0}", V_OUT);
            bool SameDirection = int.Parse(data[2]) > 0;
            System.Diagnostics.Debug.Print("Same Direction {0}", SameDirection);

            double ex = double.Parse(data[3]);
            System.Diagnostics.Debug.Print("Ex1 {0}", ex);
            double phi = double.Parse(data[4]);
            System.Diagnostics.Debug.Print("Phi1 {0}", phi);

            double sr = Single.Parse(data[5]);
            System.Diagnostics.Debug.Print("SR {0}", sr);

            Rosette ros = new Rosette(ex,0);
            _stages.Add(new Stage(SameDirection, 1, 1, ros));

            ros = new Rosette(sr,phi);

            System.Diagnostics.Debug.Print("Created Rosette");
            _stages.Add(new Stage(SameDirection, V_IN, V_OUT, ros));
            System.Diagnostics.Debug.Print("Added stage1 to stages collection");

            V_IN = double.Parse(data[6]);
            System.Diagnostics.Debug.Print("Stage2 num {0}", V_IN);
            if (V_IN > 0)
            {             
                V_OUT = double.Parse(data[7]);
                System.Diagnostics.Debug.Print("Stage2 den {0}", V_OUT);
                SameDirection = int.Parse(data[8]) > 0;
                System.Diagnostics.Debug.Print("Same Direction {0}", SameDirection);
                ex = double.Parse(data[9]);
                System.Diagnostics.Debug.Print("Ex2 {0}", ex);
                phi = double.Parse(data[10]);
                System.Diagnostics.Debug.Print("Phi {0}", phi);
                ros = new Rosette(ex,phi);
                System.Diagnostics.Debug.Print("Created Rosette");
                _stages.Add(new Stage(SameDirection, V_IN, V_OUT, ros));
                System.Diagnostics.Debug.Print("Added stage2 to stages collection");

            }
            System.Diagnostics.Debug.Print("Build Complete");

            Chuck c = new Chuck();
            c.Stages = _stages;
            return c;
        }

        private int NumberOf(string p)
        {
            String s =  p.TrimStart(new char[] { '[','0' });
            s = s.TrimEnd(new char[] { ']' });
            return int.Parse(s);
        }
    }
}
