
using System;
using System.Windows.Media.Media3D;
using BasicLib;

namespace OTWB
{

	public interface ISurface
	{
		double Depth (Point3D c);
	}
}
