using System;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;

using BasicLib;
using PropertyTools.Wpf;
using System.Windows.Controls.Primitives;

namespace OTWB
{
	
	/// <summary>
	/// This class represents the headstock of a rose engine. 
	/// The coordinate system is defined so that
	/// 	The x coordinate is the radial movement from the centre of spindle
	/// 	(which is at x=0) outwards in either + or - direction.
	/// 
    ///     The spindle is aligned along the positive Y axis 
    ///     so the work rotates around the Y axis. 
    ///     
    ///     This means that the geometric chuck will return coordinates 
    ///     in the XZ plane.
    ///     
	/// 	The z coordinate is the depth movement of the cutter along its
	/// 	axis in the -Z direction so zero is the current surface.
	/// 
    ///     Remember when the G code is generated these axes will be mapped into
	///     the CNC designated axes for a particular system setup.
    ///     
	/// The headstock comprises of
	/// 1)	A spindle holding one or more rosettes. 
    /// 	
    /// 2)  A pumping spindle holding several rosettes as above
	///  
	/// 3)	A chuck that determines the centre of the work with respect
	///     to the centre of the spindle. In a standard chuck the spindle centre
	///     and the workpiece centre are coincident.
	/// 
	///  
	/// </summary>

		
	[XmlRootAttribute("Headstock", Namespace="", IsNullable=false)]
	public class Headstock : DependencyObject, INotifyPropertyChanged
	{
		#region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }
        #endregion

        protected Polyline _outline;     // outline of this rosette
        protected ProjectInfo _pinfo;   // project info

        public Headstock()			    // set some default values
		{
			MainSpindle = new Spindle();
            MainSpindle.ID = "Main Spindle";
			PumpSpindle = new Spindle();
            PumpSpindle.ID = "Pumping Spindle";
		    Chuck = new Chuck();
            AngleRange = new Range(0, 1, 360);
            Chuck.AngleRange = AngleRange;
            _outline = new Polyline();
            _outline.Fill = new SolidColorBrush(BasicLib.Properties.Settings.Default.FillColor);
            _outline.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.ToolPathColor);
            _outline.StrokeThickness = 1;
            _pinfo = null;
		}

        [Browsable(true)]
		public string Name {get; set; }
        
      

        [Browsable(true)]
        [Category("Generating Path")]
        [DisplayName("Include Rosette")]
        public bool IncludeMainSpindle { get; set; }

        [Browsable(true)]
        [Category("Generating Path")]
        [DisplayName("Incude Pumping")]
        public bool IncludePumpSpindle { get; set; }
        
        [Browsable(true)]
        [Category("Generating Path")]
        [DisplayName("Include Chuck")]
        public bool IncludeChuck { get; set; }

        [Browsable(true)]
        [Category("Generating Path")]
        [DisplayName("Tool Position")]
        public double ToolPosition { get; set; }

        public OTWB.Spindle MainSpindle { get; set; }
		public OTWB.Spindle PumpSpindle { get; set; }
    	public Chuck Chuck {get; set; }

        // Using a DependencyProperty as the backing store for Gradient.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AngleRangeProperty =
            DependencyProperty.Register("AngleRange", typeof(Range), typeof(Headstock),
             new PropertyMetadata(new Range(), new PropertyChangedCallback(OnAngleRangePropChanged)));

        private static void OnAngleRangePropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            Range newg = (Range)args.NewValue;

            if (obj is Headstock)
            {
                Headstock h = obj as Headstock;
                h.AngleRange = newg;
            }
        }
        public Range AngleRange {
            get { return (Range)GetValue(AngleRangeProperty); }
            set
            {
                SetValue(AngleRangeProperty, value);
                if (Chuck != null)
                    Chuck.AngleRange = value;
            }
        }

        [XmlIgnore]
        [Browsable(true)]
        [Category("Path Generation")]
        [DisplayName("Start Angle")]
        public double Startangle
        {
            get { return AngleRange.Start; }
            set { AngleRange.Start = value; }
        }

        [XmlIgnore]
        [Browsable(true)]
        [Category("Path Generation")]
        [DisplayName("Angle Increment")]
        public double Incangle
        {
            get { return AngleRange.Inc; }
            set { AngleRange.Inc = value; }
        }

        [XmlIgnore]
        [Browsable(true)]
        [Category("Path Generation")]
        [DisplayName("End Angle")]
        public double Endangle
        {
            get { return AngleRange.End; }
            set { 
                   AngleRange.End = value; 
            }
        }

        [XmlIgnore]
        [Browsable(true)]
        [Category("Path Generation")]
        [DisplayName("Rotations")]
        [Slidable(0, 20.0, 0.1, 0.5, true, 0.1, TickPlacement.BottomRight)]
        public double Rotations
        {
            get { return AngleRange.End / 360.0; }
            set { 
                AngleRange = new Range(AngleRange.Start,
                                       AngleRange.Inc,
                                        360.0 * value); 
            }
        }

		[XmlIgnore]
		public ProjectInfo Project 
        {
            get { return _pinfo; }

            set
            {
                _pinfo = value;
                if (Chuck.RotationAxis != value.AXIS0)
                    Chuck.RotationAxis = value.AXIS0;
            }
        }
		      
        [XmlIgnore]
        public Polyline ToolPath { get { return _outline; } }

      
        public Point3D PointAt(double angle)
        {
            Point3D p = new Point3D();
            
            if (IncludeMainSpindle) {
                double r = MainSpindle.RadiusAt(angle) + ToolPosition;
                Utilities.Point3DConverter(MainSpindle.Axis, ref p, r, angle);
                if (IncludeChuck)
                {
                    Vector3D v  = Chuck.VectorAt(angle);
                    p.X += v.X;
                    p.Y += v.Y;
                }
            }
           
            if (IncludePumpSpindle)
                p.Z += PumpSpindle.RadiusAt(angle);

            return p;
        }

        public double PumpOffset(double angle)
        {
            return PumpSpindle.RadiusAt(angle);

        }

        public void CreatePath()
        {
            _outline.Points.Clear();
            if (Project == null) return;
            for (double angle = AngleRange.Start; angle <= AngleRange.End; angle += AngleRange.Inc)
            {
                Point3D p = PointAt(angle);
                _outline.Points.Add(new Point(p.X,p.Y));
            }
        }

      

        public void GeneratePath(ref Path path)
        {
            path.ToolPosition = ToolPosition;
            for (double angle = AngleRange.Start; angle < AngleRange.End; angle += AngleRange.Inc)
            {
                path.Add(PointAt(angle));
            }
        }

        internal void FixUpSpindles()
        {
            MainSpindle.FixUp();
            PumpSpindle.FixUp();
        }

        
    }
	
}