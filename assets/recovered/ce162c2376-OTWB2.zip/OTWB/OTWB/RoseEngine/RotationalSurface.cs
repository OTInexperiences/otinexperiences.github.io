//  
//  Copyright (C) 2009 Alan Battersby
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
// 

using System;
using System.Xml.Serialization;

namespace Utils
{
	
	/// <summary>
	/// Class of surface with angular symmetry so depth
	/// only depends upon radial distance from centre of rotation
	/// which is usually taken to be line through 0,0,0 along z axis.
	/// may generalise later.
	/// Base class implements a linear function of radius
	/// </summary>
	public class RotationalSurface : Surface
	{
		Profile rf;
		
		[XmlElement( "Profile")]
		public Profile Profile
		{
			get { return rf; }
			set { rf = value; }
		}
		
		public RotationalSurface()
		{
			rf = new Profile();
		}
		
		public new float Depth(ICoordinate posn)
		{
			return rf.ValueAt(posn);
		}
					
		public void Add(float r, float h)
		{
			if (rf is Profile)
				(rf as Profile).Add(r,h);	
		}
		
		public void Remove(float r)
		{
			if (rf is Profile)
				(rf as Profile).Remove(r);	
		}
		
		public void Update(float r, float h)
		{
			if (rf is Profile)
				(rf as Profile).Update(r,h);
		}
	}
}
