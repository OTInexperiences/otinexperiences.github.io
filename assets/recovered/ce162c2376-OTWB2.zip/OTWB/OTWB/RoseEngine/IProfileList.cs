﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BasicLib;
using System.Collections.Specialized;

namespace OTWB
{
    interface IProfileList : IList<Profile>, INotifyCollectionChanged {}

}
