// Spindle
// Author: Alan Battersby
//

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Xml.Serialization;
using System.ComponentModel;
using System.Windows.Shapes;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using BasicLib;
using PropertyTools.Wpf;
using System.Windows.Controls.Primitives;

namespace OTWB
{
	/// <summary>
	/// The Rosette shaft holds a collection of rosettes. 
	/// Each attached at a given phase angle.
	/// The radii of the various rosettes are aggregated together
	/// and the value returned.
	/// </summary>
	[XmlRootAttribute("Spindle", Namespace="", IsNullable=false)]
	public class Spindle : DependencyObject
	{
        public event EventHandler SpindleOutlineChanged;

        ObservableCollection<Rosette> _rosettes; 	// rosettes on the spindle
        Polygon _outline;                           // outine of spindle

        public static readonly DependencyProperty AxisProperty =
             DependencyProperty.Register("Axis", typeof(AXIS), typeof(Spindle),
                 new PropertyMetadata(new AXIS(), new PropertyChangedCallback(OnAxisPropChanged)));

       public static readonly DependencyProperty BlendProperty =
            DependencyProperty.Register("Blend", typeof(bool), typeof(Spindle),
                new PropertyMetadata(new bool(), new PropertyChangedCallback(OnBlendPropChanged)));

       public static readonly DependencyProperty PhaseProperty =
          DependencyProperty.Register("Phase", typeof(double), typeof(Spindle),
              new PropertyMetadata(new double(), new PropertyChangedCallback(OnPhasePropChanged)));

        private static void OnBlendPropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
           bool newbw = (bool)args.NewValue;
           if (obj is Spindle)
           {
               ((Spindle)obj).Blend = newbw;
           }
        }

        private static void OnAxisPropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            AXIS newbw = (AXIS)args.NewValue;
            if (obj is Spindle)
            {
                ((Spindle)obj).Axis = newbw;
            }
        }
         
       
        // Using a DependencyProperty as the backing store for Include.  This enables animation, styling, binding, etc...

        private static void OnPhasePropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newphase = (double)args.NewValue;
            if (obj is Spindle)
            {
                ((Spindle)obj).Phase = newphase;
            }
        }

        Range _outline_angle_range;

        public Range AngleRange
        {
            get { return _outline_angle_range; }
            set { 
                _outline_angle_range = value;
                CreateOutline();
            }
        }

        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Information")]
        [DisplayName("Total Angle")]
        [Description("The angle needed to complete pattern for this spindle")]
        public double TotalAngle
        {
            get { return _outline_angle_range.End; }
        }

        [Category("Data")]
        [DisplayName("Spindle Axis")]
        [Browsable(true)]
        public AXIS Axis
        {
            get { return (AXIS)GetValue(AxisProperty); }
            set
            {
                SetValue(AxisProperty, value);
                CreateOutline();
            }
        }

        [Browsable(true)]
        [Category("Data")]
        public bool Blend
        {
            get { return (bool)GetValue(BlendProperty); }
            set { 
                SetValue(BlendProperty, value);
                CreateOutline();
            }
        }

        [Browsable(true)]
        [Category("Data")]
        [Slidable(0, 360.0, 0.5, 1, true, 0.5, TickPlacement.BottomRight)]
        public double Phase
        {
            get { return (double)GetValue(PhaseProperty); }
            set { 
                    SetValue(PhaseProperty, value);
                    CreateOutline();
            }
        }

		double _maxradius;
		double _minradius;
		string _id;
     
		[XmlIgnore]
        [Browsable(false)]
        public Shape Outline
        {
            get { return _outline; }
        }

        [Browsable(true)]
        [Category("Data")]
		public string ID
		{
			get { return _id; }
			set { _id = value; }
		}
						
		[XmlIgnore]
        [Browsable(true)]
        [Category("Information")]
        [ReadOnly(true)]
		public double MaxRadius
		{
			get { return Math.Round(_maxradius,BasicLib.Properties.Settings.Default.DP); }	
		}
		

		[XmlIgnore]
        [Browsable(true)]
        [Category("Information")]
        [ReadOnly(true)]
		public double MinRadius
		{
			get { return Math.Round(_minradius,BasicLib.Properties.Settings.Default.DP); }	
		}

        [XmlIgnore]
        [Browsable(true)]
        [Category("Information")]
        [DisplayName("Max Rosette radius")]
        [ReadOnly(true)]
        public double MaxRosetteRadius
        {
            get {
                if (_rosettes == null || _rosettes.Count == 0)
                    return 0;
                double maxr = _rosettes[0].MaxRadius;
                for (int indx = 1; indx < _rosettes.Count; indx++)
                    if (_rosettes[indx].MaxRadius > maxr)
                        maxr = _rosettes[indx].MaxRadius;
                return maxr;
            }
        }
       	public Spindle()
		{
			_rosettes = new ObservableCollection<Rosette> ();
			_maxradius = 0;
			_minradius = 0;
			Blend = false;
            Phase = 0;
            _outline = NewOutline;
		}

        public void FixUp()
        {
            foreach (Rosette r in _rosettes)
            {
                r.RosetteOutlineChanged += r_OutlineChanged;
            }
        }

        public void add(Rosette r)
        {
            _rosettes.Add(r);       
            
            r.RosetteOutlineChanged += new EventHandler(r_OutlineChanged);
        }

        void r_OutlineChanged(object sender, EventArgs e)
        {
            CreateOutline();
        }

		public void removeAt(int indx)
		{
            Rosette r = _rosettes[indx];
            r.RosetteOutlineChanged -= r_OutlineChanged;
			_rosettes.RemoveAt(indx);
            CreateOutline();
		}

		public void clear()
		{
			_rosettes.Clear();
			_maxradius = 0;
			_minradius = double.MaxValue;
		}

        [Browsable(true)]
        [DisplayName("Num Rosettes")]
        [ReadOnly(true)]
        [Category("Information")]
		public int Count
		{
			get {return _rosettes.Count;}
		}

		
		// return the maximum radius value
		// angle can be either interpreted as either a index position 
		// or an actual angle in degrees. This is dependant upon the value of
		// the _useIndexer flag.
		public double RadiusAt(double posn)
		{
			double rmax = 0.0f;
			double r = 0.0f;

            int nr = _rosettes.Count;
			foreach (Rosette ros in _rosettes)
			{
				if (ros.Include) {
					r = ros.RadiusAt(posn - Phase);
					if ((!Blend) &&(r > rmax))
						rmax = r;
					else if (Blend) {
						rmax += r / nr;	
					}
				}
			}
			return rmax;
		}
		
		public Vector3D VectorAt(double angle)
		{
            Vector3D vmax = new Vector3D();
			foreach (Rosette r in _rosettes) {
				if (r.Include) {
					Vector3D v = r.VectorAt(angle - Phase,Axis);
                    if (!Blend && v.Length > vmax.Length)
                    {
                        vmax = v;
                    }
                    else
                    {
                        vmax = vmax + v;
                    }
				}
			}
            return vmax;
		}
		
		
		[XmlArray("Rosettes")]
		[XmlArrayItem("Rosette", typeof(Rosette))]
        [Browsable(false)]
		public ObservableCollection<Rosette> Rosettes
		{
			get { return _rosettes; }	
			set { _rosettes = value; }
		}
		
		public Rosette LookupByName(string name)
		{
			foreach (Rosette r in _rosettes)
			{
				if (r.Name == name)
					return r;
			}
			return null;
		}	
		
		[XmlIgnore]
        [Browsable(true)]
        [Category("Information")]
        [ReadOnly(true)]
		public double MeanRadius
		{
			
			get { 
				return Utilities.Round((_maxradius + _minradius) / 2); 
			
			}	
		}
				
		public void EqualiseBlendCoeffs()
		{
			double nblend = (_rosettes.Count > 0) ? (1.0f / _rosettes.Count) : 1.0f;
			foreach (Rosette r in _rosettes)
			{
				if (r.Include)
					r.BlendWeight = nblend;	
			}
		}
		
		public void SetBlendCoeffsToOne()
		{
			foreach (Rosette r in _rosettes)
			{
				if (r.Include)
					r.BlendWeight = 1.0f;	
			}
		}

        public void CreateOutline()
        {
            if (_outline == null)
                 _outline = NewOutline;
            if (_outline_angle_range == null)
                _outline_angle_range = new Range(OTWB.Properties.Settings.Default.Outline_Angle_Start,
                                                 OTWB.Properties.Settings.Default.Outline_Angle_Inc,
                                                 OTWB.Properties.Settings.Default.Outline_Angle_End);
            CreatePoints(_outline_angle_range);
        }

        public Polygon NewOutline
        {
            get
            {
                Polygon p = new Polygon();
                p.Points = new PointCollection();
                p.Fill = new SolidColorBrush(BasicLib.Properties.Settings.Default.FillColor);
                p.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.OutlineColor);
                p.StrokeThickness = 1;
                p.Opacity = 0.8;
                return p;
            }
        }
        public void CreatePoints(Range range)
        {
            _outline.Points.Clear();
            _minradius = _maxradius = RadiusAt(0);
            
            if (_rosettes.Count > 0)
            {
                for (double angle = range.Start; angle < range.End; angle += range.Inc)
                {
                    double r = RadiusAt(angle); ///**** remove -Phase
                    if (r < _minradius)
                        _minradius = r;
                    if (r > _maxradius)
                        _maxradius = r;
                    Point p = Utilities.PointConverter(r, angle);
                    _outline.Points.Add(p);
                }
            }
           if (SpindleOutlineChanged != null)
                SpindleOutlineChanged(this, new EventArgs());
        }

       
    }
}
