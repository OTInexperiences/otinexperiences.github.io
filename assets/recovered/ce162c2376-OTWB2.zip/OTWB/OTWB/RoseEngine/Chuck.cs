using System;
using System.Xml.Serialization;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls.Primitives;
using PropertyTools.Wpf;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;
using BasicLib;

namespace OTWB
{


    public class Chuck : DependencyObject
	{
        ObservableCollection<Stage> _stages;
        CylindricalCollection _mypath;

        public event EventHandler PathChanged;

        PointConverter pConverter;

        protected Path _path;     // outline of this rosette
       
        [Browsable(false)]
        [XmlIgnore]
        public Path Path
        {
            get { return _path; }
        }

        public AXIS RotationAxis { get; set; }
        
        [Browsable(false)]
        [XmlIgnore]
        public CylindricalCollection PathC
        {
            get { return _mypath; }
        }

        [Browsable(false)]
        public Range AngleRange
        {
            get { return (Range)GetValue(AngleRangeProperty); }
            set { SetValue(AngleRangeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for AngleRange.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AngleRangeProperty =
            DependencyProperty.Register("AngleRange", typeof(Range), typeof(Stage),
                           new UIPropertyMetadata(new Range()));

        [XmlIgnore]
        [Browsable(true)]
        [DisplayName("Start Angle")]
        [Category("Ange Range")]
        public double StartAngle
        {
            get { return AngleRange.Start; }
            set { AngleRange.Start = value; CreatePath(); }
        }

        [XmlIgnore]
        [Browsable(true)]
        [DisplayName("Inc Angle")]
        [Category("Ange Range")]
        public double IncAngle
        {
            get { return AngleRange.Inc; }
            set { AngleRange.Inc = value; CreatePath(); }
        }

        [XmlIgnore]
        [Browsable(true)]
        [DisplayName("End Angle")]
        [Category("Ange Range")]
        public double EndAngle
        {
           get { return AngleRange.End; }
            set { AngleRange.End = value; CreatePath(); }
        }

        [XmlIgnore]
        [Browsable(true)]
        [DisplayName("End Turns")]
        [Category("Ange Range")]
        [Slidable(1, 50, 1, 1, true, 1, TickPlacement.BottomRight)]
        public double Turns
        { 
            get { return (int)(EndAngle / 360); }
            set { EndAngle = value * 360;}  
        }
        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }
        #endregion
		
		public Chuck() //: base(CHUCKTYPE.OFFSET)
		{
            _stages = new ObservableCollection<Stage>();
            pConverter = new PointConverter();
            _path = new Path(-1);
            _mypath = new CylindricalCollection();
            AngleRange = new Range(0, 1, 360);
            RotationAxis = Properties.Settings.Default.AXIS0_Default;
		}

        public Chuck(int nstages)
        {
            _stages = new ObservableCollection<Stage>();
            pConverter = new PointConverter();
            _path = new Path(-1);
            _mypath = new CylindricalCollection();
            RotationAxis = Properties.Settings.Default.AXIS0_Default;
            AngleRange = new Range(0, 1, 360);
            for (int i = 0; i < nstages; i++)
            {
                Rosette r = new Rosette(string.Format("stage{0}", i), 20);
                Stage s = new Stage(true, 1, 1, r);
                _stages.Add(s);
            }
            Fixup();
        }

        public void Stages_CollectionChanged(Object sender, NotifyCollectionChangedEventArgs e)
        {
            CreatePath();
        }

        [XmlArray("Chuck_Stages")]
        public ObservableCollection<Stage> Stages
        {
            get { return _stages; }
            set { 
                _stages = value;
                Fixup();
            }
        }

        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [DisplayName("Number of Stages")]
        public int NumStages 
        {
            get { return _stages.Count; }
        }

        public Stage CreateStage(bool samedir, double v_in, double v_out, Rosette r)
        {
            return new Stage(samedir, v_in, v_out, r);     

        }

        public void AddStage(bool samedir, double v_in, double v_out, Rosette r)
        {
            Stage s = new Stage(samedir, v_in, v_out, r);
           
            
            if (_stages == null)
                _stages = new ObservableCollection<Stage>();
            _stages.Add(s);
            //System.Diagnostics.Debug.Print("added new stage is " + s.ToString());
            s.StageDataChanged += new EventHandler(StageDataChanged);
        }

        void Fixup()
        {
            foreach (Stage s in _stages)
            {
                s.StageDataChanged += StageDataChanged;
            }
            _stages.CollectionChanged
               += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(Stages_CollectionChanged);
        }

        public void StageDataChanged(Object sender, EventArgs args)
        {
            CreatePath();
        }

		public void AddStage(Stage s)
        {
            _stages.Add(s);
            s.StageDataChanged += new EventHandler(StageDataChanged);
        }

        public Vector3D VectorAt(double angle)
        {
            Vector3D v = new Vector3D();

            foreach (Stage s in _stages)
            {
                v += s.Rosette.VectorAt(s.OutAngle(angle),RotationAxis);
            }
            return v;
        }

        public Point PointAt(double angle)
        {
            Vector3D v = VectorAt(angle);
            if (RotationAxis == AXIS.Z)
                return new Point(v.X, v.Y);
            else if (RotationAxis == AXIS.Y)
                return new Point(v.X, v.Z);
            else
                return new Point(v.Z,v.Y);
        }

        public void CreatePath()
        {
            _path.Points.Clear();
            _mypath.Clear();
            if (NumStages > 0)
            {
                if (AngleRange == null) return;
                for (double angle = AngleRange.Start; angle <= AngleRange.End; angle += AngleRange.Inc)
                {
                    Vector3D v = VectorAt(angle);
                    int turns = (int)Math.Floor(angle / 360.0);
                    _mypath.Add(new Cylindrical(v,turns));
                    _path.Add(new Point3D(v.X,v.Y,v.Z));
                }
            }
            if (PathChanged != null)
                PathChanged(this, new EventArgs());
        }

        [XmlIgnore]
        [Browsable(true)]
        [DisplayName("Number Turns")]
        [Category("Ange Range")]
        public double NTurns
        {
            get
            {
                double N = 1;
                double D = 1;

                if (NumStages == 0)
                    return 0;
                else 
                {
                    foreach (Stage s in _stages)
                    {
                        double n = s.V_IN;
                        double d = s.V_OUT;
                        double div = Utilities.GCD(n,D);
                        N *= n / div;
                        D = D / div * d;
                    }
                    return N;
                }
            }
        }
    }
}
