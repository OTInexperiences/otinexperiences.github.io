using System;
using System.Windows;
using System.Windows.Media.Media3D;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Xml.Serialization;
using System.ComponentModel;
using BasicLib;
using ExtensionMethods;

namespace OTWB
{
	public enum ORDER
	{
		BY_ANGLE,
		BY_RADIUS,
		BY_X,
		BY_Y
	}
		
	/// <summary>
	/// Class representing 3D surface as slices of profiles indexed 
	/// by either angle or position depending on surface type
	/// For Cylindrical Depth fn of  Radius and angle
	/// For Cartesian Z fn of x and y 
	/// For Spherical !!
	/// </summary>
	[XmlRoot("Surface")]
	public class Surface : ISurface
	{
		Point3D          _maxposn;	// position of largest depth

        [XmlArray("Profiles")]
        [Browsable(false)]
        public SortableObservableCollection<Profile> Profiles { get; set; }
		
		[XmlElement("Depth_Axis")]
        [Browsable(true)]
        [DisplayName("Depth Axis")]
        [Category("Data")]
		public AXIS Depth_Axis { get; set; }
	
		[XmlElement("Profile_Axis")]
        [Browsable(true)]
        [DisplayName("Profile Axis")]
        [Category("Data")]
		public AXIS Profile_Axis { get; set; }
			
		[XmlElement("Coordinate_Type")]
        [Browsable(true)]
        [DisplayName("Coordinate Type")]
		public COORDINATETYPE CoordinateType { get; set; }
				
		[XmlElement("Order")]
        [Browsable(true)]
        [DisplayName("Order")]
        [Category("Data")]
		public ORDER Order { get; set ; }
				
		[XmlIgnore]
        [Browsable(false)]
		public List<double> ProfileKeys
		{
			get { 
				List<double> keys = new List<double>();
				foreach (Profile p in Profiles)
					keys.Add(p.Key);
				return keys;
			}
		}

	
				
		[XmlIgnore]
        [Browsable(true)]
        [DisplayName("Num Profiles")]
        [Category("Information")]
		public int Count
		{
			get { return Profiles.Count; }	
		}

        [Browsable(true)]
        [DisplayName("Maximum Position")]
        [Category("Information")]
        [ReadOnly(true)]
		public Point3D MaxPosition 
		{
			get { return _maxposn; }	
		}
		
		public Surface()  // default is normal to Z axis
		{
			Profiles = new SortableObservableCollection<Profile>();
			//createNewProfile(0);
			CoordinateType = COORDINATETYPE.CYLINDRICAL;
			Order = ORDER.BY_RADIUS;
			_maxposn = new Point3D(0,0,0);
			Depth_Axis = AXIS.Z;
			Profile_Axis = AXIS.X;
		}
		
		public void Clear()
		{
			Profiles.Clear();	
			_maxposn = new Point3D(0,0,0);
		}
		
		public double Depth(double profileindx, double key)
		{
            if (Profiles.Count == 0) return 0;
            if (Profiles.Count == 1)
            {
                return Profiles[0].Value(key);
            }
            else if (ProfileDefined(profileindx))
                return getProfile(profileindx).Value(key);
            else
            {
                Profile pl = this.getProfileOfLeastLargerKey(profileindx);
                Profile ps = this.getProfileOfGreatestSmallerKey(profileindx);
                return (pl.Value(key) + ps.Value(key)) / 2;
            }
		}
		
        public double Depth(Point3D p)
        {
            double depth = 0;
            if (Profiles.Count == 0) return depth;
            if (this.CoordinateType == COORDINATETYPE.CYLINDRICAL)
            {
                Cylindrical pc = new Cylindrical(p);
                if (Profiles.Count == 1)
                {
                    depth = Profiles[0].ValueAt(pc);
                    Console.WriteLine("Cyl 1 profile depth is {0}", depth);
                }
                else if (ProfileDefined(pc.Angle))
                {
                    depth = this.getProfile(pc.Angle).ValueAt(pc);
                    Console.WriteLine("cyl exact profile depth is {0}", depth);
                }
                else
                {
                    Profile pl = this.getProfileOfLeastLargerKey(pc.Angle);
                    Profile ps = this.getProfileOfGreatestSmallerKey(pc.Angle);
                    depth = (pl.Value(pc.Radius) + ps.Value(pc.Radius)) / 2;
                    Console.WriteLine("cyl >1 profile depth is {0}", depth);
                }
            }
            else
            {
                if (Profiles.Count == 1)
                {
                    depth = Profiles[0].Value(p.Y);
                    Console.WriteLine("Cart 1 profile depth is {0}", depth);
                }
                else if (ProfileDefined(p.Y))
                {
                    depth = this.getProfile(p.Y).Value(p.X);
                    Console.WriteLine("cart exact profile depth is {0}", depth);
                }
                else
                {
                    Profile pl = this.getProfileOfLeastLargerKey(p.Y);
                    Profile ps = this.getProfileOfGreatestSmallerKey(p.Y);
                    depth = (pl.Value(p.X) + ps.Value(p.X)) / 2;
                    Console.WriteLine("cart >1 profile depth is {0}", depth);
                }
            }
            return depth;
        }

		// store everything as Cylindrical or Cartesian dependant upon
		// type of surface
		public void Add(Cylindrical pt)
		{
			if (_maxposn == null || _maxposn.Z < pt.Depth)
				_maxposn = pt.asPoint;
			
            if (!ProfileDefined(pt.Angle)) 
					createNewEmptyProfile(pt.Angle);	
			else { // all others to cartesian for now
				Profile p = getProfile(pt.Angle);
				p.Add(pt.Radius,pt.Depth);
				
			}
		}

        public void Add(Point3D pt)
        {
            if (_maxposn == null || _maxposn.Z < pt.Z)
                _maxposn = pt;

            if (!ProfileDefined(pt.Y))
            {
                createNewEmptyProfile(pt.Y);
            }
            Profile p = getProfile(pt.Y);
            p.Add(pt.X, pt.Z);
        }

		public void Remove(Cylindrical c)
		{
			Profile p;
			if (ProfileDefined(c.Angle)) {
				p = getProfile(c.Angle);
					p.RemoveR(c.Radius);
			}
			
			if ( c.asPoint == _maxposn)
				_maxposn = findMaxPosition();
		}

        public void Remove(Point3D c)
        {
            Profile p;
            if (ProfileDefined(c.Y))
            {
                p = getProfile(c.Y);
                p.RemoveR(c.X);
            }
            if (c == _maxposn)
                _maxposn = findMaxPosition();
        }

        public void AddProfile(Profile p)
        {
            Profiles.Add(p);
            Profiles.Sort((Profile pf) => pf.Key);
        }

		public void RemoveProfile(double key)
		{
			Profile p = getProfile(key);
			Profiles.Remove(p);
			_maxposn = findMaxPosition();
		}
		
		public void Update(Cylindrical pt)
		{
			if (pt.Depth > _maxposn.Z)
				_maxposn = pt.asPoint;
		}

        public void Update(Point3D pt)
        {
            if (pt.Z > _maxposn.Z)
                _maxposn = pt;


        }

		public bool ProfileDefined(double key)
		{
            foreach (Profile p in Profiles)
                if (p.Key == key)
                    return true;
            return false;
		}
		
		public Profile getProfile(double key)
		{
            foreach (Profile p in Profiles)
                if (p.Key == key)
                    return p;
            return null;
		}
		
		// cycle round if not found
		public Profile getProfileOfLeastLargerKey(double key)
		{
			if (Profiles.Count > 1) {
				Profile largestKeyProfile = lastProfile;
				if (key < largestKeyProfile.Key) {
                    foreach (Profile p in Profiles)
                        if (p.Key > key)
                            return p;
				}
			}
            return Profiles[0];
		}
		
		// cycle round if not found
		public Profile getProfileOfGreatestSmallerKey(double key)
		{
            if (Profiles.Count > 1)
            {

                if (Profiles[0].Key > key)
                    // cycle round to largest value
                    return lastProfile;
                else
                {
                    return Profiles.FindLast(
                                                 delegate(Profile p)
                                                 {
                                                     return p.Key < key;
                                                 }

                                                 );

                }
            }
            return Profiles[0];  // only one profile so not applicable
		}
		/// <summary>
		/// create a new profile and add it to the surface
		/// </summary>
		public void createNewEmptyProfile(double key)
		{
			Profile p = new Profile();
            p.Add(0, 0);
			p.Key = key;
			Profiles.Add(p);
            Profiles.Sort<double>(prof => prof.Key);
		}
		
		int compareProfilesByKey(Profile p1, Profile p2)
		{
			 if (p1 == null) {
	            if (p2 == null)
	            {
	                // If p1 is null and p2 is null, they're
	                // equal. 
	                return 0;
				}
	            else
	            {
	                // If p1 is null and p1 is not null, p1
	                // is greater. 
	                return -1;
				}
	        }
	        else
	        {
	            // If p1 is not null...
	            //
	            if (p2 == null) {           
					// ...and p2 is null, p1 is greater.
	                return 1;
	            }
	            else  {
	                
	                return p1.Key.CompareTo(p2.Key);
	            }
	        }
		}
				             
		Profile lastProfile
		{
			get {	
				return Profiles[Profiles.Count - 1];	
			}
		}
		
		// here assuming that path is a valid filename
		// line format is X Y Z A B C u v W so
		// index 0 = X
		//		 1 = Y
		//		 2 = Z
		// 		 3 = A
		//		 4 = B
		//		 5 = C
		// 		 6 = U
		//		 7 = V
		//		 8 = W
		public static Surface  Import(string path,ProjectInfo pinf)
		{
			float X,Y,Z,A,B,C,U,V,W;
			X = Y = Z = A = B = C = U = V = W = float.NegativeInfinity;
			float key = 0, toolmovement1 = 0, toolmovement2 = 0,toolmovement3 = 0;
			Surface s = new Surface();
			if (System.IO.File.Exists(path)) {
				StreamReader re = File.OpenText(path);
				string input = null;
				while ((input = re.ReadLine()) != null)
				{
					string[] vs = input.Split(new char[]{' '});
					X = float.Parse(vs[0]);
					Y = float.Parse(vs[1]);
					Z = float.Parse(vs[2]);
					A = float.Parse(vs[3]);
					B = float.Parse(vs[4]);
					C = float.Parse(vs[5]);
					U = float.Parse(vs[6]);
					V = float.Parse(vs[7]);
					W = float.Parse(vs[8]);
					// if project uses rotary table then look at the cncRotaryTable axis
					// for angle, otherwise just use x, y and z
					if (pinf.UseRotaryTable) {
						switch (pinf.AXIS0)
						{
							case AXIS.X: key = (float)Math.Round(X,pinf.Accuracy); break;
							case AXIS.Y: key = (float)Math.Round(Y,pinf.Accuracy); break;
							case AXIS.Z: key = (float)Math.Round(Z,pinf.Accuracy); break;
							case AXIS.A: key = (float)Math.Round(A,pinf.Accuracy); break;
							case AXIS.B: key = (float)Math.Round(B,pinf.Accuracy); break;
							case AXIS.C: key = (float)Math.Round(C,pinf.Accuracy); break;
							case AXIS.U: key = (float)Math.Round(U,pinf.Accuracy); break;
							case AXIS.V: key = (float)Math.Round(V,pinf.Accuracy); break;
							case AXIS.W: key = (float)Math.Round(W,pinf.Accuracy); break;
						}
					}
						else
							key = (float)Math.Round(Y,pinf.Accuracy);
					
					switch (pinf.AXIS2)
					{
						case AXIS.X: toolmovement1 = (float)Math.Round(X,pinf.Accuracy); break;
						case AXIS.Y: toolmovement1 = (float)Math.Round(Y,pinf.Accuracy); break;
						case AXIS.Z: toolmovement1 = (float)Math.Round(Z,pinf.Accuracy); break;
						case AXIS.A: toolmovement1 = (float)Math.Round(A,pinf.Accuracy); break;
						case AXIS.B: toolmovement1 = (float)Math.Round(B,pinf.Accuracy); break;
						case AXIS.C: toolmovement1 = (float)Math.Round(C,pinf.Accuracy); break;
						case AXIS.U: toolmovement1 = (float)Math.Round(U,pinf.Accuracy); break;
						case AXIS.V: toolmovement1 = (float)Math.Round(V,pinf.Accuracy); break;
						case AXIS.W: toolmovement1 = (float)Math.Round(W,pinf.Accuracy); break;
					}
					switch (pinf.AXIS1)
					{
						case AXIS.X: toolmovement2 = (float)Math.Round(X,pinf.Accuracy); break;
						case AXIS.Y: toolmovement2 = (float)Math.Round(Y,pinf.Accuracy); break;
						case AXIS.Z: toolmovement2 = (float)Math.Round(Z,pinf.Accuracy); break;
						case AXIS.A: toolmovement2 = (float)Math.Round(A,pinf.Accuracy); break;
						case AXIS.B: toolmovement2 = (float)Math.Round(B,pinf.Accuracy); break;
						case AXIS.C: toolmovement2 = (float)Math.Round(C,pinf.Accuracy); break;
						case AXIS.U: toolmovement2 = (float)Math.Round(U,pinf.Accuracy); break;
						case AXIS.V: toolmovement2 = (float)Math.Round(V,pinf.Accuracy); break;
						case AXIS.W: toolmovement2 = (float)Math.Round(W,pinf.Accuracy); break;
					}
					
					switch (pinf.AXIS3)
					{
						case AXIS.X: toolmovement3 = (float)Math.Round(X,pinf.Accuracy); break;
						case AXIS.Y: toolmovement3 = (float)Math.Round(Y,pinf.Accuracy); break;
						case AXIS.Z: toolmovement3 = (float)Math.Round(Z,pinf.Accuracy); break;
						case AXIS.A: toolmovement3 = (float)Math.Round(A,pinf.Accuracy); break;
						case AXIS.B: toolmovement3 = (float)Math.Round(B,pinf.Accuracy); break;
						case AXIS.C: toolmovement3 = (float)Math.Round(C,pinf.Accuracy); break;
						case AXIS.U: toolmovement3 = (float)Math.Round(U,pinf.Accuracy); break;
						case AXIS.V: toolmovement3 = (float)Math.Round(V,pinf.Accuracy); break;
						case AXIS.W: toolmovement3 = (float)Math.Round(W,pinf.Accuracy); break;
					}
					
					if (!s.ProfileDefined(key))
						s.createNewEmptyProfile(key);
					Profile p = s.getProfile(key);
                    if (p != null)
					    p.Add(toolmovement1,toolmovement3);
				}		
				re.Close();

			}
			
			return s;
		}
		
		Point3D findMaxPosition()
		{
			Point3D mp = new Point3D();
            if (Profiles.Count == 0)
                return mp;
			
			double r = 0, maxr = 0; 
			double d = 0, maxd = 0;
			double k = 0;
			foreach (Profile p in Profiles) {
				p.MaxValues(out r, out d);
				if (d >= maxd) {
					maxr = r;
					maxd = d;
					k = p.Key;
				}
			}
			return new Point3D(maxr,k,maxd);
		}

        [Browsable(true)]
        [DisplayName("Maximum Key value")]
        [Category("Information")]
        [ReadOnly(true)]
        public double MaxKey
        {
            get {
                double maxkey = 0;
                foreach (Profile p in Profiles)
                    if (p.Key > maxkey)
                        maxkey = p.Key;

                return maxkey;
            }
        }

    }
}
