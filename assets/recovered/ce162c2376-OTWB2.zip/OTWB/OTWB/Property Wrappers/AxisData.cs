﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using BasicLib;

namespace OTWB
{
    class AxisData
    {
        ProjectInfo _info;

        public AxisData(ProjectInfo info)
        {
            _info = info;
        }

        [Category("Physical Axes")]
        [DisplayName("Spindle Axis")]
        [Description("The rose engine spindle rotates around this axis")]
        [Browsable(true)]
        public AXIS Axis0
        {
            get { return _info.AXIS0; }
            set { _info.AXIS0 = value; }
        }

        [Category("Physical Axes")]
        [DisplayName("Pumping Axis")]
        [Description("The rose engine spindle moves along")]
        [Browsable(true)]
        public AXIS Axis01
        {
            get { return _info.AXIS0; }
        }

        [Category("Physical Axes")]
        [DisplayName("Rosette Offset Axis")]
        [Description("The action of a rubber on a rosette forces movement along this axis")]
        [Browsable(true)]
        public AXIS Axis1
        {
            get { return _info.AXIS2; }
            set { _info.AXIS2 = value; }
        }

        [Category("Physical Axes")]
        [DisplayName("Cutter movement Axis")]
        [Description("The cutting frame moves along this axis")]
        [Browsable(true)]
        public AXIS Axis2
        {
            get { return _info.AXIS2; }
            set { _info.AXIS2 = value; }
        }

        [Category("Physical Axes")]
        [DisplayName("Cutter rotation Axis")]
        [Description("The cutting frame rotates around this axis")]
        [Browsable(true)]
        public AXIS Axis3
        {
            get { return _info.AXIS3; }
            set { _info.AXIS3 = value; }
        }
    }
}
