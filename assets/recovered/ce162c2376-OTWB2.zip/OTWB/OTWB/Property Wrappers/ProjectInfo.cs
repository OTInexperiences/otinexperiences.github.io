using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Activities.Presentation.PropertyEditing;
using System.Collections.ObjectModel;
using System.ComponentModel;
using BasicLib;

namespace OTWB
{
	
	/// <summary>
	/// Class encapsulates all info about a project
	/// </summary>
	[Serializable]
	[XmlRoot("Project_Information")] 
	public class ProjectInfo : ICloneable
	{
		// apply default values
		public ProjectInfo() 
		{
			ProjectName = OTWB.Properties.Settings.Default.ProjectName;
            ProjectPath = BasicLib.Properties.Settings.Default.ProjectsFolder;
            Accuracy = 3;

            MaxWorkPieceRadius = OTWB.Properties.Settings.Default.DefaultMaxWorkpieceRadius;
            ProjectNotes = string.Empty;
            SaveOnExit = true;

            AXIS0 = Properties.Settings.Default.AXIS0_Default;  // rotates around this axis 
            AXIS1 = Properties.Settings.Default.AXIS1_Default;  // pumping moves along this axis
            AXIS2 = Properties.Settings.Default.AXIS2_Default;  // rosette offset along this axis
            AXIS3 = Properties.Settings.Default.AXIS3_Default;  // cutter depth along this axis
                       
            HeadStockName = "new_headstock";
            ChuckPathGenRangeEnd = 360;
            ChuckPathGenRangeInc = 1;
            ChuckPathGenRangeStart = 0;
            MachiningData = new  MachiningData();
            ToolTable = new  ToolTable();
            ToolTable.Add(new ToolInfo("tool1", 0, 0));
            CodeType = GCodeType.RELATIVE;
            UsesSurface = false;
		}
		
		public object Clone()
    	{
			MemoryStream ms = new MemoryStream();
			BinaryFormatter bf = new BinaryFormatter();
			bf.Serialize(ms, this);
			ms.Position = 0;
			object obj = bf.Deserialize(ms);
			ms.Close();
			return obj;
		}

        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }
        #endregion

        [Category("Code Generation")]
        [DisplayName("Accuracy")]
        [Description("Number of decimal places for accuracy.")]
        [Browsable(true)]
		[XmlElement("Accuracy")]
		public int Accuracy { get; set; }
		
        [Category("General")]
        [Browsable(true)]
		public string ProjectName { get; set; }

        [Category("General")]
        [Browsable(true)]
        [DisplayName("Use a Surface")]
        public bool UsesSurface { get; set; }

        [Category("General")]
        [Browsable(true)]
        [DisplayName("Surface Normal")]
        public AXIS SurfaceNormal { get; set; }

		[XmlIgnore]
        [Browsable(true)]
        [Category("General")]
        [DisplayName("Project Path")]
        [Description("Location of the project.")]
		public string ProjectPath { get; set; }

        [Category("General")]
        [Browsable(true)]
        [DisplayName("Maximum Workpiece Radius")]
        public double MaxWorkPieceRadius { get; set; }

        [Category("Display")]
        [Browsable(true)]
        public double Opacity { get; set; }

        [Category("General")]
		public bool SaveOnExit { get; set; }
		
         [Category("General")]
         [Browsable(true)]
		[XmlElement("Project_Notes")]
		public string ProjectNotes { get; set; }

        [Category("General")]
		[XmlElement("Headstock")]
        [DisplayName("Headstock Filename")]
        [Description("Name of headstock file")]
        [Browsable(true)]
		public string HeadStockName { get; set; }

        [DisplayName("Start")]
        [Category("Chuck Path Range")]
        [Browsable(true)]
		public double ChuckPathGenRangeStart { get; set; }

        [DisplayName("Increment")]
        [Category("Chuck Path Range")]
        [Browsable(true)]
        public double ChuckPathGenRangeInc { get; set; }

        [Category("Chuck Path Range")]
        [DisplayName("End")]
        [Browsable(true)]
        public double ChuckPathGenRangeEnd { get; set; }
		// Default values for rosettes
       				
		// Defaults for Blending
        [DisplayName("Spindle Axis")]
        [Category("Physical Axes")]
        [Description("Spindle Rotates around this axis and pumping moves in its direction")]
        [Browsable(true)]
        public AXIS AXIS0 { get; set; }

        [DisplayName("Rosette Offset Axis")]
        [Description("Rosettes push headstock along this axis")]
        [Category("Physical Axes")]
        [Browsable(true)]
        public AXIS AXIS1 { get; set; }

        [DisplayName("Cutter Depth Axis")]
        [Description("Cutter moves along this axis")]
        [Category("Physical Axes")]
        [Browsable(true)]
        public AXIS AXIS2 { get; set; }

        [DisplayName("Cutter Rotation Axis")]
        [Description("Cutter direction rotates around axis")]
        [Category("Physical Axes")]
        [Browsable(true)]
        public AXIS AXIS3 { get; set; }

        [XmlIgnore]
        [Browsable(false)]
        public AXIS SpindleRotationAxis
        {
            get
            {
                return Utilities.RotationAxis(AXIS0);
            }
        }

        [DisplayName("Use Rotary Table")]
        [Category("Headstock")]
        [Browsable(true)]
        public bool UseRotaryTable { get; set; }
      
        [DisplayName("Gcode Type")]
        [Category("General")]
        [Browsable(true)]
        public GCodeType CodeType { get; set; }

        [XmlElement("Machining_Data")]
        public  MachiningData MachiningData { get; set; }

        [XmlElement("Tool_Table")]
        public  ToolTable ToolTable { get; set; }

      	public override string ToString ()
		{
			return string.Format("[ProjectInfo: ProjectName={0}",ProjectName);
		}

        
		[XmlIgnore]
		public string ProjectShortName
		{
			get {
					return System.IO.Path.GetFileNameWithoutExtension(ProjectPath);	
			}
		}

        public Range Chuck_Angle_Range
        {
            get
            {
                return new Range(ChuckPathGenRangeStart, ChuckPathGenRangeInc, ChuckPathGenRangeEnd);
            }
            set
            {
                ChuckPathGenRangeStart = value.Start;
                ChuckPathGenRangeInc = value.Inc;
                ChuckPathGenRangeEnd = value.End;
            }
        }

        [XmlIgnore]    
        public string MemoryMapName
        {
            get { return string.Format("{0}_{1}_{2}",ProjectName,
                (CodeType == GCodeType.ABSOLUTE) ? "abs" : "rel",
                        Properties.Settings.Default.MemMapName);
            }
        }
    }
}
