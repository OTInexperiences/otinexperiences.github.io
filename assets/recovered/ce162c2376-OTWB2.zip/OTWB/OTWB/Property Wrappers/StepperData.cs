﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.ComponentModel;
using PropertyTools.Wpf;

namespace OTWB
{
    class StepperDisplayData
    {
        [Category("Main Spindle")]
        [DisplayName("Stepper Steps")]
        [Browsable(true)]
        public int MainSpindleStepperSteps
        {
            get { return Properties.Settings.Default.Main_Spindle_Stepper_Steps; }
            set { Properties.Settings.Default.Main_Spindle_Stepper_Steps = value; }
        }
        [Category("Main Spindle")]
        [DisplayName("Stepper Multiplier")]
        [Browsable(true)]
        public int MainSpindleStepperMultiplier
        {
            get { return Properties.Settings.Default.Main_Spindle_Stepper_Multiplier; }
            set { Properties.Settings.Default.Main_Spindle_Stepper_Multiplier = value; }
        }

        [Category("Main Spindle")]
        [DisplayName("Gear Ratio Numerator")]
        [Browsable(true)]
        public double MainSpindleNumerator
        {
            get { return Properties.Settings.Default.Main_Spindle_Gear_Ratio_Numerator; }
            set { Properties.Settings.Default.Main_Spindle_Gear_Ratio_Numerator = value; }
        }

        [Category("Main Spindle")]
        [DisplayName("Gear Ratio Demoninator")]
        [Browsable(true)]
        public double MainSpindleDenominator
        {
            get { return Properties.Settings.Default.Main_Spindle_Gear_Ratio_Denominator; }
            set { Properties.Settings.Default.Main_Spindle_Gear_Ratio_Denominator = value; }
        }

        [Category("Main Spindle")]
        [DisplayName("Angle per full turn")]
        [Browsable(true)]
        public double MainSpindleAngle
        {
            get { return Properties.Settings.Default.Main_Spindle_Angle_Per_Turn; }
            set { Properties.Settings.Default.Main_Spindle_Angle_Per_Turn = value; }
        }

        [Category("Pump Spindle")]
        [DisplayName("Stepper Steps")]
        [Browsable(true)]
        public int PumpSpindleStepperSteps
        {
            get { return Properties.Settings.Default.Pump_Spindle_Stepper_Steps; }
            set { Properties.Settings.Default.Pump_Spindle_Stepper_Steps = value; }
        }
        [Category("Pump Spindle")]
        [DisplayName("Stepper Multiplier")]
        [Browsable(true)]
        public int PumpSpindleStepperMultiplier
        {
            get { return Properties.Settings.Default.Pump_Spindle_Stepper_Multiplier; }
            set { Properties.Settings.Default.Pump_Spindle_Stepper_Multiplier = value; }
        }

        [Category("Pump Spindle")]
        [DisplayName("Gear Ratio Numerator")]
        [Browsable(true)]
        public double PumpSpindleNumerator
        {
            get { return Properties.Settings.Default.Pump_Spindle_Gear_Ratio_Numerator; }
            set { Properties.Settings.Default.Pump_Spindle_Gear_Ratio_Numerator = value; }
        }

        [Category("Pump Spindle")]
        [DisplayName("Gear Ratio Demoninator")]
        [Browsable(true)]
        public double PumpSpindleDenominator
        {
            get { return Properties.Settings.Default.Pump_Spindle_Gear_Ratio_Denominator; }
            set { Properties.Settings.Default.Pump_Spindle_Gear_Ratio_Denominator = value; }
        }

        [Category("Pump Spindle")]
        [DisplayName("Pitch")]
        [Browsable(true)]
        public double PumpSpindlePitch
        {
            get { return Properties.Settings.Default.Pump_Spindle_Pitch; }
            set { Properties.Settings.Default.Pump_Spindle_Pitch = value; }
        }

        // Offset Spindle

        [Category("Offset Spindle")]
        [DisplayName("Stepper Steps")]
        [Browsable(true)]
        public int OffsetSpindleStepperSteps
        {
            get { return Properties.Settings.Default.Offset_Spindle_Stepper_Steps; }
            set { Properties.Settings.Default.Pump_Spindle_Stepper_Steps = value; }
        }
        [Category("Offset Spindle")]
        [DisplayName("Stepper Multiplier")]
        [Browsable(true)]
        public int OffsetSpindleStepperMultiplier
        {
            get { return Properties.Settings.Default.Offset_Spindle_Stepper_Multiplier; }
            set { Properties.Settings.Default.Offset_Spindle_Stepper_Multiplier = value; }
        }

        [Category("Offset Spindle")]
        [DisplayName("Gear Ratio Numerator")]
        [Browsable(true)]
        public double OffsetSpindleNumerator
        {
            get { return Properties.Settings.Default.Offset_Spindle_Gear_Ratio_Numerator; }
            set { Properties.Settings.Default.Offset_Spindle_Gear_Ratio_Numerator = value; }
        }

        [Category("Offset Spindle")]
        [DisplayName("Gear Ratio Demoninator")]
        [Browsable(true)]
        public double OffsetSpindleDenominator
        {
            get { return Properties.Settings.Default.Offset_Spindle_Gear_Ratio_Denominator; }
            set { Properties.Settings.Default.Offset_Spindle_Gear_Ratio_Denominator = value; }
        }

        [Category("Offset Spindle")]
        [DisplayName("Pitch")]
        [Browsable(true)]
        public double OffsetSpindlePitch
        {
            get { return Properties.Settings.Default.Offset_Spindle_Pitch; }
            set { Properties.Settings.Default.Offset_Spindle_Pitch = value; }
        }

        // Cutter Depth Spindle
        [Category("Cutter Depth Spindle")]
        [DisplayName("Stepper Steps")]
        [Browsable(true)]
        public int CutterDepthSpindleStepperSteps
        {
            get { return Properties.Settings.Default.Cutter_Depth_Spindle_Stepper_Steps; }
            set { Properties.Settings.Default.Pump_Spindle_Stepper_Steps = value; }
        }
        [Category("Cutter Depth Spindle")]
        [DisplayName("Stepper Multiplier")]
        [Browsable(true)]
        public double Cutter_DepthSpindleStepperMultiplier
        {
            get { return Properties.Settings.Default.Cutter_Depth_Spindle_Stepper_Multiplier; }
            set { Properties.Settings.Default.Cutter_Depth_Spindle_Stepper_Multiplier = value; }
        }

        [Category("Cutter Depth Spindle")]
        [DisplayName("Gear Ratio Numerator")]
        [Browsable(true)]
        public double Cutter_DepthSpindleNumerator
        {
            get { return Properties.Settings.Default.Cutter_Depth_Spindle_Gear_Ratio_Numerator; }
            set { Properties.Settings.Default.Cutter_Depth_Spindle_Gear_Ratio_Numerator = value; }
        }

        [Category("Cutter Depth Spindle")]
        [DisplayName("Gear Ratio Demoninator")]
        [Browsable(true)]
        public double Cutter_DepthSpindleDenominator
        {
            get { return Properties.Settings.Default.Cutter_Depth_Spindle_Gear_Ratio_Denominator; }
            set { Properties.Settings.Default.Cutter_Depth_Spindle_Gear_Ratio_Denominator = value; }
        }

        [Category("Cutter Depth Spindle")]
        [DisplayName("Pitch")]
        [Browsable(true)]
        public double Cutter_DepthSpindlePitch
        {
            get { return Properties.Settings.Default.Cutter_Depth_Spindle_Pitch; }
            set { Properties.Settings.Default.Cutter_Depth_Spindle_Pitch = value; }
        }
    }
}
