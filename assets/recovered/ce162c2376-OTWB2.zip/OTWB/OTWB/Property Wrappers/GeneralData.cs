﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.ComponentModel;
using PropertyTools.Wpf;
using BasicLib;

namespace OTWB
{
    class General_Data
    {
        [Category("General")]
        [DisplayName("Load last project on startup")]
        [Browsable(true)]
        public bool LoadOnStartup
        {
            get { return Properties.Settings.Default.LoadProjectOnStartup; }
            set { Properties.Settings.Default.LoadProjectOnStartup = value; }
        }

     
        [Category("Angle Ranges")]
        [DisplayName("Path Generator Range")]
        [Browsable(true)]
        public Range PathGenRange
        {
            get
            {
                return new Range(Properties.Settings.Default.Generator_Range_Start,
                    Properties.Settings.Default.Generator_Range_Increment,
                    Properties.Settings.Default.Generator_Range_End);
            }
            set
            {
                Properties.Settings.Default.Generator_Range_Start = value.Start;
                Properties.Settings.Default.Generator_Range_Increment = value.Inc;
                Properties.Settings.Default.Generator_Range_End = value.End;
            }
        }

        [Category("Angle Ranges")]
        [DisplayName("Spindle Outline Range")]
        [Browsable(true)]
        public Range SpindleOutlineRange
        {
            get { 
                 return new Range(OTWB.Properties.Settings.Default.Outline_Angle_Start,
                     OTWB.Properties.Settings.Default.Outline_Angle_Inc,
                     OTWB.Properties.Settings.Default.Outline_Angle_End); }
            set { 
                OTWB.Properties.Settings.Default.Outline_Angle_Start = value.Start;
                OTWB.Properties.Settings.Default.Outline_Angle_Inc = value.Inc;
                OTWB.Properties.Settings.Default.Outline_Angle_End = value.End;
            }
        }

        [Category("Default Values")]
        [DisplayName("Major Radius")]
        [Browsable(true)]
        public double MajorRadius
        {
            get { return Properties.Settings.Default.Major_Radius_Default; }
            set { Properties.Settings.Default.Major_Radius_Default = value; }
        }

        [Category("Default Values")]
        [DisplayName("Minor Radius")]
        [Browsable(true)]
        public double MinorRadius
        {
            get { return Properties.Settings.Default.Minor_Radius_Default; }
            set { Properties.Settings.Default.Minor_Radius_Default = value; }
        }

        [DisplayName("Maximum Turns")]
        [Description("The max allowable number of rotations used to generate an outline")]
        [Browsable(true)]
        public double MaxTurns
        {
            get { return Properties.Settings.Default.MaxTurns; }
            set { Properties.Settings.Default.MaxTurns = value; }
        }
    }
}
