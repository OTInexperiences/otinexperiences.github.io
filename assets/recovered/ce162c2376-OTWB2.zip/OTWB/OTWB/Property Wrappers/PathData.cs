﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.ComponentModel;
using PropertyTools.Wpf;
using BasicLib;


namespace OTWB
{
    class PathDataWrapper
    {
        Path _path;
        int _indx;
        
        public PathDataWrapper(Path p, int indx)
        {
            _path = p;
            _indx = indx;
        }

        [Category("Information")]
        [DisplayName("Name")]
        [Browsable(true)]
        [ReadOnly(true)]
        public string p0
        {
            get { return string.Format("Path{0}", _indx); }
        }

        [Category("Information")]
        [DisplayName("Number Points")]
        [Browsable(true)]
        [ReadOnly(true)]
        public int p2 
        {
            get { return _path.Count; }
        }

        [Category("Information")]
        [DisplayName("Radial Range")]
        [Browsable(true)]
        [ReadOnly(true)]
        public Range p3
        {
            get { return _path.RadialRange; }
        }

        [Category("Data")]
        [DisplayName("Points")]
        [Browsable(true)]
        [ReadOnly(true)]
        public System.Windows.Media.Media3D.Point3DCollection p4
        {
            get { return _path.Points; }
        }  
    }
}
