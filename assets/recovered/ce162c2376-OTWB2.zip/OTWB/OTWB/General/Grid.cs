﻿using System;
using System.Windows;
using System.Media;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BasicLib;
using System.ComponentModel;
using PropertyTools.Wpf;
using System.Windows.Media;

namespace OTWB
{
    class Grid : DependencyObject
    {
        public enum GRIDTYPE {CARTESIAN,RADIAL};

        private static readonly DependencyProperty Dim1RangeProp =
           DependencyProperty.Register("Range1", typeof(Range), typeof(Grid),
            new PropertyMetadata(new Range(-100,5,100), new PropertyChangedCallback(OnDim1RangePropChanged)));

        private static void OnDim1RangePropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            if (obj is Grid && args != null && args.NewValue != null)
            {
                (obj as Grid).Dim1Range = (Range)args.NewValue;
            }
        }


        private static readonly DependencyProperty Dim2RangeProp =
          DependencyProperty.Register("Range2", typeof(Range), typeof(Grid),
           new PropertyMetadata(new Range(-100,5,100), new PropertyChangedCallback(OnDim2RangePropChanged)));

        private static void OnDim2RangePropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            if (obj is Grid && args != null && args.NewValue != null)
            {
                (obj as Grid).Dim2Range = (Range)args.NewValue;
            }
        }

        [Browsable(true)]
        [Category("Axis Range")]
        [DisplayName("Horizontal/Radial")]
        [TypeConverter(typeof(RangeTypeConverter))]
        public Range Dim1Range
        {
            get { return (Range)GetValue(Dim1RangeProp); }
            set
            {
                SetValue(Dim1RangeProp, value);
            }
        }

        [Browsable(true)]
        [Category("Axis Range")]
        [DisplayName("Vertical/Angular")]
        [TypeConverter(typeof(RangeTypeConverter))]
        public Range Dim2Range
        {
            get { return (Range)GetValue(Dim2RangeProp); }
            set
            {
                SetValue(Dim2RangeProp,value);
            }
        }

        public void CreateGrid()
        {
            if (_gtype == GRIDTYPE.CARTESIAN)
                CreateCartesianGrid();
            else
                CreateRadialGrid();
        }

        private void CreateRadialGrid()
        {
            GeometryGroup gg = new GeometryGroup();
            Point origin = new Point(0,0);
            for (double r = Dim1Range.Start; r <= Dim1Range.End; r += Dim1Range.Inc)
            {
                EllipseGeometry eg = new EllipseGeometry(origin, r, r);
                gg.Children.Add(eg);
            }
           
            for (double a = Dim2Range.Start; a <= Dim2Range.End; a += Dim2Range.Inc)
            {
                double aa = Utilities.toRadians(a);
                double x = Dim1Range.End * Math.Cos(aa);
                double y = Dim1Range.End * Math.Sin(aa);
                Point end = new Point(x,y);
                LineGeometry lg = new LineGeometry(origin, end);
                gg.Children.Add(lg);
            }
            _outline.Data = gg;
        }

        private void CreateCartesianGrid()
        {
            PathGeometry pg = new PathGeometry();
            double start1 = Math.Floor(Dim1Range.Start / Dim1Range.Inc) * Dim1Range.Inc;
            double start2 = Math.Floor(Dim2Range.Start / Dim2Range.Inc) * Dim2Range.Inc;
            double end1 = Math.Round(Dim1Range.End / Dim1Range.Inc,0) * Dim1Range.Inc;
            double end2 = Math.Ceiling(Dim2Range.End / Dim2Range.Inc) * Dim2Range.Inc;
         
            pg.Figures = new PathFigureCollection();
            if (Dim1Range.Start >= 0)
            {  // both are positive so start at 0
                
                for (double x = 0; x <= end1; x += Dim1Range.Inc)
                {
                    PathFigure pf = new PathFigure();
                    pf.StartPoint = new Point(x, start2);
                    pf.Segments = new PathSegmentCollection(1);
                    pf.Segments.Add(new LineSegment(new Point(x, end2), true));
                    pg.Figures.Add(pf);
                }
            }
            else  // starting value is negative
            {   // here go from 0 down to negative starting value
                
                for (double x = 0; x >= start1; x -= Dim1Range.Inc)
                {
                    PathFigure pf = new PathFigure();
                    pf.StartPoint = new Point(x, start2);
                    pf.Segments = new PathSegmentCollection(1);
                    pf.Segments.Add(new LineSegment(new Point(x, end2), true));
                    pg.Figures.Add(pf);
                }
               
                if (Dim1Range.End > 0)
                {
                    // go from 0 to End
                    for (double x = 0; x <= end1; x += Dim1Range.Inc)
                    {
                        PathFigure pf = new PathFigure();
                        pf.StartPoint = new Point(x, start2);
                        pf.Segments = new PathSegmentCollection(1);
                        pf.Segments.Add(new LineSegment(new Point(x,end2), true));
                        pg.Figures.Add(pf);
                    }
                }
            }

            if (Dim2Range.Start >= 0)
            {
                for (double y = 0; y <= end2; y += Dim2Range.Inc)
                {
                    PathFigure pf = new PathFigure();
                    pf.StartPoint = new Point(start1, y);
                    pf.Segments = new PathSegmentCollection(1);
                    pf.Segments.Add(new LineSegment(new Point(end1, y), true));
                    pg.Figures.Add(pf);
                }
            }
            else  
            {
                for (double y = 0; y >= start2; y -= Dim2Range.Inc)
                {
                    PathFigure pf = new PathFigure();
                    pf.StartPoint = new Point(start1, y);
                    pf.Segments = new PathSegmentCollection(1);
                    pf.Segments.Add(new LineSegment(new Point(end1, y), true));
                    pg.Figures.Add(pf);
                }

                if (Dim2Range.End > 0)
                {
                    for (double y = 0; y <= end2; y += Dim2Range.Inc)
                    {
                        PathFigure pf = new PathFigure();
                        pf.StartPoint = new Point(start1, y);
                        pf.Segments = new PathSegmentCollection(1);
                        pf.Segments.Add(new LineSegment(new Point(end1, y), true));
                        pg.Figures.Add(pf);
                    }
                }
            }
            _outline.Data = pg;
        }

        System.Windows.Shapes.Path _outline;
        GRIDTYPE _gtype;

        public Grid(GRIDTYPE _typ)
        {
            _gtype = _typ;
            _outline = new System.Windows.Shapes.Path();
            _outline.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.GridColor);
            _outline.StrokeThickness = 0.5;
            CreateGrid();                       
        }

        public Grid() : this(GRIDTYPE.CARTESIAN) { }

        public System.Windows.Shapes.Path GridOutline
        {
            get { return _outline; }
        }
    }

   
}
