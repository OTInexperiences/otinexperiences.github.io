﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using BasicLib;
using System.ComponentModel;
using Petzold.Media3D;
using System.Windows.Media.Media3D;

namespace OTWB
{
    class Grid3D : WireLines
    {
        public enum GRIDTYPE { CARTESIAN, RADIAL };
        public enum GRIDPLANE { XY, XZ, YZ };

        public Grid3D()
        {
            Opacity = (float)BasicLib.Properties.Settings.Default.Grid_Opacity;
            PropertyChanged(new DependencyPropertyChangedEventArgs());
        }

        [Browsable(false)]
        [Category("Data")]
        [DisplayName("Opacity")]
        public float Opacity
        {
            get { return Color.ScA; }
            set {
                System.Windows.Media.Color c = base.Color;
                c.ScA = value;
                Color = c;
            }
        }

        private static readonly DependencyProperty GridTypeProp =
          DependencyProperty.Register("GridType",
                                      typeof(GRIDTYPE),
                                      typeof(Grid3D),
                                      new UIPropertyMetadata(GRIDTYPE.CARTESIAN,
                                                             PropertyChanged,
                                                             null,
                                                             true));
        [Browsable(true)]
        [Category("Data")]
        [DisplayName("Grid Type")]
        public GRIDTYPE GridType
        {
            get { return (GRIDTYPE)GetValue(GridTypeProp); }
            set { SetValue(GridTypeProp, value); }
        }

        private static readonly DependencyProperty GridPlaneProp =
         DependencyProperty.Register("GridPlane",
                                     typeof(GRIDPLANE),
                                     typeof(Grid3D),
                                     new UIPropertyMetadata(GRIDPLANE.XY,
                                                            PropertyChanged,
                                                            null,
                                                            true));

        [Browsable(true)]
        [Category("Data")]
        [DisplayName("Grid Plane")]
        public GRIDPLANE GridPlane
        {
            get { return (GRIDPLANE)GetValue(GridPlaneProp); }
            set { SetValue(GridPlaneProp, value); }
        }

        private static readonly DependencyProperty Dim1RangeProp =
           DependencyProperty.Register("Range1", 
                                       typeof(Range), 
                                       typeof(Grid3D),
                                       new UIPropertyMetadata(new Range(-100, 5, 100), 
                                                              PropertyChanged,
                                                              null,
                                                              true));

        [Browsable(true)]
        [Category("Axis Range")]
        [DisplayName("Horizontal/Radial")]
        [TypeConverter(typeof(RangeTypeConverter))]
        public Range Dim1Range
        {
            get { return (Range)GetValue(Dim1RangeProp); }
            set { SetValue(Dim1RangeProp, value); }
        }
        private static readonly DependencyProperty Dim2RangeProp =
          DependencyProperty.Register("Range2", 
                                      typeof(Range), 
                                      typeof(Grid3D),
                                      new UIPropertyMetadata(new Range(-100, 5, 100), 
                                                             PropertyChanged,
                                                             null,
                                                             true));
        [Browsable(true)]
        [Category("Axis Range")]
        [DisplayName("Vertical/Angular")]
        [TypeConverter(typeof(RangeTypeConverter))]
        public Range Dim2Range
        {
            get { return (Range)GetValue(Dim2RangeProp); }
            set { SetValue(Dim2RangeProp, value); }
        }

        Point3D GridPoint(double r1, double r2)
        {
            if (GridPlane == GRIDPLANE.XY)
                return new Point3D(r1, r2, 0);
            else if (GridPlane == GRIDPLANE.XZ)
                return new Point3D(r1, 0, r2);
            else
                return new Point3D(0, r1, r2);
        }

        protected override void Generate(DependencyPropertyChangedEventArgs args,
                                        Point3DCollection lines)
        {
            lines.Clear();
            if (GridType == GRIDTYPE.CARTESIAN)
            {
                double start1 = Math.Floor(Dim1Range.Start / Dim1Range.Inc) * Dim1Range.Inc;
                double start2 = Math.Floor(Dim2Range.Start / Dim2Range.Inc) * Dim2Range.Inc;
                double end1 = Math.Round(Dim1Range.End / Dim1Range.Inc, 0) * Dim1Range.Inc;
                double end2 = Math.Ceiling(Dim2Range.End / Dim2Range.Inc) * Dim2Range.Inc;
                double r = 0;
                if (Dim1Range.Start >= 0)
                {  // both are positive so start at 0

                    for (r = 0; r <= end1; r += Dim1Range.Inc)
                    {
                        lines.Add(GridPoint(r,start2));
                        lines.Add(GridPoint(r,end2));
                    }
                }
                else  // starting value is negative
                {   // here go from 0 down to negative starting value

                    for (r = 0; r >= start1; r -= Dim1Range.Inc)
                    {
                        lines.Add(GridPoint(r, start2));
                        lines.Add(GridPoint(r, end2));
                    }

                    if (Dim1Range.End > 0)
                    {
                        // go from 0 to End
                        for (r = 0; r <= end1; r += Dim1Range.Inc)
                        {
                            lines.Add(GridPoint(r, start2));
                            lines.Add(GridPoint(r, end2));
                        }
                    }
                }

                if (Dim2Range.Start >= 0)
                {
                    for (r = 0; r <= end2; r += Dim2Range.Inc)
                    {
                        lines.Add(GridPoint(start1,r));
                        lines.Add(GridPoint(end1,r));
                    }
                }
                else
                {
                    for (r = 0; r >= start2; r -= Dim2Range.Inc)
                    {
                        lines.Add(GridPoint(start1, r));
                        lines.Add(GridPoint(end1, r));
                    }

                    if (Dim2Range.End > 0)
                    {
                        for (r = 0; r <= end2; r += Dim2Range.Inc)
                        {
                            lines.Add(GridPoint(start1, r));
                            lines.Add(GridPoint(end1, r));
                        }
                    }
                }
            }
            else  // create radial grid
            {
                // radial lines
                double aa = 0, x = 0, y = 0;
                for (double a = Dim2Range.Start; a <= Dim2Range.End; a += Dim2Range.Inc)
                {
                    aa = Utilities.toRadians(a);
                    x = Dim1Range.End * Math.Cos(aa);
                    y = Dim1Range.End * Math.Sin(aa);
                    lines.Add(new Point3D());
                    lines.Add(GridPoint(x,y));
                }
                //approx of Circular lines
                 for (double r = Dim1Range.Inc; r <= Dim1Range.End; r += Dim1Range.Inc)
                {
                    for (double a = Dim2Range.Start; a < Dim2Range.End; a += Dim2Range.Inc)
                    {
                        aa = Utilities.toRadians(a);
                        x = r * Math.Cos(aa);
                        y = r * Math.Sin(aa);
                        lines.Add(GridPoint(x,y));
                        aa = Utilities.toRadians(a + Dim2Range.Inc);
                        x = r * Math.Cos(aa);
                        y = r * Math.Sin(aa);
                        lines.Add(GridPoint(x,y));
                    }
                }
            }
        }
      
    }
}
