﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Media;
using System.Linq;
using System.Text;
using BasicLib;

namespace OTWB
{
    class OffsetGenerator
    {
        public StepperData StepData {get; set; }
        public Range Range {get; set; }
        public Surface Surface { get; set; }
        public AXIS SurfaceNormal { get; set; }
        public bool UsingSurface { set; get; }

        public ObservableCollection<FullOffsetInfo> GenerateOffsets(Spindle spindl,AXIS ax, AXIS rx)
        {
            ObservableCollection<FullOffsetInfo> offsets = new ObservableCollection<FullOffsetInfo>();

            double a_steps_per_unit = StepData.StepsPerUnit(ax);
            double a_units_per_step = StepData.UnitsPerStep(ax);
            double r_steps_per_unit = StepData.StepsPerUnit(rx);
            double r_units_per_step = StepData.UnitsPerStep(rx);
           
            double lastAngle = Range.Start;
            double adeficit = 0;

            double lastRadius = spindl.RadiusAt(Range.Start);
            double rdeficit = 0;
            for (double angle = Range.Start; angle <= Range.End; angle += Range.Inc)
            {
                double da = angle - lastAngle;

                if (Utilities.Quadrant0To3(lastAngle,angle))
                    da -= 360;
                else if (Utilities.Quadrant3To0(lastAngle, angle) && da < 0 )
                    da += 360;

                double nsa = da * a_steps_per_unit;
                double nsai = Math.Round(nsa);
                adeficit += da - nsai * a_units_per_step;
                if (Math.Abs(adeficit) >= a_units_per_step)
                {
                    nsai += 1;
                    adeficit = Math.Sign(adeficit) * (Math.Abs(adeficit) - a_units_per_step); 
                }
                double fsa = Math.Abs(Math.Round(adeficit / a_units_per_step * 100));

                double r = spindl.RadiusAt(angle);
                double dr = r - lastRadius;
                double nsr = dr * r_steps_per_unit;
                double nsri = Math.Round(nsr);
                rdeficit += dr - nsri * r_units_per_step;
                if (Math.Abs(rdeficit) >= r_units_per_step)
                {
                    nsri += 1;
                    rdeficit = Math.Sign(rdeficit) * (Math.Abs(rdeficit) - r_units_per_step);
                }


                double fsr = Math.Abs(Math.Round(rdeficit / r_units_per_step * 100));

                FullOffsetInfo info = new FullOffsetInfo(
                                            Utilities.Round(angle),
                                            Utilities.Round(da),
                                            (int)Math.Abs(nsai),
                                            Utilities.Round(adeficit),
                                            fsa,

                                            Utilities.Round(r),
                                            Utilities.Round(dr),
                                            (int)Math.Abs(nsri),
                                            Utilities.Round(rdeficit),
                                            fsr);   
                
                offsets.Add(info);
                lastRadius = r;
                lastAngle = angle;
            }

            return offsets;
        }

        public ObservableCollection<FullOffsetInfo> GenerateChuckOffsets(Chuck chuck, AXIS ax, AXIS rx)
        {
            ObservableCollection<FullOffsetInfo> offsets = new ObservableCollection<FullOffsetInfo>();

            if (chuck.PathC == null)
            {
                if (chuck.AngleRange == null)
                    chuck.AngleRange = Range;
                chuck.CreatePath();
            }

            CylindricalCollection points = chuck.PathC;
           
            double a_steps_per_unit = StepData.StepsPerUnit(ax);
            double a_units_per_step = StepData.UnitsPerStep(ax);
            double r_steps_per_unit = StepData.StepsPerUnit(rx);
            double r_units_per_step = StepData.UnitsPerStep(rx);

            double rdeficit = 0;
            double adeficit = 0;
            Cylindrical lastpoint = null;
            Cylindrical currentpoint;

            for (int i = 0; i < points.Count; i++ )
            {
                currentpoint = points[i];

                double dr = currentpoint.Radius - ((lastpoint != null) ? lastpoint.Radius : 0);
                double nsr = dr * r_steps_per_unit;
                double nsri = Math.Round(nsr);
                rdeficit = dr - nsri * r_units_per_step;
                if (Math.Abs(rdeficit) >= r_units_per_step)
                {
                    nsri += 1;
                    rdeficit = Math.Sign(rdeficit) * (Math.Abs(rdeficit) - r_units_per_step);
                }
                double fsr = Math.Round(rdeficit / r_units_per_step, 2) * 100;

                double da = currentpoint.Angle + adeficit - ((lastpoint != null) ? lastpoint.Angle : 0);
                
                if (lastpoint != null)
                    if (Utilities.Quadrant0To3(lastpoint.Angle, currentpoint.Angle))
                        da -= 360;
                    else if (Utilities.Quadrant3To0(lastpoint.Angle, currentpoint.Angle))
                        da += 360;

                double nsa = da * a_steps_per_unit;
                double nsai = Math.Round(nsa);
                adeficit = da - nsai * a_units_per_step;
                if (Math.Abs(adeficit) >= a_units_per_step)
                {
                    nsai += 1;
                    adeficit = Math.Sign(adeficit) * (Math.Abs(adeficit) - a_units_per_step);
                }
                double fsa = Math.Round(adeficit / a_units_per_step, 2) * 100;

                FullOffsetInfo info = new FullOffsetInfo(
                                            Utilities.Round(currentpoint.Angle),
                                            Utilities.Round(da),
                                            (int)nsai,
                                            Utilities.Round(adeficit),
                                            fsa,

                                            Utilities.Round(currentpoint.Radius),
                                            Utilities.Round(dr),
                                            (int)nsri,
                                            Utilities.Round(rdeficit),
                                            fsr);

                offsets.Add(info);
                lastpoint = currentpoint;
            }

             return offsets;
        }

    }
}
