﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using BasicLib;

namespace OTWB
{
    [Serializable]
    public class FullOffsetInfo
    {
        public double Angle { get; set; }
        public double AOffset { get; set; }
        public int ADirn { get; set; }
        public int ASteps { get; set; }
        public double AError { get; set; }
        public double AEP { get; set; }

        public double Radius { get; set; }
        public double ROffset { get; set; }
        public int RDirn { get; set; }
        public int RSteps { get; set; }
        public double RError { get; set; }
        public double REP { get; set; }

         public FullOffsetInfo(double a, double aoffset, int asteps, double aerror, double aefrac,
                               double v, double voffset, int vsteps, double verror, double vefrac)
         {
             Angle = a;
             AOffset = aoffset;
             ADirn = (aoffset >= 0) ? 1 : 0;
             ASteps = asteps;
             AError = aerror;
             AEP = aefrac;

             Radius = v;
             ROffset = voffset;
             RDirn = (voffset >= 0) ? 1 : 0;
             RSteps = vsteps;
             RError = verror;
             REP = vefrac;
         }
    }

    public class Offsets
    {
        ObservableCollection<FullOffsetInfo> _mainspindle_offsets;
        ObservableCollection<FullOffsetInfo> _pump_offsets;
        ObservableCollection<FullOffsetInfo> _chuck_offsets;

        public ObservableCollection<FullOffsetInfo> MainSpindle_Offsets
        {
            get { return _mainspindle_offsets; }
            set { _mainspindle_offsets = value; }
        }

        public ObservableCollection<FullOffsetInfo> Pump_Offsets
        {
            get { return _pump_offsets; }
            set { _pump_offsets = value; }
        }

        public ObservableCollection<FullOffsetInfo> Chuck_Offsets
        {
            get { return _chuck_offsets; }
            set { _chuck_offsets = value; }
        }

        public Offsets()
        {
            _mainspindle_offsets = new ObservableCollection<FullOffsetInfo>();
            _pump_offsets = new ObservableCollection<FullOffsetInfo>();
            _chuck_offsets = new ObservableCollection<FullOffsetInfo>();
        }

        public void Clear()
        {
            _mainspindle_offsets.Clear();
            _pump_offsets.Clear();
            _chuck_offsets.Clear();
        }

        public ObservableCollection<FullOffsetInfo> OffsetsFor(GCodeSource src)
        {
            if (src ==  GCodeSource.ROSE)
                return MainSpindle_Offsets;
            else if (src ==  GCodeSource.PUMP)
                return Pump_Offsets;
            else if (src ==  GCodeSource.CHUCK)
                return Chuck_Offsets;

            return MainSpindle_Offsets;  // as default
        }


        Range MaxMinRadius (ObservableCollection<FullOffsetInfo> offsets)
        {
           Range r = new Range(offsets[0].Radius, 0, offsets[0].Radius);
           foreach (FullOffsetInfo ff in offsets)
           {
               if (ff.Radius > r.End)
                   r.End = ff.Radius;
               if (ff.Radius < r.Start)
                   r.Start = ff.Radius;
            }
           return r;
        }

        public Range MainSpindleStats
        {
            get { return ((MainSpindle_Offsets != null) && (MainSpindle_Offsets.Count > 0))
                ? MaxMinRadius(MainSpindle_Offsets)
                : new Range(0,0,0); }
        }

        public Range PumpSpindleStats
        {
            get { return ((Pump_Offsets != null) && (Pump_Offsets.Count > 0))
                ? MaxMinRadius(Pump_Offsets)
                : new Range(0,0,0); }
        }

        public Range ChuckStats
        {
            get { return MaxMinRadius(Chuck_Offsets); }
        }
    }
}
