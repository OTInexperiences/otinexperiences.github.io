﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Petzold.Media3D;
using System.Windows;
using System.Windows.Media.Media3D;
using BasicLib;

namespace OTWB
{
    class Path3D : WirePolyline
    {

        public Path3D()
        {
            this.Color = BasicLib.Properties.Settings.Default.ToolPathColor;
            PropertyChanged(new DependencyPropertyChangedEventArgs());         
        }


        private static readonly DependencyProperty PathProp =
         DependencyProperty.Register("PathProp",
                                     typeof(Path),
                                     typeof(Path3D),
                                     new UIPropertyMetadata(new Path(-1),
                                                            PropertyChanged,
                                                            null,
                                                            true));
      
        public Path Path
        {
            get { return (Path)GetValue(PathProp); }
            set {
                if (value != null)
                {
                    SetValue(PathProp, value);
                    Points = value.Points;
                }
            }
        }

        public Range XRange
        {
            get
            {
                Range r = new Range(0, 0, 0);
                foreach (Point3D p in Points)
                {
                    if (p.X > r.End)
                        r.End = p.X;
                    if (p.X < r.Start)
                        r.Start = p.X;
                }
                return r;
            }
        }

        public Range YRange
        {
            get
            {
                Range r = new Range(0, 0, 0);
                foreach (Point3D p in Points)
                {
                    if (p.Y > r.End)
                        r.End = p.Y;
                    if (p.Y < r.Start)
                        r.Start = p.Y;
                }
                return r;
            }
        }

        public Range ZRange
        {
            get
            {
                Range r = new Range(0, 0, 0);
                foreach (Point3D p in Points)
                {
                    if (p.Z > r.End)
                        r.End = p.Z;
                    if (p.Z < r.Start)
                        r.Start = p.Z;
                }
                return r;
            }
        }
    }
}
