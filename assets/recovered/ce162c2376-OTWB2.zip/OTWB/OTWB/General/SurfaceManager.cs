﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BasicLib;

namespace OTWB
{
    public class SurfaceManager
    {
        public Surface Surface {get; set; }

        public SurfaceManager()
        {
            Surface = new Surface();
        }

        public void AddNewProfile(System.Windows.Window owner)
        {
            ValueChooser vc = new ValueChooser();
            vc.Title = "Choose new Profile Key";
            vc.DataLabel = "Profile Key";
            vc.Owner = owner;
            vc.DefaultValue = Surface.MaxKey +  ((Surface.Count > 0) ? 1 : 0);
            vc.ShowDialog();
            if ((bool)vc.DialogResult)
            {
               Surface.createNewEmptyProfile(vc.ChosenValue);
            }
        }

        public void AddProfile(Profile p)
        {
            Surface.AddProfile(p);
        }

        public void DeleteProfile(double key)
        {
            Surface.RemoveProfile(key);
        }

        public void EditProfile(double key)
        {

        }

        public void Clear()
        {
            Surface.Profiles.Clear();
        }

        public void AddPoint(double key)
        {
            Profile p = Surface.getProfile(key);
            if (p != null)
                p.AddNew();
        }

        public void Save(string path)
        {
            // save surface into project area
            Console.WriteLine("Saving surface to {0}", path);
            Serializer<Surface>.WriteFile(path, Surface);
        }

        public bool Open(string path)
        {
            System.Diagnostics.Debug.Print("opening Surface file " + path);
            try
            {
                Surface = Serializer<Surface>.ReadFile(path);
                return (Surface != null);
            }
            catch (Exception)
            {
                MessageBox.Show("Could not open Surface " + path);
            }
            return false;
        }

        public void Update(double key, int row, int col, double newval)
        {
            Profile p = Surface.getProfile(key);
            p.Update(row, col, newval);
        }
    }
}
