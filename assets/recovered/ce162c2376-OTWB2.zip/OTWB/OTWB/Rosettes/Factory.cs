// RosetteFactory.cs created with MonoDevelop
// User: alan at 19:43 28/11/2008
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;
using BasicLib;

namespace OTWB
{
	public class Factory
	{
		
		public Factory()
		{
		}

		public static Rosette NewCircularRosette(ProjectInfo info)
		{
			return new Rosette(info.DefaultRadius);	
		}
		
		public static Rosette NewCircularRosette(float radius) 
		{
			return new Rosette(radius); 
		}

		public static Rosette NewPolyRosette(ProjectInfo info) 
		{
			return new PolygonalRosette(info.DefaultRadius, (int)info.DefaultSymmetry, info.DefaultCurvature); 
		}
		
		public static Rosette NewPolyRosette(float radius,int sides,float curvature) 
		{
			return new PolygonalRosette(radius,sides,curvature); 
		}

		public static Rosette NewWaveRosette(float radius, float freq, float amplitude, bool abs) 
		{
			return new WaveRosette(radius,freq,amplitude,abs);
		}

		public static Rosette NewWaveRosette(ProjectInfo info) 
		{
			return new WaveRosette(info.DefaultRadius,info.DefaultFrequency, info.DefaultAmplitude, info.DefaultUseAbsoluteValues);
		}

		public static Rosette NewEpicycloidRosette(float rfixed, float rrolling) 
		{
			return new EpicycloidRosette(rfixed,rrolling); 		
		}

		public static Rosette NewEpicycloidRosette(ProjectInfo info) 
		{
			return new EpicycloidRosette(info.DefaultRadius, info.DefaultSymmetry); 		
		}
		
		public static Rosette NewHypocycloidRosette(float rfixed, float sym) 
		{
			return new HypocycloidRosette(rfixed,sym); 	
		}
		
		public static Rosette NewHypocycloidRosette(ProjectInfo info) 
		{
			return new HypocycloidRosette(info.DefaultRadius,info.DefaultSymmetry); 	
		}
		
		public static Rosette NewSpiralRosette(float offset, float gradient, float exponent)
		{
			return new SpiralRosette(offset,gradient,exponent);	
		}
		
		public static Rosette NewSpiralRosette(ProjectInfo info)
		{
			return new SpiralRosette(info.DefaultOffset,info.DefaultGradient, info.DefaultExponent);	
		}
		
		public static Rosette NewProfileRosette(AngularProfile p)
		{
			return new ProfileRosette(p);	
		}
		
		
		public static Rosette Load(string path,ROSETTETYPE typ)
		{
			Rosette r = null;
			switch (typ)
			{
				case ROSETTETYPE.ELLIPTICAL:
						r = Serializer<Rosette>.ReadFile(path);
					break;
				case ROSETTETYPE.POLYGON:
						r = Serializer<PolygonalRosette>.ReadFile(path);
					break;
				case ROSETTETYPE.WAVE:
						r = Serializer<WaveRosette>.ReadFile(path);
					break;
				case ROSETTETYPE.EPICYCLOID:
						r = Serializer<EpicycloidRosette>.ReadFile(path);
					break;
				case ROSETTETYPE.HYPOCYCLOID:
						r = Serializer<HypocycloidRosette>.ReadFile(path);
					break;
				case ROSETTETYPE.SPIRAL:
						r = Serializer<SpiralRosette>.ReadFile(path);	
					break;
			case ROSETTETYPE.PROFILE:
						r = Serializer<ProfileRosette>.ReadFile(path);
					break;
			case ROSETTETYPE.FORMULA:
					break;
			}
			
			return r;
		}
		
		public static void Save(string path, Rosette r)
		{
			if (r is WaveRosette)
			{
				Serializer<WaveRosette>.WriteFile(path,(WaveRosette)r);
			}
			else if (r is PolygonalRosette)
			{
				Serializer<PolygonalRosette>.WriteFile(path,(PolygonalRosette)r);
			}
			else if (r is EpicycloidRosette)
			{
				Serializer<EpicycloidRosette>.WriteFile(path,(EpicycloidRosette)r);
			}
			else if (r is HypocycloidRosette)
			{
				Serializer<HypocycloidRosette>.WriteFile(path,(HypocycloidRosette)r);
			}
			else if (r is SpiralRosette)
			{
				Serializer<SpiralRosette>.WriteFile(path,(r as SpiralRosette));	
			}
			else if (r is ProfileRosette)
			{
				Serializer<ProfileRosette>.WriteFile(path, (r as ProfileRosette));	
			}
			else 
			{
				Serializer<Rosette>.WriteFile(path,r);
			}
		}
	}
}
