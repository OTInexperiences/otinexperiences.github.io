
using System;
using System.Xml.Serialization;
using BasicLib;
using System.ComponentModel;
using System.Windows.Media;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using PropertyTools.Wpf;

namespace OTWB
{

	[XmlRootAttribute("Rosette", Namespace="", IsNullable=false)]
	public class HypocycloidRosette : Rosette
	{
        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Information")]
        public override double Turns
        {
            get
            {
                if (Radius % MinorRadius != 0)
                {
                    return Math.Min(Utilities.period(Radius, MinorRadius),
                           OTWB.Properties.Settings.Default.MaxTurns);
                }
                return base.Turns;
            }
        }

		[XmlIgnore]
		protected override string NameTemplate
		{
			get { return "Hypo-R{0}-r{1}"; } 
		}
		
		[XmlIgnore]
		public override double MaxRadius {
			
			get {
				return Radius;
			}
		}

		[XmlIgnore]
		public override double MinRadius {
			
			get {
				return Radius - 2 * MinorRadius;
			}
		}
				
		public  HypocycloidRosette(string name, double R, double r) 
			:base(name,ROSETTETYPE.HYPOCYCLOID,R,r) {}
		
		public HypocycloidRosette(double R, double r) 
			:base(string.Empty,ROSETTETYPE.HYPOCYCLOID,R,r) 
		{
			Name = StandardName;
		}
		
		public HypocycloidRosette() :base(string.Empty,
                                          ROSETTETYPE.HYPOCYCLOID,
                                          OTWB.Properties.Settings.Default.Major_Radius_Default,
                                          OTWB.Properties.Settings.Default.Minor_Radius_Default)
		{
			Name = StandardName;
		}
	
		/// <summary>
        /// k = R / r
        /// x = r * (k - 1)cos θ + r cos ((k-1) θ)
        /// y = r * (k - 1)sin θ - r sin ((k-1) θ)
        /// 
		/// x = (R − r)cos θ + r cos [(R − r) /r)] * θ]
    	/// y = (R − r)sin θ − r sin [(R − r /r)] * θ]
		/// </summary>
		public override double RadiusAt(double angle)
		{
			double ar = Utilities.toRadians(angle);
            double ph = Utilities.toRadians(Phase);
            double k = Radius / MinorRadius;
            double km1 = k - 1;
            double x = MinorRadius * km1 * Math.Cos(ar - ph) + MinorRadius * Math.Cos(km1 * ar - ph);
            double y = MinorRadius * km1 * Math.Sin(ar - ph) - MinorRadius * Math.Sin(km1 * ar - ph);

            Vector v = new Vector(x, y);
            return BlendWeight * v.Length;
		}

        public override void CreatePoints(Range range)
        {
            _outline.Points.Clear();
            double k = Radius / MinorRadius;
            double km1 = k - 1;
            double ph = Utilities.toRadians(Phase);
            for (double angle = range.Start; angle < range.End; angle += range.Inc)
            {
                double ar = Utilities.toRadians(angle);             
                double x = MinorRadius * km1 * Math.Cos(ar - ph) + MinorRadius * Math.Cos(km1 * ar - ph);
                double y = MinorRadius * km1 * Math.Sin(ar - ph) - MinorRadius * Math.Sin(km1 * ar - ph);

                _outline.Points.Add(new Point(BlendWeight * x, BlendWeight * y));
            }
        }

		[XmlIgnore]
		public override string StandardName
		{
			get {
				return string.Format(NameTemplate,Radius,MinorRadius); //,Phase);
			}
		}
	}
}
