using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.ComponentModel;
using BasicLib;
using System.Windows.Media;
using System.Windows;
using System.Windows.Shapes;
using PropertyTools.Wpf;
using System.Windows.Controls.Primitives;

namespace OTWB
{
	
	[XmlRootAttribute("Rosette", Namespace="", IsNullable=false)]
	public class SpiralRosette : Rosette
	{
        [Browsable(true)]
        [Category("Data")]
        [Slidable(0, 100.0, 0.1, 0.5, true, 0.1, TickPlacement.BottomRight)]
        public double Gradient      {
            get { return (double)GetValue(GradientProperty); }
            set { 
                SetValue(GradientProperty, value);
                OutlineChanged();
            }
        }

        [Browsable(true)]
        [Category("Data Helper")]
        [DisplayName("Archimedean Pitch")]
        public double Pitch
        {
            get { return Math.Round(Gradient * (2 * Math.PI),BasicLib.Properties.Settings.Default.DP - 1); }
            set { Gradient = value / (2 * Math.PI); }
        }

        // Using a DependencyProperty as the backing store for Gradient.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GradientProperty =
            DependencyProperty.Register("Gradient", typeof(double), typeof(SpiralRosette),
             new PropertyMetadata(new double(),new PropertyChangedCallback(OnGradientPropChanged)));

        private static void OnGradientPropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newg = Math.Round((double)args.NewValue, 3);

            if (obj is SpiralRosette)
            {
                SpiralRosette r = obj as SpiralRosette;
                r.Gradient = newg;
            }
        }

		[Browsable(true)]
        [Category("Data")]
        [Slidable(0, 20.0, 0.01, 0.5, true, 0.1, TickPlacement.BottomRight)]
        public double Exponent
        {
            get { return (double)GetValue(ExponentProperty); }
            set { 
                SetValue(ExponentProperty, value);
                OutlineChanged();
            }
        }

        // Using a DependencyProperty as the backing store for Exponent.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ExponentProperty =
            DependencyProperty.Register("Exponent", typeof(double), typeof(SpiralRosette),
            new PropertyMetadata(new double(), new PropertyChangedCallback(OnExponentPropChanged)));

        private static void OnExponentPropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newv = Math.Round((double)args.NewValue, 3);

            if (obj is SpiralRosette)
            {
                SpiralRosette r = obj as SpiralRosette;
                r.Exponent = newv;
            }
        }

        [Browsable(true)]
        [Category("Data")]
        public bool IsLogrithmic
        {
            get { return (bool)GetValue(LogrithmicProperty); }
            set
            {
                SetValue(LogrithmicProperty, value);
                OutlineChanged();
            }
        }

        // Using a DependencyProperty as the backing store for Exponent.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LogrithmicProperty =
            DependencyProperty.Register("Logrithmic", typeof(bool), typeof(SpiralRosette));

				
		[XmlIgnore]
		protected override string NameTemplate
		{
			get { if (IsLogrithmic) 
                    return "LogSpiral-O:{0}-G:{1}-E{2}"; 
                  else
                    return "Spiral-O:{0}-G:{1}-E{2}"; 
            }
		}
		
		[XmlIgnore]
        [ReadOnly(true)]
		public override double MaxRadius {
			
			get {
				return RadiusAt(360);
			}
		}

		[XmlIgnore]
        [ReadOnly(true)]
		public override double MinRadius {
			
			get {
				return RadiusAt(0);
			}
		}
		
		public SpiralRosette(string name, double a, double b, double n)
			:base(name,0)
		{
			Radius = a;
			Gradient = b;
			Exponent = n;
			Type = ROSETTETYPE.SPIRAL;
            IsLogrithmic = false;
			Name = StandardName;
		}
		
		public SpiralRosette(double a, double b, double n)
			:this(string.Empty,a,b,n){}
		
		public SpiralRosette()
			:this(string.Empty,0,1.0f,1.0f){}
		
		[XmlIgnore]
		public override string StandardName
		{
			get {
				return string.Format(NameTemplate,Radius,Gradient,Exponent);
			}
		}
		
		public override double RadiusAt(double angle)
		{
            double ar = Utilities.toRadians(angle - Phase);
            if (IsLogrithmic)
                return Radius + Gradient * Math.Exp(ar / Exponent);
            else
			    return Radius + Gradient * Math.Pow(ar, 1 / Exponent);
		}

        public override void EmcData(ref List<string> code, int baseaddr)
        {
            base.EmcData(ref code, baseaddr);
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Pitch, Pitch));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Gradient, Gradient));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Exponent, Exponent));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Logrithmic, (IsLogrithmic ? 1 : 0)));
        }
	}
}
