// OffsetCircleRosette.cs created with MonoDevelop
// User: alan at 16:54 29/11/2008
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;
using System.Xml.Serialization;
using OpenTK.Math;
using Utils;

namespace OTWorkbench
{
	
	[XmlRootAttribute("Rosette", Namespace="", IsNullable=false)]
	public class OffsetCircleRosette : Rosette
	{
		Vector2 _offset;	// offset of centre
		float _cradius;		// radius of circle centres
		
		[XmlIgnore]
		protected override string NameTemplate
		{
			get { return "OC-R{0}-X:{1}-Y:{2}"; } //-P:{3}";}
		}
		
		public OffsetCircleRosette(string name, float radius, Vector2 offset) //, float phase)
			:base(name,radius) //, phase)
		{
			_offset = offset;
			_cradius = (float)Math.Sqrt(_offset.X * _offset.X + _offset.Y * _offset.Y);
			_type = ROSETTETYPE.OFFSETCIRCULAR;
		}

		public OffsetCircleRosette(float radius, Vector2 offset) //, float phase)
			:base(null,radius) //, phase)
		{
			_offset = offset;
			_cradius = (float)Math.Sqrt(_offset.X * _offset.X + _offset.Y * _offset.Y);
			_type = ROSETTETYPE.OFFSETCIRCULAR;
			_name = StandardName;
		}
		
		public OffsetCircleRosette() : base("OffsetCircle",1) //,0)
		{
			_offset = new Vector2(1,0);
			_cradius = 1;
			_type = ROSETTETYPE.OFFSETCIRCULAR;
			_name = StandardName;
		}
		
		[XmlElement("OffsetX")]
		public float OffsetX
		{
			get { return _offset.X; }
			set { _offset.X = value; }
		}
		
		
		[XmlElement("OffsetY")]
		public float OffsetY
		{
			get { return _offset.Y; }
			set { _offset.Y = value; }
		}
		
		public override float Radius(float angle)
		{
			float cx, cy ; // centre of rotating circle;
			float theta = (float)Utilities.toRadians(angle);
			cx = (float)(_offset.X + _cradius * Math.Cos(theta));
			cy = (float)(_offset.Y + _cradius * Math.Sin(theta));

			float d = MeanRadius * MeanRadius - cy * cy;
			float rd, r1,r2;
			
			if ( d > 0 )
			{
				rd = (float)Math.Sqrt(d);
				r1 = cx + rd;
				r2 = cx - rd;
				return (float)(Math.Max(r1,r2));
			}
			else
				return 0.0f;
		}
		
		public override void Draw (Cairo.Context ct,float phase, float blendcoeff)
		{
			Path p = Outline(0,1,360, phase, blendcoeff);
			ct.Translate(-OffsetX,-OffsetY);
			p.Draw2D(ct);
			ct.MoveTo(0,0);
			ct.Arc(0,0,4,0,Utilities.toRadians(360));
			ct.Stroke();
		}

		[XmlIgnore]
		public override string StandardName
		{
			get {
				return string.Format(NameTemplate,MeanRadius,OffsetX,OffsetY); //,Phase);
			}
		}

	}
}
