
using System;
using System.Windows;
using System.Xml.Serialization;
using System.ComponentModel;
using System.Windows.Media;
using System.Windows.Shapes;
using BasicLib;
using PropertyTools.Wpf;

namespace OTWB
{
	
	/// <summary>
	/// Polygonal rosettes may either be straight, convex, concave
	/// adjustment is via a constant sf.
	/// </summary>
	
	[XmlRootAttribute("Rosette", Namespace="", IsNullable=false)]
	public class PolygonalRosette : Rosette
	{
        private static readonly DependencyProperty NumSidesProperty =
          DependencyProperty.Register("NumSides", typeof(int), typeof(PolygonalRosette),
           new PropertyMetadata(new int(), new PropertyChangedCallback(OnNumSidesPropertyChanged)));

        private static void OnNumSidesPropertyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
           int newr = (int)args.NewValue;

            if (obj is PolygonalRosette)
            {
                PolygonalRosette r = obj as PolygonalRosette;
                r.NumSides = newr;
                if (r.Outline == null)
                    r.CreateOutline();
                if (newr > 0)
                    r.CreatePoints(new Range(0, r.Resolution, 360));
            }
        }

        private static readonly DependencyProperty IsStarProperty =
         DependencyProperty.Register("IsStar", typeof(bool), typeof(PolygonalRosette),
          new PropertyMetadata(new bool(), new PropertyChangedCallback(OnIsStarPropertyChanged)));

        private static void OnIsStarPropertyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            bool newr = (bool)args.NewValue;

            if (obj is PolygonalRosette)
            {
                PolygonalRosette r = obj as PolygonalRosette;
                r.IsStar = newr;
                if (r.Outline == null)
                    r.CreateOutline();
                r.CreatePoints(new Range(0, r.Resolution, 360));
            }
        }
        [Browsable(true)]
        [Category("Data")]
        [Slidable(3, 100, 1, 10)]
        public int NumSides
        {
            get { return (int)GetValue(NumSidesProperty); }
            set { 
                SetValue(NumSidesProperty, value);
                OutlineChanged();
            }
        }

        [Browsable(true)]
        [Category("Data")]
        public bool IsStar
        {
            get { return (bool)GetValue(IsStarProperty); }
            set { 
                SetValue(IsStarProperty, value);
                OutlineChanged();
            }
        }

		[XmlIgnore]
        [Browsable(false)]
		protected override string NameTemplate
		{
			get { return "Poly-R{0}-r{1}-N{2}"; }
		}
						
		public PolygonalRosette()
			:base(string.Empty,10.0f) 
		{
			NumSides = 6;
			Type = ROSETTETYPE.POLYGON;
			Name = StandardName;
            Resolution = 0.5;
		}
								
		public override double RadiusAt(double angl)
		{
            double angle = angl - Phase;

            if (NumSides > 2)
            {
                //if (angle - Phase == 0)
                //    return Radius;

                double ns = (IsStar) ? 2 * NumSides : NumSides;

                double da = 360 / ns;
                double dar = Utilities.toRadians(da);

                double da2 = da / 2;
                double dar2 = Utilities.toRadians(da2);

                double f = angle / da;

                int indx = (int)Math.Floor(f);
                double fs = angle - indx * da;

                if (!IsStar)
                {
                    if (fs < da2)
                        fs = da2 - fs;
                else
                    fs = fs - da2;
                    return Radius * Math.Cos(dar2) / Math.Cos(Utilities.toRadians(fs));
                }

                double r1 = Radius;  
                double r2 = MinorRadius;

                if (indx % 2 != 0)
                {
                    Utilities.Swap(ref r1, ref r2);
                }
               
                double l = r1 - r2 * Math.Cos(dar);
                double alpha = Math.Atan(r2 * Math.Sin(dar) / l);

                double r = r2 * Math.Sin(dar + alpha) / Math.Sin(Utilities.toRadians(fs) + alpha);
                //System.Diagnostics.Debug.Print("da {4} angle {0} L {1} alpha {2} r {3}", angle, l, alpha,r,da);
                return r;
            }
            else
                return 0;
		}

		
		[XmlIgnore]
		public override string StandardName
		{
			get {
				return string.Format(NameTemplate,(int)Radius,(int)this.MinorRadius,NumSides); 
			}
		}

        public override void EmcData(ref System.Collections.Generic.List<string> code, int baseaddr)
        {
            base.EmcData(ref code, baseaddr);
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Numsides, NumSides));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_IsStar, (IsStar) ? 1 : 0));
        }
	}
}
