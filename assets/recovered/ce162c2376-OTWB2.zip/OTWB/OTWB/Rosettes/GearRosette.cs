﻿using System;
using System.Xml.Serialization;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using BasicLib;
using System.Windows.Controls.Primitives;
using PropertyTools.Wpf;

namespace OTWB
{
    [XmlRootAttribute("Rosette", Namespace = "", IsNullable = false)]
    public class GearRosette : Rosette
    {

        public static readonly DependencyProperty ModuleProperty =
           DependencyProperty.Register("Module", typeof(double), typeof(GearRosette),
            new PropertyMetadata(new double(), new PropertyChangedCallback(OnModulePropChanged)));

        private static void OnModulePropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newr = (double)args.NewValue;
            if (obj is GearRosette)
            {
                GearRosette r = (GearRosette)obj;
                r.Module = newr;
            }
        }

        [Browsable(true)]
        [Category("Data")]
        [Slidable(0.1, 20.0, 0.1, 5, true, 1, TickPlacement.BottomRight)]
        public double Module
        {
            get { return (double)GetValue(ModuleProperty); }
            set
            {
                SetValue(ModuleProperty, value);
                OutlineChanged();
            }
        }

        [XmlIgnore]
        [Browsable(true)]
        [Category("Data")]
        [Slidable(0, 20.0, 1, 5, true, 1, TickPlacement.BottomRight)]
        public double DiametralPitch
        {
            get { return 25.4 / (double)GetValue(ModuleProperty); }
            set
            {
                SetValue(ModuleProperty, 25.4 / value);
                OutlineChanged();
            }
        }

        public static readonly DependencyProperty PressureAngleProperty =
          DependencyProperty.Register("PressureAngle", typeof(double), typeof(GearRosette),
           new PropertyMetadata(new double(), new PropertyChangedCallback(OnPressureAnglePropChanged)));

        private static void OnPressureAnglePropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newr = (double)args.NewValue;
            if (obj is GearRosette)
            {
                GearRosette r = (GearRosette)obj;
                r.PressureAngle = newr;
            }
        }

        /* Pressure angle in degrees */
        [Browsable(true)]
        [Category("Data")]    
        [Slidable(0, 90.0, 1, 5, true, 1, TickPlacement.BottomRight)]
        public double PressureAngle
        {
            get { return (double)GetValue(PressureAngleProperty); }
            set
            {
                SetValue(PressureAngleProperty, value);
                OutlineChanged();
            }
        }

        public static readonly DependencyProperty NumTeethProperty =
          DependencyProperty.Register("NumTeeth", typeof(int), typeof(GearRosette),
           new PropertyMetadata(new int(), new PropertyChangedCallback(OnNumTeethPropChanged)));

        private static void OnNumTeethPropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            int newr = (int)args.NewValue;
            if (obj is GearRosette)
            {
                GearRosette r = (GearRosette)obj;
                r.NumTeeth = newr;
            }
        }

        [Browsable(true)]
        [Category("Data")]
        [Slidable(0, 200, 1, 5, true, 1, TickPlacement.BottomRight)]
        public int NumTeeth
        {
            get { return (int)GetValue(NumTeethProperty); }
            set
            {
                SetValue(NumTeethProperty, value);
                OutlineChanged();
            }
        }


       

        [XmlIgnore]
        [Browsable(false)]
        public override bool Valid
        {
            get
            {
                return (Module > 0) && (NumTeeth > 0) && (PressureAngle > 0);
            }
        }
        [XmlIgnore]
        [Browsable(false)]
        protected override string NameTemplate
        {
            get { return "Gear-Mod{0}-N{1}-Pa{2}"; } //-P:{3}";}
        }

        [XmlIgnore]
        public override string StandardName
        {
            get
            {
                return string.Format(NameTemplate, Module, NumTeeth, PressureAngle); //,Phase);
            }
        }

        public GearRosette()
            : this(null, 1.0, 12, 20.0f)
        {
            Name = StandardName;
        }

        public GearRosette(string name, double mod, int n, double pa) 
			:base(name,(mod * n / 2) * Math.Cos(Utilities.toRadians(pa))) 
		{
			Module = mod;
			NumTeeth = n;
			Type = ROSETTETYPE.GEAR;
            Name = StandardName;
            if (Valid)
            {
                SetValue(MajorRadiusProperty, OutsideDiameter);
                SetValue(MinorRadiusProperty, PitchDiameter);
            }
		}

        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        public double Addendum
        {
            get { return Module; }
        }

        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        public double Dedendum
        {
            get { return Module * 1.25; }
        }

        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        public double TopLandWidth
        {
            get { return Module * 0.25; }
        }

        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        public double WholeDepth
        {
            get { return Module * 2.25; }
        }
        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        public double PitchDiameter
        {
            get { return Module * NumTeeth; }
        }

        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        public double RootDiameter
        {
            get { return PitchDiameter * Math.Cos(Utilities.toRadians(PressureAngle)); }
        }

        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        public double OutsideDiameter
        {
            get { return (NumTeeth + 2 ) * Module ; }
        }

        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        public double CircularPitch
        {
            get { return Math.PI * Module; }
        }

        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        public double CircularToothThickness
        {
            get { return CircularPitch / 2; }
        }

        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        public double ToothPitchAngle
        {
            get
            {
                return 360 / NumTeeth;
            }
        }
 
        [XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Gear data")]
        [Description("Normal Tooth thickness at pitch diameter")]
        public double NTT
        {
            get { return PitchDiameter * Math.Sin(Utilities.toRadians(90 / NumTeeth)); }
        }

        // angle is in degrees
        public Point RotateAroundOrigin(Point p, double angle)
        {
            Cylindrical2D cp = new Cylindrical2D(p);
            cp.Angle += angle;
            return Utilities.PointConverter(cp);
        }

        // angle is in degrees
        public override Point PointAt(double angl)
        {
            if (Valid)
            {               
                double rot = Math.Floor(angl /ToothPitchAngle) * ToothPitchAngle;
                double adiff = angl - rot;
                double a1 = 180 * TopLandWidth / OutsideDiameter; 
               
                double l1 = ToothPitchAngle / 2 - a1;
                double l2 = ToothPitchAngle / 2;
                double l3 = ToothPitchAngle / 2 + l1;
                double l4 = ToothPitchAngle;

                if (adiff < l1)
                {
                    double f = adiff /l1;
                    double r = Utilities.Linterp(RootDiameter/2, f, OutsideDiameter/2);
                    return Utilities.PointConverterXY(r, angl + Phase);
                }                  
                else if (adiff >= l1 && adiff < l2 )
                {
                   return Utilities.PointConverterXY(OutsideDiameter/2, angl + Phase);
                }
                else if (adiff >= l2 && adiff <= l3)
                {
                    double f = (adiff - l2) / l1;
                    double r = Utilities.Linterp(RootDiameter / 2, 1 - f, OutsideDiameter / 2);
                    return Utilities.PointConverterXY(r, angl + Phase);
                }
                else 
                {
                    return Utilities.PointConverterXY(RootDiameter/2, angl + Phase);
                }                        
            }
            else return Utilities.PointConverterXY(RootDiameter/2,angl + Phase);
        }

        // here the angle has got to be in degrees
        // first param is diameter
        public Point Involute(double d, double a)
        {
            double s = Math.PI * d * a / 360;
            double ar = Utilities.toRadians(a);
            double x = d * Math.Cos(ar) / 2 + s * Math.Sin(ar);
            double y = d * Math.Sin(ar) /2  - s * Math.Cos(ar);
            return  new Point(x, y);
        }

        // angle a in degrees
        // result in radians
        public double Inv(double a)
        {
            return Math.Tan(a) - Utilities.toRadians(a);
        }

        public Point ReflectInYaxis(Point p)
        {
            p.Y *= -1;
            return p;
        }

    }
}
