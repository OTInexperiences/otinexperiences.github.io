
using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.ComponentModel;
using BasicLib;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Activities.Presentation.PropertyEditing;
using PropertyTools.Wpf;


namespace OTWB
{
	
	/// <summary>
	/// This class simulates a Rosette used in OT.
	/// The main function is 
	/// double Radius(double angle)
	/// That returns a radius value that is dependent upon angle.
	/// </summary>

	[XmlInclude (typeof(HypocycloidRosette))]
	[XmlInclude (typeof(EpicycloidRosette))]
	[XmlInclude (typeof(PolygonalRosette))]
	[XmlInclude (typeof(WaveRosette))]
	[XmlInclude (typeof(SpiralRosette))]
	[XmlInclude (typeof(ProfileRosette))]
    [XmlInclude (typeof(GearRosette))]
	[XmlRootAttribute("Rosette", Namespace="", IsNullable=false)]

    public class Rosette : DependencyObject
	{
        public event EventHandler RosetteOutlineChanged;

        protected Polygon _outline;     // outline of this rosette

        [Browsable(false)]
        public Shape Outline
        {
            get { return _outline; }
        }

       protected static readonly DependencyProperty MajorRadiusProperty =
            DependencyProperty.Register("Radius", typeof(double), typeof(Rosette),
             new PropertyMetadata(new double(),new PropertyChangedCallback(OnMajorRadiusPropChanged)));

        private static void OnMajorRadiusPropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newr = Math.Round((double)args.NewValue,3);
           
            if (obj is Rosette)
            {
                Rosette r = obj as Rosette;
                r.Radius = newr;
            }
        }

        private static readonly DependencyProperty NameProp =
           DependencyProperty.Register("Name", typeof(string), typeof(Rosette));

         // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        private static readonly DependencyProperty PhaseProp =
            DependencyProperty.Register("Phase", typeof(double), typeof(Rosette),
            new PropertyMetadata(new double(), new PropertyChangedCallback(OnPhasePropChanged)));

        private static void OnPhasePropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newp = (double)args.NewValue;
            if (obj is Rosette)
            {
                Rosette r = (Rosette)obj;
                r.Phase = newp;
            }
        }
        // Using a DependencyProperty as the backing store for MinorAxis.  This enables animation, styling, binding, etc...
       
        protected static readonly DependencyProperty MinorRadiusProperty =
            DependencyProperty.Register("MinorAxis", typeof(double), typeof(Rosette),
            new PropertyMetadata(new double(), new PropertyChangedCallback(OnMinorRadiusPropChanged)));

        private static void OnMinorRadiusPropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newr = (double)args.NewValue;
            if (obj is Rosette)
            {
                Rosette r = (Rosette)obj;
                r.MinorRadius = newr;
            }
        } 

        // Using a DependencyProperty as the backing store for TypeProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TypeProperty =
            DependencyProperty.Register("Type", typeof(ROSETTETYPE), typeof(Rosette));

        // Using a DependencyProperty as the backing store for BlendWeight.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty BlendWeightProperty =
            DependencyProperty.Register("BlendWeight", typeof(double), typeof(Rosette),
            new PropertyMetadata(new double(), new PropertyChangedCallback(OnBlendWeightPropChanged)));

        private static void OnBlendWeightPropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newbw = (double)args.NewValue;
            if (obj is Rosette)
            {
                Rosette r = (Rosette)obj;
                r.BlendWeight = newbw;
            }
        } 
        // Using a DependencyProperty as the backing store for Include.  This enables animation, styling, binding, etc...
    
        public static readonly DependencyProperty IncludeProperty =
            DependencyProperty.Register("Include", typeof(bool), typeof(Rosette));

        [Browsable(true)]
        [Category("Data")]
        public bool Include
        {
            get { return (bool)GetValue(IncludeProperty); }
            set { 
                SetValue(IncludeProperty, value);
                OutlineChanged();
            }
        }

        [Browsable(true)]
        [Category("Data")]
        [DisplayName("Blend Weight")]
        [Slidable(-2.0, 2.0, 0.1, 0.5, true, 0.1, TickPlacement.BottomRight)]
        public double BlendWeight
        {
            get { return (double)GetValue(BlendWeightProperty); }
            set { 
                SetValue(BlendWeightProperty, value);
                OutlineChanged();
            }
        }

        public static readonly DependencyProperty ResolutionProperty =
       DependencyProperty.Register("Resolution", typeof(double), typeof(Rosette),
        new PropertyMetadata(1.0, new PropertyChangedCallback(OnResolutionPropChanged)));

        private static void OnResolutionPropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newr = (double)args.NewValue;
            if (obj is Rosette)
            {
                Rosette r = (Rosette)obj;
                r.Resolution = newr;
            }
        }

        [Browsable(true)]
        [Category("Data")]
        public double Resolution
        {
            get { return (double)GetValue(ResolutionProperty); }
            set
            {
                SetValue(ResolutionProperty, value);
                OutlineChanged();
            }
        }
        public virtual void OutlineChanged()
        {
            if (Outline == null)
            {
                CreateOutline();
            }
            CreatePoints(new Range(0, Resolution, Turns * 360));
            
            if (RosetteOutlineChanged != null)
                RosetteOutlineChanged(this, new EventArgs());
        }

        [Browsable(true)]
        [Category("Data")]
        [DisplayName("Major Radius")]
        [Slidable(0, 200.0, 0.1, 0.5, true, 0.1, TickPlacement.BottomRight)]
        public double Radius 
        {
            get { return (double)GetValue(MajorRadiusProperty); }
            set { 
                SetValue(MajorRadiusProperty, Math.Round(value,BasicLib.Properties.Settings.Default.DP));
                OutlineChanged();
            }
        }
 
        [Browsable(true)]
        [Category("Data")]
        [DisplayName("Minor Radius")]
        [Slidable(0, 200.0, 0.1, 0.5, true, 0.1, TickPlacement.BottomRight)]
        public virtual double MinorRadius
        {
            get { return (double)GetValue(MinorRadiusProperty); }
            set {
                SetValue(MinorRadiusProperty, Math.Round(value, BasicLib.Properties.Settings.Default.DP));
                OutlineChanged();
            }
        }

        [Browsable(true)]
        [Category("Information")]
        [ReadOnly(true)]
        public ROSETTETYPE Type
        {
            get { return (ROSETTETYPE)GetValue(TypeProperty); }
            set { SetValue(TypeProperty, value); }
        }

        [Browsable(true)]
        [Category("Data")]
        [Slidable(0, 360.0, 0.5, 1, true, 0.5, TickPlacement.BottomRight)]
        public double Phase
        {
            get { return (double)GetValue(PhaseProp); }
            set {
                SetValue(PhaseProp, Math.Round(value, BasicLib.Properties.Settings.Default.DP));
                OutlineChanged();
            }
        }
    
        [Browsable(true)]
        [Category("Data")]
		public string Name 
        {
            get { return (string)GetValue(NameProp);}
            set { SetValue(NameProp,value); }
        } 

		[XmlIgnore]
        [Browsable(false)]
		protected virtual string NameTemplate
		{
            get { return "Ellipse-R{0}-r{1}-P{2}"; }
		}
		
        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Information")]
        [XmlIgnore]
        public double MeanRadius
        {
            get { return (MaxRadius + MinRadius) / 2; }
        }

        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Information")]
		[XmlIgnore]
		public virtual double MaxRadius {	
			get {
                return Math.Max(Radius, MinorRadius);
			}
		}

        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Information")]
		[XmlIgnore]
		public virtual double MinRadius {
			
			get {
				return Math.Min(Radius, MinorRadius);
			}
		}

        [Browsable(true)]
        [ReadOnly(true)]
        [Category("Information")]
        [XmlIgnore]
        public virtual double Turns
        {

            get { return 1.0; }
        }

        public Rosette(string name, ROSETTETYPE typ, double r1, double r2)
        {
            SetValue(NameProp, name);
            SetValue(MajorRadiusProperty, r1);
            SetValue(MinorRadiusProperty, r2);
            SetValue(PhaseProp, 0.0);
            SetValue(BlendWeightProperty, 1.0);
            SetValue(IncludeProperty, true);
            SetValue(TypeProperty,typ);
            CreateOutline();
        }

		public Rosette(string name,double r) 
		{
            SetValue(NameProp, name);
            SetValue(MajorRadiusProperty, r);
            SetValue(MinorRadiusProperty, r);
            SetValue(PhaseProp, 0.0);
            SetValue(BlendWeightProperty, 1.0);
            SetValue(IncludeProperty, true);
            SetValue(TypeProperty, ROSETTETYPE.ELLIPTICAL);
            CreateOutline();
		}

		public Rosette(double r, double phi) 
		{
			SetValue(NameProp, StandardName);
            SetValue(MajorRadiusProperty, r);
            SetValue(MinorRadiusProperty, r);
            SetValue(PhaseProp, phi);
            SetValue(BlendWeightProperty, 1.0);
            SetValue(IncludeProperty, true);
            SetValue(TypeProperty,ROSETTETYPE.ELLIPTICAL);
            CreateOutline();
		}
		
		public Rosette()
		{
            SetValue(NameProp, StandardName);
            SetValue(MajorRadiusProperty, OTWB.Properties.Settings.Default.Major_Radius_Default);
            SetValue(MinorRadiusProperty, OTWB.Properties.Settings.Default.Minor_Radius_Default);
            SetValue(PhaseProp, 0.0);
            SetValue(BlendWeightProperty, 1.0);
            SetValue(IncludeProperty, true);
            SetValue(TypeProperty, ROSETTETYPE.ELLIPTICAL);
            CreateOutline();
		}

        public virtual Vector3D VectorAt(double angle,AXIS axis)
        {
            double r = RadiusAt(angle);
            if (axis == AXIS.X || axis == AXIS.A || axis == AXIS.U)
                return Utilities.VectorConverterYZ(r, angle);
            else if (axis == AXIS.Z || axis == AXIS.C || axis == AXIS.W)
                return Utilities.VectorConverterXY(r, angle);
            else
                return Utilities.VectorConverterXZ(r, angle);
        }

        // relative to centre we have
        // r(theta) =  a * b / (sqrt( (b * cos(theta))^2 + (a * sin(theta))^2 ) 
		public virtual double RadiusAt(double angle)
		{
            double angl = Utilities.toRadians(angle - Phase);
            double bcos = MinorRadius * Math.Cos(angl);
            double asin = Radius * Math.Sin(angl);
            return BlendWeight * Radius * MinorRadius / Math.Sqrt(bcos * bcos + asin * asin);
		}

        public virtual Point PointAt(double angle)
        {
            double r = RadiusAt(angle);
            return Utilities.PointConverter(r, angle);
        }

        public void CreateOutline()
        {
            Polygon p = new Polygon();
            p.Points = new PointCollection();
            p.Fill = new SolidColorBrush(BasicLib.Properties.Settings.Default.FillColor);
            p.Stroke = new SolidColorBrush(BasicLib.Properties.Settings.Default.ToolPathColor);
            p.StrokeThickness = 1;
            _outline = p;
            CreatePoints(new Range(0, 0.5, 360));
        }

        [XmlIgnore]
        [Browsable(false)]
        public virtual bool Valid
        {
            get { return Radius > 0; }
        }

        public virtual void CreatePoints(Range range)
        {
            _outline.Points.Clear();
            if (Valid)
            {
                for (double angle = range.Start; angle < range.End; angle += range.Inc)
                {
                    _outline.Points.Add(PointAt(angle));
                }
            }
        }

		public virtual string StandardName
		{
			get {
				return string.Format(NameTemplate,(int)Radius,(int)MinorRadius, (int)Phase); 
			}
		}

        public virtual void EmcData(ref List<string> code, int baseaddr)
        {
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Type, (int)Type));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Include, (Include) ? 1 : 0));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_R, Radius));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_r, MinorRadius));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Phase, Phase));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Blend, BlendWeight));

        }

	}
}
