
using System;

namespace OTWB
{
	
	
	public enum ROSETTETYPE
	{
		ELLIPTICAL = 0,
		POLYGON = 1,
		WAVE = 2,
		EPICYCLOID = 3,
		HYPOCYCLOID = 4,
		SPIRAL = 5,
        GEAR = 6,
		PROFILE = 7,
		FORMULA = 8
	}
}
