// RosetteRenderer.cs
// 
// Copyright (C) 2008 [Alan Battersby]
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

using System;
using Cairo;
using Utils;

namespace OTWorkbench
{
	
	
	public class RosetteRenderer  : Gtk.CellRenderer
	{
		PhaseElement f_phase_element;		// the rosette to render
//		Color gridColr = new Color(0.3,0.3,0.3);
//		Color itmColr  = new Color(0,0,1);
		double deltaR;
		int f_iconsz;	// helps determine size of icon in pixels
		
		public RosetteRenderer(int iconsz) : base()
		{
			f_iconsz = iconsz;
		}

		public PhaseElement TheRosette
		{
			get { return f_phase_element; }
			set { f_phase_element = value; }
		}

		protected override void Render(Gdk.Drawable drawable, Gtk.Widget widget, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, Gdk.Rectangle expose_area, Gtk.CellRendererState flags)
		{
			if (f_phase_element == null)
				return;
			
			Gdk.Rectangle pix_rect = Gdk.Rectangle.Zero;

			this.GetSize (widget, ref cell_area, out pix_rect.X, out pix_rect.Y, out pix_rect.Width, out pix_rect.Height);

			// Take care of padding
			pix_rect.X += cell_area.X + (int) this.Xpad;
			pix_rect.Y += cell_area.Y + (int) this.Ypad;
			// Remove left, right, top and buttom borders which were added to the returned width
			pix_rect.Width  -= (int) this.Xpad * 2;
			pix_rect.Height -= (int) this.Ypad * 2;
			
			Cairo.Context context = Gdk.CairoHelper.Create (drawable);
			context.Translate (pix_rect.X, pix_rect.Y);
			RenderCell (context,pix_rect);
			
			(context as System.IDisposable).Dispose ();
		}

		public override void GetSize (Gtk.Widget widget, ref Gdk.Rectangle cell_area, out int x_offset, out int y_offset, out int width, out int height)
		{
			width = (int) this.Xpad * 2 + f_iconsz;
			height = (int) this.Ypad * 2 + f_iconsz;
			
			if (cell_area != Gdk.Rectangle.Zero) {
				if (widget.Direction == Gtk.TextDirection.Rtl)
					x_offset =  (int) ((1.0 - this.Xalign) * (cell_area.Width - width));
				else
					x_offset = (int) (this.Xalign * (cell_area.Width - width));
				x_offset = System.Math.Max (x_offset, 0);
				
				y_offset = (int) (this.Yalign * (cell_area.Height - height));
				y_offset = System.Math.Max (y_offset, 0);
			} else {
				x_offset = 0;
				y_offset = 0;
			}
		}

		private double getlineWidth(double width, Cairo.Context ct)
		{
			double lw = width, lh=1.0; 
			ct.InverseTransformDistance(ref lw,ref lh);
			return lw;
		}
		
		void RenderCell(Context ct, Gdk.Rectangle pix_rect )
		{
			ct.Save();
			ct.Translate(pix_rect.Width/2,pix_rect.Height/2);
			deltaR = pix_rect.Width / (f_phase_element.Rosette.MeanRadius * 2 );
			ct.Scale(deltaR,deltaR);
		   // render the rosette
			
			ct.LineWidth = getlineWidth(1.0,ct);
			f_phase_element.Draw(ct);
			ct.Restore();
		}

		

	}
}
