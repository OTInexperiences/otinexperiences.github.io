// CamRosette.cs created with MonoDevelop
// User: alan at 20:25 28/11/2008
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;
using System.Xml.Serialization;
using OpenTK.Math;
using Utils;

namespace OTWorkbench
{
	
	[XmlRootAttribute("Rosette", Namespace="", IsNullable=false)]
	public class CamRosette : Rosette
	{
		Vector2 _offset;
		Rosette _baserosette;
		string  _rname;
		
		[XmlIgnore]
		protected override string NameTemplate
		{
			get { return "Cam-[{0}]-X:{1}-Y:{2}"; } //-P:{3}";}
		}
		
		
		
		[XmlIgnore]
		public override float MaxRadius {
			
			get {
				return _radius + _offset.X;;
			}
		}

		[XmlIgnore]
		public override float MinRadius {
			
			get {
				return _radius - _offset.X;
			}
		}
		
		public CamRosette(string name,Rosette baserosette, Vector2 offset) //, float phase)
			:base(name,0) //,phase)
		{
			_baserosette = baserosette;
			_offset = offset;
			_rname = baserosette.Name;
			_type = ROSETTETYPE.CAM;
		}
		
		public CamRosette(Rosette baserosette, Vector2 offset) //, float phase)
			:base(null,0) //,phase)
		{
			_baserosette = baserosette;
			_offset = offset;
			_rname = baserosette.Name;
			_type = ROSETTETYPE.CAM;
			_name = StandardName;
		}
		
		public CamRosette() : base(null,200) //,0)
		{
			_offset = new Vector2(0,0);
			_baserosette = null;
			_rname = "";
			_type = ROSETTETYPE.CAM;
			_name = StandardName;
		}
		
		[XmlElement("BaseName")]
		[Browseable(true)]
		public string BaseName
		{
			get { return _rname; }
			set { _rname = value; }
		}
		
		[XmlIgnore]
		public Rosette BaseRosette
		{
			get { return _baserosette; }	
			set { _baserosette = value; }
		}

		[XmlElement("OffsetX")]
		[Browseable(true)]
		public float OffsetX
		{
			get { return _offset.X; }
			set { _offset.X = value; }
		}
		
		
		[XmlElement("OffsetY")]
		[Browseable(true)]
		public float OffsetY
		{
			get { return _offset.Y; }
			set { _offset.Y = value; }
		}
		
		
		public override float Radius(float angle)
		{
			float r = 0.0f;

			return r;
		}
		
		[XmlIgnore]
		public override string StandardName
		{
			get {
				return string.Format(NameTemplate,BaseName,OffsetX,OffsetY); //,Phase);
			}
		}
		
	}
}
