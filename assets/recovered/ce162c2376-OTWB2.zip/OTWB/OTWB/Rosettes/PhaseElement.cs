//  
//  Copyright (C) 2009 Alan Battersby
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
// 

using System;
using System.Xml.Serialization;
using System.ComponentModel;
using BasicLib;

namespace OTWB
{
	
	/// <summary>
	/// Rosettes on a spindle have a phase value
	/// </summary>
	[XmlRoot("PhaseElement")]
	public class PhaseElement : INotifyPropertyChanged
	{
        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }
        #endregion
		
		Rosette _rosette;		// the rosette
		
		public PhaseElement()
		{
			_rosette = null;
			Phase = 0;
			BlendCoefficient = 1.0f;
			Include = true;
		}		
		public PhaseElement(Rosette r, double p)
		{
			_rosette= r;
			Phase = p;
			BlendCoefficient = 1.0f;
			Include = true;
		}
		
		[Browsable(true)]
		[XmlIgnore]
		public ROSETTETYPE Type {
			get {
				return _rosette.Type;
			}
			set {
				_rosette.Type = value;
			}
		}
		
		[Browsable(true)]
		public bool Include {get; set; }
			
		[Browsable(true)]
		public double Phase { get; set; }
		
		
		[Browsable(true)]
		public double BlendCoefficient { get; set; }
		
		[XmlIgnore]
		protected string NameTemplate
		{
			get { return "{0} with phase {1}";} //-P:{1}";}
		}
		
		[XmlIgnore]
		public  string StandardName
		{
			get {
				return string.Format(NameTemplate,_rosette.Name,Phase); //,_phase);
			}
		}
		
		[XmlElement("Rosette")]
		public Rosette Rosette
		{
			get { return _rosette; }
			set { _rosette = value; }
		}
		
		public double RadiusAt(double angle)
		{
			if (Include)
				return BlendCoefficient * _rosette.RadiusAt(angle + Phase);
			else
				return 0;
		}
		
       				
		public System.Windows.Point PointAt(double angle)
		{
			System.Windows.Point p = _rosette.PointAt(angle + Phase);
            p.X *= BlendCoefficient;
            p.Y *= BlendCoefficient;
			return p;
		}

        public System.Windows.Vector VectorAt(double angle)
        {
            System.Windows.Vector p = _rosette.VectorAt(angle + Phase);
            p.X *= BlendCoefficient;
            p.Y *= BlendCoefficient;
            return p;
        }
	}
}
