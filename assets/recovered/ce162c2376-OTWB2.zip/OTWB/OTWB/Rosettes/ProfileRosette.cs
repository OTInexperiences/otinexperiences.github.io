
using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using BasicLib;

namespace OTWB
{

	public class ProfileEntry
	{
		double _angle;
		double _radius;
		
		public ProfileEntry(double a, double r)
		{
			_angle = a;
			_radius = r;
		}
		
		public ProfileEntry()
			: this(0,0) {}
		
		[XmlAttribute("Angle")]
		public double Angle
		{
			get { return _angle; }
			set { _angle = value; }
		}
		
		[XmlAttribute("Radius")]
		public double Radius
		{
			get { return _radius; }
			set { _radius = value; }
		}
	}

	public class ProfileRosette : Rosette
	{
		AngularProfile _profile;
	
		[XmlIgnore]
		public AngularProfile Profile {
			get { return _profile; }
			set { 
				_profile = value; 
				_profile.ProfileChanged += _profileProfileChanged;
			}
		}

		// pass on changed event
		void _profileProfileChanged (object sender, EventArgs e)
		{
				
		}
		
		[XmlArray("Profile")]
		public List<ProfileEntry> ProfileList
		{
			get {
				List<ProfileEntry> l = new List<ProfileEntry>();
				foreach (double angle in _profile.Profile.Keys) {
					l.Add(new ProfileEntry(angle,_profile[angle]));
				}
				return l;
			}
			
			set {
				List<ProfileEntry> l = value;
				foreach(ProfileEntry p in l)
				{
					_profile.Add(p.Angle,p.Radius);	
				}
			}
		}
		
		
		[XmlIgnore]
		protected override string NameTemplate
		{
			get { return "Profile-N:{0}"; } 
		}
		
		[XmlIgnore]
		public override double MaxRadius {
			
			get {
				return _profile.MaxRadius;
			}
		}

		[XmlIgnore]
		public override double MinRadius {
			
			get {
				return _profile.MinRadius;
			}
		}
		
		[XmlIgnore]
		public int Count
		{
			get { return _profile.Profile.Count; }	
		}
		
		public ProfileRosette () :base()
		{
			_profile = new AngularProfile();
			Type = ROSETTETYPE.PROFILE;
		}
		
		public ProfileRosette(double ainc, double r) : base()
		{
			_profile = new AngularProfile(ainc,r);
			Type = ROSETTETYPE.PROFILE;
		}
		
		public ProfileRosette(AngularProfile p) : base()
		{
			_profile = p;	
			Type = ROSETTETYPE.PROFILE;
		}
		
		public override double RadiusAt(double angle)
		{
			return _profile.Value(angle - Phase);
		}
		
		public void Add(double angle, double radius)
		{
			_profile.Add(angle,radius);	
		}
		
		public void Remove(double angle)
		{
			_profile.Remove(angle);
			
		}
		
	}
}
