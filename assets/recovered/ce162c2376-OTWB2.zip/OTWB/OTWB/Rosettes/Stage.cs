﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using PropertyTools.Wpf;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Xml.Serialization;

namespace OTWB
{
    // With offset chucks the offset can move either
    // in a circle or in an ellipse
    [Serializable]
    public class Stage : DependencyObject
    {

        [Browsable(true)]
        [Slidable(1, 100, 1, 10, true, 1, TickPlacement.BottomRight)]
        public double V_IN
        {
            get { return (double)GetValue(V_INProperty); }
            set { SetValue(V_INProperty, value); }
        }

        // Using a DependencyProperty as the backing store for V_IN.  This enables animation, styling, binding, etc...
        private static readonly DependencyProperty V_INProperty =
            DependencyProperty.Register("V_IN", typeof(double), typeof(Stage),
                 new PropertyMetadata(new double(), new PropertyChangedCallback(OnPropertyChanged)));

        [Browsable(true)]
        [Slidable(1, 100, 1, 10, true, 1, TickPlacement.BottomRight)]
        public double V_OUT
        {
            get { return (double)GetValue(V_OUTProperty); }
            set { SetValue(V_OUTProperty, value); }
        }

        // Using a DependencyProperty as the backing store for V_IN.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty V_OUTProperty =
            DependencyProperty.Register("V_OUT", typeof(double), typeof(Stage),
                     new PropertyMetadata(new double(), new PropertyChangedCallback(OnPropertyChanged)));

        private static void OnPropertyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            if (obj is Stage)
            {
                if ((obj as Stage).StageDataChanged != null)
                    (obj as Stage).StageDataChanged(obj, new EventArgs());
            }
        }

        [Browsable(true)]
        public bool SameDirection
        {
            get { return (bool)GetValue(SameDirectionProperty); }
            set { SetValue(SameDirectionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SameDirection.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SameDirectionProperty =
            DependencyProperty.Register("SameDirection", typeof(bool), typeof(Stage),
                       new PropertyMetadata(new bool(), new PropertyChangedCallback(OnPropertyChanged)));


        Rosette _rosette;
        public Rosette Rosette
        {
            get { return _rosette; }
            set
            {
                if (_rosette != null)
                {
                    _rosette.RosetteOutlineChanged -= _rosette_RosetteOutlineChanged;
                }
                _rosette = value;
                if (_rosette != null)
                    _rosette.RosetteOutlineChanged += new EventHandler(_rosette_RosetteOutlineChanged);
            }
        }

        void _rosette_RosetteOutlineChanged(object sender, EventArgs e)
        {
            if (StageDataChanged != null)
                StageDataChanged(this, new EventArgs());
        }

        public event EventHandler StageDataChanged;


        [Browsable(true)]
        [XmlIgnore]
        public string Type
        {
            get { return this.Rosette.Type.ToString(); }
        }

        public double OutAngle(double angle)
        {
            return ((SameDirection) ? 1 : -1) * (V_OUT / V_IN) * angle;
        }

        public Stage(bool dir, double gN, double gD, Rosette r)
        {
            V_IN = gN;
            V_OUT = gD;
            SameDirection = dir;
            Rosette = r;
        }

        public Stage()
        {
            V_IN = V_OUT = 1;
            SameDirection = true;
            Rosette = null;
        }

        public override string ToString()
        {
            return string.Format("[{0},{1}:{2},{3}]", SameDirection, V_IN, V_OUT, Rosette.Name);
        }

        public void EmcData(ref List<string> code, int baseaddr)
        {
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.C_Vin, V_IN));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.C_VOut, V_OUT));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.C_SameDirn, 
                                                    (SameDirection ? 1 : 0)));
            Rosette.EmcData(ref code, baseaddr + EMC.Variables.C_Rosette);
        }

    }
}
