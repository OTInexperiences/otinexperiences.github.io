
using System;
using System.Xml.Serialization;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using BasicLib;
using System.Windows.Controls.Primitives;
using PropertyTools.Wpf;

namespace OTWB
{
	[XmlRootAttribute("Rosette", Namespace="", IsNullable=false)]
	public class WaveRosette : Rosette
	{
	
        [Browsable(true)]
        [Category("Data")]
        [Slidable(0, 100.0, 1, 5, true, 1, TickPlacement.BottomRight)]
        public double Frequency
        {
            get { return (double)GetValue(FrequencyProperty); }
            set { 
                SetValue(FrequencyProperty, value);
                OutlineChanged();
            }
        }

        // Using a DependencyProperty as the backing store for double Frequency.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FrequencyProperty = 
            DependencyProperty.Register("Frequency", typeof(double), typeof(WaveRosette),
             new PropertyMetadata(new double(), new PropertyChangedCallback(OnFrequencyPropChanged)));

        private static void OnFrequencyPropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newr = (double)args.NewValue;
            if (obj is WaveRosette)
            {
                WaveRosette r = (WaveRosette)obj;
                r.Frequency = newr;
            }
        }

        [Browsable(true)]
        [Category("Data")]
        [Slidable(0, 200.0, 0.1, 0.5, true, 0.1, TickPlacement.BottomRight)]
        public double Amplitude
        {
            get { return (double)GetValue(AmplitudeProperty); }
            set { 
                SetValue(AmplitudeProperty, value);
                OutlineChanged();
            }
        }

        // Using a DependencyProperty as the backing store for Amplitude.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AmplitudeProperty =
            DependencyProperty.Register("Amplitude", typeof(double), typeof(WaveRosette),
             new PropertyMetadata(new double(), new PropertyChangedCallback(OnAmplitudePropChanged)));
        
        private static void OnAmplitudePropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            double newr = (double)args.NewValue;
            if (obj is WaveRosette)
            {
                WaveRosette r = (WaveRosette)obj;
                r.Amplitude = newr;
            }
        }

         [Browsable(true)]
         [Category("Data")]
        public bool UseAbsolute
        {
            get { return (bool)GetValue(UseAbsoluteProperty); }
            set { 
                SetValue(UseAbsoluteProperty, value);
                OutlineChanged();
            }
        }

        // Using a DependencyProperty as the backing store for bool UseAbsolute.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty UseAbsoluteProperty =
            DependencyProperty.Register("UseAbsolute", typeof(bool), typeof(WaveRosette),
            new PropertyMetadata(new bool(), new PropertyChangedCallback(OnUseAbsolutePropChanged)));

        private static void OnUseAbsolutePropChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            bool newr = (bool)args.NewValue;
            if (obj is WaveRosette)
            {
                WaveRosette r = (WaveRosette)obj;
                r.UseAbsolute = newr;
            }
        }

        [XmlIgnore]
        [Browsable(false)]
        public override double MinorRadius
        {
            get
            {
                return base.MinorRadius;
            }
            set
            {
                base.MinorRadius = value;
            }
        }
		
		[XmlIgnore]
        [Browsable(false)]
		protected override string NameTemplate
		{
			get { return "Wave-R{0}-F{1}-A{2}"; } //-P:{3}";}
		}
		
		[XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
		public override double MaxRadius {
			
			get {
				return Radius + Amplitude;
			}
		}

		[XmlIgnore]
        [Browsable(true)]
        [ReadOnly(true)]
		public override double MinRadius {
			
			get {
				return Radius - Amplitude;
			}
		}
		
		public WaveRosette(string name, double r, double f, double a, bool useabs) 
			:base(name,r) 
		{
			Frequency = f;
			Amplitude = a;
			Type = ROSETTETYPE.WAVE;
			UseAbsolute = useabs;
		}
		
		public WaveRosette(string name, double r, double f, double a) 
			: this(name,r,f,a,false){}

		
		public WaveRosette(double r, double f, double a,bool abs) //,double phase)
			: this(null,r,f,a,abs){}
		
		public WaveRosette() 
			: this(null,100.0f,1.0f,10.0f,false)
		{
			Name = StandardName;
		}

		public override double RadiusAt(double angle)
		{
			double ar = Utilities.toRadians((angle - Phase)* Frequency);
			double amp = Amplitude * Math.Sin(ar);
			double rr = BlendWeight * (double)( Radius + ((UseAbsolute) ? Math.Abs(amp) : amp));
			return rr;
		}

   		[XmlIgnore]
		public override string StandardName
		{
			get {
				return string.Format(NameTemplate,(int)MeanRadius,(int)Frequency,(int)Amplitude); //,Phase);
			}
		}

        public override void EmcData(ref System.Collections.Generic.List<string> code, int baseaddr)
        {
            base.EmcData(ref code, baseaddr);
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Frequency, Frequency));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Amplitude, Amplitude));
            code.Add(EMC.Variables.Assign(baseaddr + EMC.Variables.R_Absolute, (UseAbsolute) ? 1 : 0));

        }
     }
}
