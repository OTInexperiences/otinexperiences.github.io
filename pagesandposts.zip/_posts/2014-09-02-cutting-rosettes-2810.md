---
layout: post
title: Cutting Rosettes
date: 2014-09-02 16:54:16 +0000
author: Alan
categories:
- cutting patterns
- New Rose Engine
- Techniques
- Tools
tags: []
permalink: /blog/cutting-rosettes/
original_url: http://ab48.uk/otblog/cutting-rosettes/
recovery_source: wordpress_database
recovery_status: recovered
redirect_from:
- /cutting-rosettes/
- /otblog/cutting-rosettes/
---
The last couple of days I have been looking at cutting rosettes for my machine.

<a href="http://ab48.uk/otblog/wp-content/uploads/2014/09/test-rosette.png"><img class="wp-image-2811 size-medium" src="/assets/placeholder-original-image.svg" alt="My first rosette " width="300" height="249" /></a> My first rosette a 150mm diameter  wave with 6 nodes and an amplitude of 5mm.



<a title="Cutting a Rosette" href="http://ab48.uk/otblog/cutting-a-rosette/">This page </a>shows how I created the rosette above. Next step is to create the rubbers so that the outline of the rosette is translated into a headstock movement on my machine.


